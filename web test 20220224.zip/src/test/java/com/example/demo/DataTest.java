package com.example.demo;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.DigestUtils;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.example.demo.web.common.AESUtil;
import com.example.demo.web.form.GetSpecifyAgentInputForm;
import com.example.demo.web.form.GetSpecifyAgentResultForm;

@RunWith(SpringRunner.class)
@SpringBootTest
public class DataTest {

  @Test
  public void test() throws Exception {

    HttpHeaders headers = new HttpHeaders();
    headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

    MultiValueMap<String, Object> map= new LinkedMultiValueMap<String, Object>();
    AESUtil aes = new AESUtil("MS932");

    map.add("accident_number", aes.encode("73B0000100011", "52315082fcccdf59"));
    map.add("gyoumu_kubun", aes.encode("0", "52315082fcccdf59"));
    map.add("name_kana_sei", aes.encode("ｿﾝﾎﾟ", "52315082fcccdf59"));
    map.add("name_kana_mei", aes.encode("ﾀﾛｳ", "52315082fcccdf59"));
    map.add("kyaku_Namekubun", aes.encode("9", "52315082fcccdf59"));
    map.add("telj1", aes.encode("1-1-1", "52315082fcccdf59"));
    map.add("car_bond_num", aes.encode("D123456789", "52315082fcccdf59"));
    map.add("damage_date", aes.encode("2020/11/11 10:30:00", "52315082fcccdf59"));
    map.add("motor_damage_kubun", aes.encode("1", "52315082fcccdf59"));
    map.add("motor_damage_type", aes.encode("10", "52315082fcccdf59"));
    map.add("driver", aes.encode("1", "52315082fcccdf59"));
    map.add("sontyou_cloud_flag", aes.encode("2", "52315082fcccdf59"));

    HttpEntity<MultiValueMap<String, Object>> request = new HttpEntity<MultiValueMap<String, Object>>(map, headers);

    RestTemplate restTemplate = new RestTemplate();
    ResponseEntity<String> response = restTemplate.exchange("https://app-ebz10-dev.azurewebsites.net/B50Z/XWB/XWBPFLBE001/XWBBE001/XWBBE001001FC01.aspx", HttpMethod.POST, request , String.class);

    System.out.println(response);

  }

  @Test
  public void testMD5() throws Exception {

    String zipCD = "0010000";
    String processDatetime = "20210519093030";
    String strAccessKey = "sdm8ybk2vm2ex77m" + processDatetime + zipCD;
    String md5AccessKey = DigestUtils.md5DigestAsHex(strAccessKey.getBytes());
    System.out.println(md5AccessKey);

    GetSpecifyAgentInputForm params = new GetSpecifyAgentInputForm();
    params.setAccessKey("5a167b1fd1a16d53bfe8ee94e55f73dd");
    params.setProcessDateTime("20211020093031");
    params.setZipCD("0010000");

    RestTemplate template = new RestTemplate();
    GetSpecifyAgentResultForm result =
        template.postForObject("https://xop-app-st.herokuapp.com/api/specifyagent_interface", params,
            GetSpecifyAgentResultForm.class);
    System.out.println(result);

  }

}
