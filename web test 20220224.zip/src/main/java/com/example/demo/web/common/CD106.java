package com.example.demo.web.common;

/**
 * CD106:リターンコードの列挙クラス
 *
 * @author SSD
 *
 */
public enum CD106 implements Encodable<String> {
  /**
   * 正常終了
   */
  INQUIRY_API_RETURN_NORMAL_END("000000", "正常終了"),
  /**
   * 必須項目未設定
   */
  INQUIRY_API_RETURN_ABNORMAL_ITEM_MUST("101001", "必須項目未設定"),
  /**
   * 項目属性不正
   */
  INQUIRY_API_RETURN_ABNORMAL_ITEM_TYPE("101002", "項目属性不正"),
  /**
   * 項目値不正
   */
  INQUIRY_API_RETURN_ABNORMAL_ITEM_VALUE("101003", "項目値不正"),
  /**
   * 項目桁数不正
   */
  INQUIRY_API_RETURN_ABNORMAL_ITEM_BYTE("101004", "項目桁数不正"),
  /**
   * 項目間関連不正
   */
  INQUIRY_API_RETURN_ABNORMAL_ITEM_ASSOCIATION("101005", "項目間関連不正"),
  /**
   * データ取得エラー
   */
  INQUIRY_API_RETURN_ABNORMAL_DATA_READ("201001", "データ取得エラー"),
  /**
   * DB書き込みエラー
   */
  INQUIRY_API_RETURN_ABNORMAL_DATA_WRITE("201002", "DB書き込みエラー"),
  /**
   * 遷移元IPアドレス不正
   */
  INQUIRY_API_RETURN_ABNORMAL_FROM_IP("301001", "遷移元IPアドレス不正"),
  /**
   * その他
   */
  INQUIRY_API_RETURN_ABNORMAL_OTHER("901001", "その他");

  /** デコーダー */
  private static final Decoder<String, CD106> DECODER = Decoder.create(values());

  /** コード値 */
  private final String code;

  /** 名称 */
  private final String name;

  /**
   * コンストラクタ.
   *
   * @param code コード値
   * @param name 名称
   */
  private CD106(String code, String name) {
    this.code = code;
    this.name = name;
  }

  @Override
  public String getCode() {
    return code;
  }

  /**
   * コード値からEnumクラスを取得する.
   *
   * @param code コード値
   * @return 受領形式Enumクラス
   */
  public static CD106 decode(String code) {
    return DECODER.decode(code);
  }

  /**
   * 名称を取得するメソッド.
   *
   * @return 名称
   */
  public String getName() {
    return name;
  }
}

