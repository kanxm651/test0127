package com.example.demo.web.form;

import lombok.Data;

/**
 * マイページの代理店選択画面、代理店検索画面で利用する＠指定代理店情報を取得INPUTのFormクラス
 *
 * @author SSD_曾洋
 *
 */
@SuppressWarnings("serial")
@Data
public class GetSpecifyAgentInputForm {

  /**
   * アクセスキー
   */
  private String accessKey;

  /**
   * 処理日時
   */
  private String processDateTime;

  /**
   * 郵便番号
   */
  private String zipCD;

}
