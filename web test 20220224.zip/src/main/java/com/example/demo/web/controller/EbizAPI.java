package com.example.demo.web.controller;

import java.util.Enumeration;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.web.common.AESUtil;

@RestController
public class EbizAPI {

//  @SuppressWarnings("unchecked")
//  @RequestMapping("/ebiz")
//  public <T> ResponseEntity<String> ebiz(HttpServletRequest request, @RequestBody T entity) {
//    LinkedHashMap<String, String> map = (LinkedHashMap<String, String>) entity;
//    AESUtil aes = new AESUtil();
//
//    System.out.println("----------------------------------------------test start");
//    for (HashMap.Entry<String, String> entry : map.entrySet()) {
//      if (entry.getValue() != null) {
//        String de = aes.decode(entry.getValue(), "52315082fcccdf59");
//        map.put(entry.getKey(), de);
//      }
//      System.out.println(entry.getKey() + ": " + entry.getValue());
//    }
//    System.out.println("----------------------------------------------test end");
//
//    String response = "000000";
//
//    return new ResponseEntity<String>(response, HttpStatus.OK);
//  }

  @RequestMapping("/ebiz")
  public <T> ResponseEntity<String> ebiz(HttpServletRequest request) {

    AESUtil aes = new AESUtil("MS932");

    Enumeration<String> keys = request.getParameterNames();
    while (keys.hasMoreElements() )
    {
       String key = (String)keys.nextElement();
       String value = request.getParameter(key);
       System.out.println(key + ": " + aes.decode(value, "52315082fcccdf59"));
    }

    String response = "000000";

    return new ResponseEntity<String>(response, HttpStatus.OK);

  }

}

