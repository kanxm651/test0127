package com.example.demo.web.form;

import lombok.Data;

/**
 * 「＠指定代理店情報取得インタフェース」の返却値のFormクラス.
 *
 * @author SSD_曾洋
 *
 */
@SuppressWarnings("serial")
@Data
public class GetSpecifyAgentResultForm {

  /**
   * 処理結果ステータス.
   */
  private String statusCode = "";

  /**
   * メッセージ
   */
  private String message = "";

  /**
   * エラーコード
   */
  private String errorCode = "";

  /**
   * ＠指定代理店情報.
   */
  private GetSpecifyAgentResult result = new GetSpecifyAgentResult();

}
