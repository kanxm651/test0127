package com.example.demo.web.form;

import lombok.Data;

@SuppressWarnings("serial")
@Data
public class GetSpecifyAgentResult {

  /** 所有者ID. */
  private String userID = "";

  /** 親口座. */
  private String parentNo = "";

}
