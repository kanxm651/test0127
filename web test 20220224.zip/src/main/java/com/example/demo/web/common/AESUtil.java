package com.example.demo.web.common;

import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.spec.SecretKeySpec;

import org.springframework.beans.factory.annotation.Autowired;

/**
 * 暗号化と復号化をする.
 *
 * @author SSD_曾洋
 *
 */
public class AESUtil {

  @Autowired
  Cipher cipher;

  @Autowired
  SecretKeySpec generateKey;

  private String charsetName;

  public AESUtil() {
    this.charsetName = "UTF-8";
  }

  public AESUtil(String charsetName) {
    this.charsetName = charsetName;
  }

  /**
   * key転換
   *
   * @param 待転換key
   */
  private SecretKeySpec getKey(String key) {
    try {
      KeyGenerator keyGenerator = KeyGenerator.getInstance("AES");
      keyGenerator.init(128);
      // 転換開始
      byte[] keybytes = key.getBytes();
      generateKey = new SecretKeySpec(keybytes, "AES");

      return generateKey;
    } catch (Exception e) {
      e.printStackTrace();
    }
    return null;
  }

  /**
   * 暗号化
   *
   * @param content 暗号化する文字列
   * @param key 待転換key
   * @return 暗号化した文字列
   */
  public String encode(String content, String key) {
    content = null2Blank(content);
    try {
      cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
      cipher.init(Cipher.ENCRYPT_MODE, getKey(key));
      byte[] resultbytes = cipher.doFinal(content.getBytes(charsetName));
      String en = Base64.getEncoder().encodeToString(resultbytes);

      return en;
    } catch (Exception e) {
      e.printStackTrace();
    }
    return null;
  }

  /**
   * 復号化
   *
   * @param content 復号化する文字列
   * @param key 待転換key
   * @return 復号化した文字列
   */
  public String decode(String content, String key) {
    content = null2Blank(content);
    try {
      cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
      cipher.init(Cipher.DECRYPT_MODE, getKey(key));
      byte[] result = Base64.getDecoder().decode(content.getBytes());
      String de = new String(cipher.doFinal(result), charsetName);

      return de;
    } catch (Exception e) {
      e.printStackTrace();
    }
    return null;
  }

  /**
   * NULLを作成する
   */
  public static String null2Blank(String str) {
    if (str == null) {
      return "";
    }
    return str;
  }

}
