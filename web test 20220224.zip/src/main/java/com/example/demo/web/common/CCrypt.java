package com.example.demo.web.common;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Base64;

import org.springframework.util.DigestUtils;

/**
 * 顧客IDの暗号化と復号化をする
 *
 * @author SSD_曾洋
 *
 */
public class CCrypt {
  /**
   * パスフレーズ
   */
  private static final String myCryptKey = "28D65670-6A08-4FF9-BC41-050B33A36E60";

  /**
   * 暗号化(パスフレーズはデフォルトを使用する)
   *
   * @param vtarget [I] 暗号化する文字列
   * @return [O] 暗号化した文字列
   */
  public static String Encrypt(String vtarget) {
    return Encrypt(vtarget, "");
  }

  /**
   * 暗号化
   *
   * @param vtarget [I] 暗号化する文字列
   * @param vcryptKey [I] パスフレーズ（Optional）
   * @return [O] 暗号化した文字列
   */
  public static String Encrypt(String vtarget, String vcryptKey) {
    String currentDateTime;
    String strInput;
    String authKey;
    String target;
    String cryptKey;

    String retEncrypt = "";

    target = null2Blank(vtarget);

    if (vcryptKey == null || vcryptKey.isEmpty()) {
      cryptKey = myCryptKey;
    } else {
      cryptKey = vcryptKey;
    }
    currentDateTime = LocalDateTime.now()
        .format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"));

    // 認証キー作成
    strInput = currentDateTime + target + cryptKey;
    authKey = DigestUtils.md5DigestAsHex(strInput.getBytes());

    // 引数エンコード
    String encTarget;
    encTarget = Base64.getEncoder().encodeToString(target.getBytes());

    retEncrypt = authKey + currentDateTime + encTarget;

    return retEncrypt;
  }

  /**
   * 復号化(パスフレーズはデフォルトを使用する)
   *
   * @param vtarget [I] 復号化する文字列
   * @return [O] 復号化した文字列 復号化に失敗した場合はnull
   */
  public static String Decrypt(String vtarget) {
    return Decrypt(vtarget, "");
  }

  /**
   * 復号化
   *
   * @param vtarget [I] 復号化する文字列
   * @param vcryptKey [I] パスフレーズ（Optional）
   * @return [O] 復号化した文字列 復号化に失敗した場合はnull
   */
  public static String Decrypt(String vtarget, String vcryptKey) {
    String vreturnValue = null;
    String currentDateTime;
    String strInput;
    String authKey;
    String returnString;
    String target;
    String cryptKey;

    vreturnValue = "";

    target = null2Blank(vtarget);

    if (vcryptKey == null || vcryptKey.isEmpty()) {
      cryptKey = myCryptKey;
    } else {
      cryptKey = vcryptKey;
    }

    if (target.length() < 46) {
      // 認証キー＋要求日時のバイト数以下
      return vreturnValue;
    }

    currentDateTime = target.substring(32, 32 + 14);
    // 戻り値復号化
    if (target.substring(46).length() % 4 != 0) {
      // Base64で正常にエンコードできない
      return vreturnValue;
    } else {
      returnString = new String(Base64.getDecoder().decode(target.substring(46)));
    }

    // 認証キー生成
    strInput = currentDateTime + returnString + cryptKey;
    authKey = DigestUtils.md5DigestAsHex(strInput.getBytes());
    // 認証キー比較
    if (!authKey.equals(target.substring(0, 32))) {
      return vreturnValue;
    }

    // 復号化文字列を戻り値に設定して正常終了
    vreturnValue = returnString;

    return vreturnValue;
  }

  /**
   * NULLを作成する
   */
  public static String null2Blank(String str) {
    if (str == null) {
      return "";
    }
    return str;
  }

}

