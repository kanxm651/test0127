package com.example.demo.web.controller;

/**
 * コントローラのベースクラス
 *
 * @author SSD
 *
 */
public class ControllerBase {

  /**
   * 表示するテンプレート名取得
   *
   * @param url 表示するテンプレートURL
   * @return 表示するテンプレート名
   */
  public static String getViewName(String url) {
    String ret = url;
    if (ret.charAt(0) == '/') {
      ret = url.substring(1);
    }
    return ret;
  }

  /**
   * 指定されたURLをリダイレクト指定する
   *
   * @param url URL
   * @return リダイレクト指定が付与されたURL
   */
  public static String redirect(String url) {
    return "redirect:" + url;
  }

}

