package com.example.demo.web.common;

import java.io.Serializable;

/**
 * 外部コードエンコードクラス
 *
 * @author SSD
 *
 */
public interface Encodable<T extends Serializable> {
  /**
   * エンコーダー
   *
   * @return Enum定義
   */
  T getCode();

  /**
   * コードの名称を返す.
   *
   * @return 名称
   */
  String getName();
}

