package com.example.demo.web.controller;

import java.net.URL;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.DigestUtils;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.client.RestTemplate;

import com.example.demo.web.common.AESUtil;
import com.example.demo.web.common.CD106;
import com.example.demo.web.common.SslUtils;
import com.example.demo.web.form.GetSpecifyAgentInputForm;
import com.example.demo.web.form.GetSpecifyAgentResultForm;

@Controller
public class STTest extends ControllerBase {

  @RequestMapping(value = "/st_main", method = RequestMethod.GET)
  public String st_main() {
    return getViewName("/st_main");
  }

  @RequestMapping(value = "/st_encode", method = RequestMethod.GET)
  public String st_encode() {
    return getViewName("/st_encode");
  }

  @RequestMapping(value = "/st_encode", method = RequestMethod.POST)
  public String st_encode_p(HttpServletRequest request, Model model) {
    AESUtil aes = new AESUtil();
    model.addAttribute("encodeB", request.getParameter("encode"));
    model.addAttribute("encodeA", aes.encode(request.getParameter("encode"), "6b4d2cfd8505535c"));
    return getViewName("/st_encode");
  }

  @RequestMapping(value = "/st_decode", method = RequestMethod.GET)
  public String st_decode() {
    return getViewName("/st_decode");
  }

  @RequestMapping(value = "/st_decode", method = RequestMethod.POST)
  public String st_decode_p(HttpServletRequest request, Model model) {
    AESUtil aes = new AESUtil();
    model.addAttribute("decodeB", request.getParameter("decode"));
    model.addAttribute("decodeA", aes.decode(request.getParameter("decode"), "6b4d2cfd8505535c"));
    return getViewName("/st_decode");
  }

  @RequestMapping(value = "/st_fire", method = RequestMethod.GET)
  public String st_fire() {
    return getViewName("/st_fire");
  }

  @RequestMapping(value = "/st_fire_mypage_ag", method = RequestMethod.POST)
  public String st_fire_mypage_ag() {
    return getViewName("/st_fire_mypage_ag");
  }

  @RequestMapping(value = "/st_off", method = RequestMethod.GET)
  public String st_off() {
    return getViewName("/st_off");
  }

  @RequestMapping(value = "/st_car", method = RequestMethod.GET)
  public String st_car() {
    return getViewName("/st_car");
  }

  @RequestMapping(value = "/st_inquiry_i", method = RequestMethod.GET)
  public String st_inquiry_i() {
    return getViewName("/st_inquiry_i");
  }

  @RequestMapping(value = "/st_inquiry_i", method = RequestMethod.POST)
  public String st_inquiry_i(HttpServletRequest request, Model model) {

    HashMap<String, String> map = new HashMap<String, String>();

    // 遷移元情報
    map.put("SeniMotoInfo", request.getParameter("SeniMotoInfo"));
    // 顧客番号
    map.put("kokyaku_no", request.getParameter("kokyaku_no"));
    // 受付区分
    map.put("Ukekubun", request.getParameter("Ukekubun"));
    // お問合せ区分
    map.put("Question_kubun", request.getParameter("Question_kubun"));
    // 当社契約の有無
    map.put("Exchange", request.getParameter("Exchange"));
    // 証券番号
    map.put("Bill_code_1", request.getParameter("Bill_code_1"));
    // お問い合わせ内容
    map.put("Contents", request.getParameter("Contents"));
    // お客さま区分
    map.put("Send_materials", request.getParameter("Send_materials"));
    // お名前：漢字姓
    map.put("Name_kanji_sei", request.getParameter("Name_kanji_sei"));
    // お名前：漢字名
    map.put("Name_kanji_mei", request.getParameter("Name_kanji_mei"));
    // お名前：カナ姓
    map.put("Name_kana_sei", request.getParameter("Name_kana_sei"));
    // お名前：カナ名
    map.put("Name_kana_mei", request.getParameter("Name_kana_mei"));
    // 生年月日-年号
    map.put("Nengo", request.getParameter("Nengo"));
    // 生年月日-年
    map.put("Nen", request.getParameter("Nen"));
    // 生年月日-月
    map.put("Tuki", request.getParameter("Tuki"));
    // 生年月日-日
    map.put("Hi", request.getParameter("Hi"));
    // 性別
    map.put("Sex", request.getParameter("Sex"));
    // 郵便番号-1
    map.put("Yubin1", request.getParameter("Yubin1"));
    // 郵便番号-2
    map.put("Yubin2", request.getParameter("Yubin2"));
    // 都道府県
    map.put("Address_pref", request.getParameter("Address_pref"));
    // 市区町村
    map.put("Address1", request.getParameter("Address1"));
    // 丁目番地号
    map.put("Address2", request.getParameter("Address2"));
    // マンション名・部屋番号等
    map.put("Address3", request.getParameter("Address3"));
    // 電話番号-1
    map.put("Telj1", request.getParameter("Telj1"));
    // 電話番号-2
    map.put("Telj2", request.getParameter("Telj2"));
    // 電話番号-3
    map.put("Telj3", request.getParameter("Telj3"));
    // 日中連絡先の電話番号-1
    map.put("Telc1", request.getParameter("Telc1"));
    // 日中連絡先の電話番号-2
    map.put("Telc2", request.getParameter("Telc2"));
    // 日中連絡先の電話番号-3
    map.put("Telc3", request.getParameter("Telc3"));
    // 日中連絡先の電話番号の区分
    map.put("Contact_classify", request.getParameter("Contact_classify"));
    // Eメールアドレス
    map.put("Email_add", request.getParameter("Email_add"));
    // 会社名
    map.put("Ones_office", request.getParameter("Ones_office"));
    // 部署名
    map.put("Ones_post", request.getParameter("Ones_post"));
    // 業種
    map.put("Division2", request.getParameter("Division2"));
    // その他の業種
    map.put("Division2_sub", request.getParameter("Division2_sub"));

    // 暗号化処理
    AESUtil aes = new AESUtil();
    for (HashMap.Entry<String, String> entry : map.entrySet()) {
      if (entry.getValue() != null) {
        String de = aes.encode(entry.getValue(), "6b4d2cfd8505535c");
        map.put(entry.getKey(), de);
      }
    }

    MultiValueMap<String, String> paramMap = new LinkedMultiValueMap<String, String>();
    for (HashMap.Entry<String, String> entry : map.entrySet()) {
      paramMap.add(entry.getKey(), entry.getValue());
    }

    RestTemplate template = new RestTemplate();

    URL realUrl = null;
    try {
      realUrl = new URL("https://ohp-st.sompo-japan.co.jp/api/inquiry_interface");
      if("https".equalsIgnoreCase(realUrl.getProtocol())){
        SslUtils.ignoreSsl();
      }
    } catch (Exception e) {
      e.printStackTrace();
    }

    String result = template.postForObject(
        String.valueOf(realUrl), paramMap, String.class);

    model.addAttribute("message",
        "returnCode: " + result + "(" + CD106.decode(result).getName() + ")");

    return getViewName("/st_inquiry_i");
  }

  @RequestMapping(value = "/st_en_inquiry_i", method = RequestMethod.GET)
  public String st_en_inquiry_i() {
    return getViewName("/st_en_inquiry_i");
  }

  @RequestMapping(value = "/st_en_inquiry_i", method = RequestMethod.POST)
  public String st_en_inquiry_i(HttpServletRequest request, Model model) {

    HashMap<String, String> map = new HashMap<String, String>();

    // 受付区分
    map.put("Ukekubun", request.getParameter("Ukekubun"));
    // お問い合わせ内容
    map.put("Contents", request.getParameter("Contents"));
    // お名前：姓
    map.put("Name_kana_sei", request.getParameter("Name_kana_sei"));
    // お名前：名
    map.put("Name_kana_mei", request.getParameter("Name_kana_mei"));
    // 年齢
    map.put("Age", request.getParameter("Age"));
    // 性別
    map.put("Sex", request.getParameter("Sex"));
    // 住所
    map.put("Address_eng", request.getParameter("Address_eng"));
    // Eメールアドレス
    map.put("Email_add", request.getParameter("Email_add"));

    // 暗号化処理
    AESUtil aes = new AESUtil();
    for (HashMap.Entry<String, String> entry : map.entrySet()) {
      if (entry.getValue() != null) {
        String de = aes.encode(entry.getValue(), "6b4d2cfd8505535c");
        map.put(entry.getKey(), de);
      }
    }

    MultiValueMap<String, String> paramMap = new LinkedMultiValueMap<String, String>();
    for (HashMap.Entry<String, String> entry : map.entrySet()) {
      paramMap.add(entry.getKey(), entry.getValue());
    }

    RestTemplate template = new RestTemplate();
    String result = template.postForObject(
        "https://ohp-st.sompo-japan.co.jp/api/english_inquiry_interface", paramMap, String.class);

    model.addAttribute("message",
        "returnCode: " + result + "(" + CD106.decode(result).getName() + ")");

    return getViewName("/st_en_inquiry_i");
  }

  @RequestMapping(value = "/st_off_inquiry_i", method = RequestMethod.GET)
  public String st_off_inquiry_i() {
    return getViewName("/st_off_inquiry_i");
  }

  @RequestMapping(value = "/st_off_inquiry_i", method = RequestMethod.POST)
  public String st_off_inquiry_i(HttpServletRequest request, Model model) {

    HashMap<String, String> map = new HashMap<String, String>();

    // お問い合わせ内容
    map.put("Contents", request.getParameter("Contents"));
    // お名前：漢字姓
    map.put("Name_kanji_sei", request.getParameter("Name_kanji_sei"));
    // お名前：漢字名
    map.put("Name_kanji_mei", request.getParameter("Name_kanji_mei"));
    // お名前：カナ姓
    map.put("Name_kana_sei", request.getParameter("Name_kana_sei"));
    // お名前：カナ名
    map.put("Name_kana_mei", request.getParameter("Name_kana_mei"));
    // 生年月日-年号
    map.put("Nengo", request.getParameter("Nengo"));
    // 生年月日-年
    map.put("Nen", request.getParameter("Nen"));
    // 生年月日-月
    map.put("Tuki", request.getParameter("Tuki"));
    // 生年月日-日
    map.put("Hi", request.getParameter("Hi"));
    // 性別
    map.put("Sex", request.getParameter("Sex"));
    // 契約証番号(ご契約済の方)
    map.put("Off_ContractNumber", request.getParameter("Off_ContractNumber"));
    // 郵便番号-1
    map.put("Yubin1", request.getParameter("Yubin1"));
    // 郵便番号-2
    map.put("Yubin2", request.getParameter("Yubin2"));
    // 都道府県
    map.put("Address_pref", request.getParameter("Address_pref"));
    // 市区町村
    map.put("Address1", request.getParameter("Address1"));
    // 丁目番地号
    map.put("Address2", request.getParameter("Address2"));
    // マンション名・部屋番号等
    map.put("Address3", request.getParameter("Address3"));
    // 電話番号-1
    map.put("Telj1", request.getParameter("Telj1"));
    // 電話番号-2
    map.put("Telj2", request.getParameter("Telj2"));
    // 電話番号-3
    map.put("Telj3", request.getParameter("Telj3"));
    // 日中連絡先の電話番号-1
    map.put("Telc1", request.getParameter("Telc1"));
    // 日中連絡先の電話番号-2
    map.put("Telc2", request.getParameter("Telc2"));
    // 日中連絡先の電話番号-3
    map.put("Telc3", request.getParameter("Telc3"));
    // 日中連絡先の電話番号の区分
    map.put("Contact_classify", request.getParameter("Contact_classify"));
    // Eメールアドレス
    map.put("Email_add", request.getParameter("Email_add"));

    // 暗号化処理
    AESUtil aes = new AESUtil();
    for (HashMap.Entry<String, String> entry : map.entrySet()) {
      if (entry.getValue() != null) {
        String de = aes.encode(entry.getValue(), "6b4d2cfd8505535c");
        map.put(entry.getKey(), de);
      }
    }

    MultiValueMap<String, String> paramMap = new LinkedMultiValueMap<String, String>();
    for (HashMap.Entry<String, String> entry : map.entrySet()) {
      paramMap.add(entry.getKey(), entry.getValue());
    }

    RestTemplate template = new RestTemplate();
    String result = template.postForObject(
        "https://ohp-st.sompo-japan.co.jp/api/off_inquiry_interface", paramMap, String.class);

    model.addAttribute("message",
        "returnCode: " + result + "(" + CD106.decode(result).getName() + ")");

    return getViewName("/st_off_inquiry_i");
  }

  @RequestMapping(value = "/st_specifyagent_i", method = RequestMethod.GET)
  public String st_specifyagent_i() {
    return getViewName("/st_specifyagent_i");
  }

  @RequestMapping(value = "/st_specifyagent_i", method = RequestMethod.POST)
  public String st_specifyagent_i(HttpServletRequest request, Model model) {

    String zipCD = request.getParameter("zipCD");
    String processDatetime = "20210519093030";
    String strAccessKey = "sdm8ybk2vm2ex77m" + processDatetime + zipCD;
    String md5AccessKey = DigestUtils.md5DigestAsHex(strAccessKey.getBytes());

    GetSpecifyAgentInputForm params = new GetSpecifyAgentInputForm();
    params.setAccessKey(md5AccessKey);
    params.setProcessDateTime(processDatetime);
    params.setZipCD(zipCD);

    RestTemplate template = new RestTemplate();
    GetSpecifyAgentResultForm result =
        template.postForObject("https://ohp-st.sompo-japan.co.jp/api/specifyagent_interface",
            params, GetSpecifyAgentResultForm.class);

    model.addAttribute("message", "returnCode: " + result.toString());

    return getViewName("/st_specifyagent_i");
  }

}

