package com.example.demo.web.controller;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import javax.servlet.http.HttpServletRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class Data extends ControllerBase {

  @RequestMapping(value = "/data", method = RequestMethod.GET)
  public String data1(Model model) {
    String txtContents = "";

    try {
      File file = new File("/tmp/data.txt");
      FileReader filereader = new FileReader(file);

      int ch;
      while ((ch = filereader.read()) != -1) {
        txtContents = txtContents + (char) ch;
      }

      filereader.close();
    } catch (IOException e) {
      e.printStackTrace();
    }

    model.addAttribute("txtContents", txtContents);
    return getViewName("/data");
  }

  @RequestMapping(value = "/data", method = RequestMethod.POST)
  public String data2(HttpServletRequest request, Model model) {
    String txtContents = request.getParameter("txtContents");

    try {
      Files.deleteIfExists(Paths.get("/tmp/data.txt"));
      Path tmpPath = Files.createFile(Paths.get("/tmp/data.txt"));
      File file = tmpPath.toFile();

      // ファイルに書き込み
      FileWriter fw = new FileWriter(file, true);
      BufferedWriter bw = new BufferedWriter(fw);
      PrintWriter pw = new PrintWriter(bw);
      pw.write(txtContents);
      pw.flush();
      pw.close();
    } catch (IOException e) {
      e.printStackTrace();
    }

    model.addAttribute("txtContents", txtContents);
    return getViewName("/data");
  }

}

