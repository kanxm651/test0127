package com.example.demo.web.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.web.common.CCrypt;

@RestController
public class CCryptAPI {

  @RequestMapping("/ccrypt")
  public String ccrypt(HttpServletRequest request) {
    return CCrypt.Encrypt(request.getParameter("kokyaku_no"));
  }

}

