package jp.co.sj.xop.batch.common;

import java.util.HashMap;
import java.util.List;
import jp.co.sj.xop.batch.common.constants.Constants;
import net.sf.json.JSONNull;

public class ConvertUtil {

  /**
   * ファイルデータ作成（組合せ）
   */
  @SuppressWarnings("unlikely-arg-type")
  public static String StringMosaic(List<String> list, HashMap<String, String> map, String divider)
      throws Exception {
    StringBuffer sf = new StringBuffer();
    // ファイル項目定義リストがnullの場合、エラー
    if (list == null || list.size() == 0) {
      throw new Exception();
    }
    // データConvert結果配列がnullまた０件の場合
    if (map == null || map.size() == 0) {
      // ""をリターン
      return Constants.EMPTY;
    }
    // ファイル組み合わせ利用dividerがnullの場合、エラー
    if (divider == null) {
      throw new Exception();
    }
    // ファイル項目定義より、データを組み合わせる
    for (int i = 0; i < list.size(); i++) {
      String key = list.get(i);
      if (JSONNull.getInstance().equals(map.get(key))) {
        sf.append(Constants.EMPTY);
      } else {
        sf.append(map.get(key));
      }
      if (i < list.size() - 1) {
        if (!(Constants.START.equals(map.get(key))
            || Constants.END.equals(map.get(list.get(i + 1))))) {
          sf.append(divider);
        }
      }
    }
    return sf.toString();
  }

  /**
   * ファイルデータ作成（データを""付けて組合せ）
   */
  @SuppressWarnings("unlikely-arg-type")
  public static String StringMosaiWithQuotes(List<String> list, HashMap<String, String> map,
      String divider) throws Exception {
    StringBuffer sf = new StringBuffer();
    // ファイル項目定義リストがnullの場合、エラー
    if (list == null || list.size() == 0) {
      throw new Exception();
    }
    // データConvert結果配列がnullまた０件の場合
    if (map == null || map.size() == 0) {
      return Constants.EMPTY;
    }
    // ファイル組み合わせ利用dividerがnullの場合、エラー
    if (divider == null) {
      throw new Exception();
    }
    // ファイル項目定義より、データを組み合わせる
    for (int i = 0; i < list.size(); i++) {
      String key = list.get(i);
      if (JSONNull.getInstance().equals(map.get(key))) {
        sf.append(StringUtil.addQuotes(Constants.EMPTY));
      } else {
        sf.append(StringUtil.addQuotes(map.get(key)));
      }
      if (i < list.size() - 1) {
        if (!(Constants.START.equals(map.get(key))
            || Constants.END.equals(map.get(list.get(i + 1))))) {
          sf.append(divider);
        }
      }
    }
    return sf.toString();
  }


}
