package jp.co.sj.xop.batch.listener;

import org.springframework.stereotype.Component;

/**
 * 集配信システムへファイル転送（火災保険加入相談）バッチの Read前後に実施する処理。
 *
 * @author SSD 曾洋
 *
 */
@Component
public class FireInsuranceExportItemReadListener extends BaseItemReadListener {

}
