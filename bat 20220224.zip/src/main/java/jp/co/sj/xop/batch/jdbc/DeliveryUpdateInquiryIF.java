package jp.co.sj.xop.batch.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.HashMap;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import jp.co.sj.xop.batch.common.constants.Constants;
import jp.co.sj.xop.batch.service.SqlLoaderService;
import jp.co.sj.xop.batch.service.SystemTimestampService;

/**
 * お問合せ集配信F転テーブルを更新するのUPDATEクラス.
 *
 * @author SSD 曾洋
 *
 */

public class DeliveryUpdateInquiryIF extends BaseUpdate {
  /**
   * SQLファイルローダー
   */
  @Autowired
  SqlLoaderService sqlLoaderService;

  private PreparedStatement preStmt = null;

  /**
   * Update実行するメソッドを呼び出す.
   *
   * @return Map
   * @throws Exception
   */

  @SuppressWarnings("rawtypes")
  @Override
  protected Map subExecute(Map<String, String> map, Connection conn,
      SqlLoaderService sqlLoaderService)
      throws Exception {

    int updateCount = 0;
    Map<String, String> upTBCount = new HashMap<String, String>();
    SystemTimestampService systemTimestampService = new SystemTimestampService();
    String updateTime = systemTimestampService.getDateTime();
    String tbName = Constants.EMPTY;
    try {
      if (map != null) {
        conn.setAutoCommit(false);

        for (String key : map.keySet()) {
          tbName = map.get(key);
          String sql = "UPDATE " + tbName + " SET shuhai_send_flag = ?,"
              + "shuhai_send_datetime = (to_timestamp(?,'yyyymmdd hh24:mi:ss')) "
              + "WHERE form_code=? and insert_number=? ";
          preStmt = conn.prepareStatement(sql);
          preStmt.setString(1, "1");
          preStmt.setString(2, updateTime);
          preStmt.setString(3, key.substring(0, 2));
          preStmt.setString(4, key.substring(2));

          updateCount = preStmt.executeUpdate();
          if (updateCount != 0) {
            if (upTBCount.get(map.get(key)) != null) {
              upTBCount.put(map.get(key),
                  String.valueOf(Integer.valueOf(upTBCount.get(map.get(key))) + 1));
            } else {
              upTBCount.put(map.get(key), "1");
            }
          }
        }
        conn.commit();
      }
    } finally {
        preStmt.close();
    }
    return upTBCount;

  }
}
