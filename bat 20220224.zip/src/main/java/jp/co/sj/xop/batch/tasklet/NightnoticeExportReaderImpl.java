package jp.co.sj.xop.batch.tasklet;

import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Component;

/**
 * 夜間バッチ通知メール送信バッチ 取得処理
 *
 * @author SSD
 *
 */
@Component
public class NightnoticeExportReaderImpl extends BaseReaderImpl {

  public NightnoticeExportReaderImpl() {
    Map<String, String> readFunctionMap = new HashMap<String, String>();
    readFunctionMap.put("jp.co.sj.xop.batch.jdbc.NightNoticeGetMailAddress", "query");

    super.setReadFunctionMap(readFunctionMap);
  }

}
