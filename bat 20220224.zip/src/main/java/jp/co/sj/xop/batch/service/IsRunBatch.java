package jp.co.sj.xop.batch.service;

import java.sql.Timestamp;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;
import jp.co.sj.xop.batch.common.DateTimeUtil;
import jp.co.sj.xop.batch.common.LocalDateTimeEx;
import jp.co.sj.xop.batch.common.StringUtil;
import jp.co.sj.xop.batch.common.constants.DateTimeConstants;

/**
 *
 * バッチ計画停止有無チェック
 *
 * @author SSD
 *
 */

@Component
public class IsRunBatch {

  /**
   * メッセージソース.
   */
  @Autowired
  MessageSource messagesource;

  /**
   * 計画停止リスト
   */
  private String BatchStopList = System.getenv("BATCH_STOP_LIST");

  /**
   * 計画停止時間帯
   */
  private String BatchStopPeriod = System.getenv("BATCH_STOP_PERIOD");

  /**
   * バッチ計画停止有無チェック.
   *
   * @return チェック結果（true:計画停止有、false:計画停止無）
   */
  public boolean isBatchOutage(String BatchName) {

    // システム日時を取得
    // システム時間取得
    Timestamp nowTimestamp = Timestamp.valueOf(LocalDateTimeEx.now());
    String now = DateTimeUtil.format(nowTimestamp, DateTimeConstants.DATETIMEFORMAT_DATETIME);
    if (!StringUtil.isNullOrEmpty(BatchStopList) && !StringUtil.isNullOrEmpty(BatchStopPeriod)) {
      // 計画停止時間帯分離処理
      String[] period = BatchStopPeriod.split("～");
      // 計画停止リスト分離処理
      String[] list = BatchStopList.split(",");
      // システム日時が「計画停止時間帯」の範囲内
      if (now.compareTo(period[0]) >= 0 && now.compareTo(period[1]) <= 0) {
        for (String name : list) {
          // 当該batchが「計画停止リスト」に存在している場合
          if (BatchName.equals(name)) {
            return true;
          }
        }
      }
    }
    return false;
  }
}


