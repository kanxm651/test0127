package jp.co.sj.xop.batch.listener;

import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.stereotype.Component;

/**
 * step処理の前後に実施する処理
 *
 * @author SSD
 *
 */
@Component
public class BaseStepListener implements StepExecutionListener {

  @Override
  public void beforeStep(StepExecution stepExecution) {}

  @Override
  public ExitStatus afterStep(StepExecution stepExecution) {
    return stepExecution.getExitStatus();
  }

}

