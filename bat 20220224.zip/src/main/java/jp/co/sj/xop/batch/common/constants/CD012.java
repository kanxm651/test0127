package jp.co.sj.xop.batch.common.constants;

/**
 * CD012:連絡先の電話番号区分の列挙クラス
 *
 * @author SSD
 *
 */
public enum CD012 implements Encodable<String> {
  /**
   * 勤務先
   */
  CONTACT_CLASSIFY_HOME("1", "自宅"),
  /**
   * 携帯電話
   */
  CONTACT_CLASSIFY_OFFICE("2", "勤務先"),
  /**
   * その他
   */
  CONTACT_CLASSIFY_MOBILE("3", "携帯電話");

  /** デコーダー */
  private static final Decoder<String, CD012> DECODER = Decoder.create(values());

  /** コード値 */
  private final String code;

  /** 名称 */
  private final String name;

  /**
   * コンストラクタ.
   *
   * @param code コード値
   * @param name 名称
   */
  private CD012(String code, String name) {
    this.code = code;
    this.name = name;
  }

  @Override
  public String getCode() {
    return code;
  }

  /**
   * コード値からEnumクラスを取得する.
   *
   * @param code コード値
   * @return 受領形式Enumクラス
   */
  public static CD012 decode(String code) {
    return DECODER.decode(code);
  }

  /**
   * 名称を取得するメソッド.
   *
   * @return 名称
   */
  public String getName() {
    return name;
  }
}

