package jp.co.sj.xop.batch.jdbc;

import java.sql.Connection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.stereotype.Component;
import jp.co.sj.xop.batch.service.SqlLoaderService;

/**
 * データUpdateクラス
 *
 * @author SSD
 */
@Component
public class BaseUpdate {

  /**
   * Update実行メソッド
   *
   * @return result
   * @throws Exception
   */
  @SuppressWarnings({"rawtypes", "unchecked"})
  public int execute(List list, Connection conn, SqlLoaderService sqlLoaderService)
      throws Exception {
    int result = 0;
    try {
      result = subExecute(list, conn, sqlLoaderService);
    } catch (Exception e) {
      conn.rollback();
      throw e;
    }
    return result;
  }

  /**
   * Update実行メソッド
   *
   * @return int
   * @throws Exception
   */
  protected int subExecute(List<String> list, Connection conn, SqlLoaderService sqlLoaderService)
      throws Exception {
    return 0;
  }

  /**
   * Update実行メソッド
   *
   * @return result
   * @throws Exception
   */
  @SuppressWarnings({"rawtypes"})
  public Map execute(Map<String, String> map, Connection conn, SqlLoaderService sqlLoaderService)
      throws Exception {
    Map result = null;
    try {
      result = subExecute(map, conn, sqlLoaderService);
    } catch (Exception e) {
      conn.rollback();
      throw e;
    }
    return result;
  }

  /**
   * Update実行メソッド
   *
   * @return int
   * @throws Exception
   */
  @SuppressWarnings("rawtypes")
  protected Map subExecute(Map<String, String> map, Connection conn,
      SqlLoaderService sqlLoaderService) throws Exception {
    return new HashMap();
  }

}
