package jp.co.sj.xop;

import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import jp.co.sj.xop.batch.listener.NightnoticeExportItemProcessListener;
import jp.co.sj.xop.batch.listener.NightnoticeExportItemReadListener;
import jp.co.sj.xop.batch.listener.NightnoticeExportItemWriteListener;
import jp.co.sj.xop.batch.listener.NightnoticeExportJobListener;
import jp.co.sj.xop.batch.listener.NightnoticeExportStepListener;
import jp.co.sj.xop.batch.tasklet.NightnoticeExportDataProcessor;
import jp.co.sj.xop.batch.tasklet.NightnoticeExportDataReader;
import jp.co.sj.xop.batch.tasklet.NightnoticeExportDataWriter;

/**
 * 夜間バッチ通知メール送信バッチ controllerクラス
 *
 * @author SSD
 *
 */
@EnableBatchProcessing
@EnableAutoConfiguration
@ComponentScan
public class NightnoticeExportController extends BaseController {

  @Autowired
  public JobBuilderFactory jobBuilderFactory;

  /**
   * リスナー定義
   */
  @Autowired
  private NightnoticeExportItemProcessListener nightnoticeExportItemProcessListener;
  @Autowired
  private NightnoticeExportItemReadListener nightnoticeExportItemReadListener;
  @Autowired
  private NightnoticeExportItemWriteListener nightnoticeExportItemWriteListener;
  @Autowired
  private NightnoticeExportJobListener nightnoticeExportJobListener;
  @Autowired
  private NightnoticeExportStepListener nightnoticeExportStepListener;

  /**
   * 取得処理定義
   */
  @Autowired
  private NightnoticeExportDataReader nightnoticeExportDataReader;
  /**
   * 編集処理定義
   */
  @Autowired
  private NightnoticeExportDataProcessor nightnoticeExportDataProcessor;
  /**
   * 出力処理定義
   */
  @Autowired
  private NightnoticeExportDataWriter nightnoticeExportDataWriter;

  /**
   * mainメソッド
   *
   * @param args 引数
   */
  public static void main(String[] args) throws Exception {
    SpringApplication.run(NightnoticeExportController.class, args);
  }

  /**
   * Job実行メソッド
   *
   * @return Job
   * @throws Exception
   */
  @Bean(name = "NightnoticeExportBatchJob")
  public Job NightnoticeExportBatchJob(JobBuilderFactory jobBuilderFactory) throws Exception {
    // 夜間バッチ通知メール送信Jobの取得データセット
    super.setBaseDataRead(nightnoticeExportDataReader);
    // 夜間バッチ通知メール送信Jobの編集データセット
    super.setBaseDataProcessor(nightnoticeExportDataProcessor);
    // 夜間バッチ通知メール送信Jobの出力データセット
    super.setBaseDataWriter(nightnoticeExportDataWriter);
    // 夜間バッチ通知メール送信JobのStepリスナーセット
    super.setBaseStepListener(nightnoticeExportStepListener);
    // 夜間バッチ通知メール送信JobのReadリスナーセット
    super.setBaseItemReadListener(nightnoticeExportItemReadListener);
    // 夜間バッチ通知メール送信JobのProcessリスナーセット
    super.setBaseItemProcessListener(nightnoticeExportItemProcessListener);
    // 夜間バッチ通知メール送信JobのWriteリスナーセット
    super.setBaseItemWriteListener(nightnoticeExportItemWriteListener);
    // 夜間バッチ通知メール送信Jobを実行
    return jobBuilderFactory.get("NightnoticeExportBatchJob").incrementer(new RunIdIncrementer())
        // step処理開始
        .preventRestart().start(stepExecution())
        // 正常の場合、ステータスと終了コードを取得、Job完了
        .on(ExitStatus.COMPLETED.getExitCode()).end()
        // 異常した場合、ステータスと終了コードを取得、Job完了
        .on(ExitStatus.FAILED.getExitCode()).fail().end()
        // 夜間バッチ通知メール送信Jobリスナーセット
        .listener(nightnoticeExportJobListener)
        // Job実行
        .build();
  }
}
