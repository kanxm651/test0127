package jp.co.sj.xop.batch.tasklet;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import javax.sql.DataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.ItemStreamException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;
import jp.co.sj.xop.batch.common.constants.Constants;
import jp.co.sj.xop.batch.jdbc.BaseQuery;
import jp.co.sj.xop.batch.jdbc.FileDelGetTblData;
import jp.co.sj.xop.batch.service.SqlLoaderService;
import jp.co.sj.xop.batch.service.SystemTimestampService;
import net.sf.json.JSONObject;
import net.sf.json.JsonConfig;
import net.sf.json.util.CycleDetectionStrategy;

/**
 * 不要ファイル削除バッチ 取得処理
 *
 * @author SSD
 *
 */
@Component
public class S3FileDelReader extends BaseDataRead {
  private ExecutionContext executionContext;
  // インデックス
  private int idx = 0;
  // 初回処理かどうかのフラグ
  private boolean firstFlag = true;
  // 不要ファイル取得リスト
  ArrayList<HashMap<String, String>> fileDelQueryArray = null;
  // 不要ファイル取得配列
  HashMap<String, String> fileDelMap = null;
  // バチ状態
  private String key = "read";
  private Connection conn = null;

  @Autowired
  public DataSource dataSource;

  @Autowired
  public SystemTimestampService systemTimestampService;

  @Autowired
  public SqlLoaderService sqlLoaderService;

  /**
   * ロガー.
   */
  private static final Logger logger = LoggerFactory.getLogger(S3FileDelReader.class);

  /**
   * メッセージソース
   */
  @Autowired
  private MessageSource messagesource;

  @Override
  public void open(ExecutionContext executionContext) throws ItemStreamException {
    this.executionContext = executionContext;
  }

  /**
   * 不要ファイル削除管理テーブルから、不要ファイルを抽出処理
   *
   */
  @Override
  public Object read() throws Exception {
    Map<String, String> map = new HashMap<String, String>();
    if (executionContext != null) {
      if (firstFlag) {
        conn = dataSource.getConnection();
        // 不要ファイル削除バッチが既に正常に実行されている場合
        // ログを出力し、処理を正常終了する。
        IsRunSchedular.setLogHead(Constants.S3_FILE_JOB_NAME_JAP);
        if (IsRunSchedular.isRunSchedularinDay(Constants.S3_FILE_JOB_NAME_ENG,
            Constants.BATCH_COMPLETED)) {
          return null;
        }
        // 不要ファイル削除管理テーブルにデータを取得する
        BaseQuery bq = new FileDelGetTblData();
        fileDelQueryArray = bq.query(null, conn, sqlLoaderService, messagesource);
        firstFlag = false;
      }
      if (fileDelQueryArray == null || fileDelQueryArray.size() == 0) {
        // データが取得しない または 0件取得の場合、処理を中止する。
        String errorMessage = messagesource.getMessage("message.LOGMSG0023I",
            new String[] {Constants.TBNAME_FILE_DEL, Constants.EMPTY}, Locale.JAPAN);
        logger.info(errorMessage);
        throw new Exception(errorMessage);
      } else {
        if (fileDelQueryArray.size() == idx + 1) {
          // 終了の場合、状態をセット（「end」を付ける）
          key = key + "end";
        }
        if (fileDelQueryArray.size() == idx) {
          conn.close();
          return null;
        }
        fileDelMap = fileDelQueryArray.get(idx);
        idx++;
      }
      try {
        // 取得データをJson型に転換する
        HashMap<String, ArrayList<HashMap<String, String>>> result =
            new HashMap<String, ArrayList<HashMap<String, String>>>();
        ArrayList<HashMap<String, String>> subResult = new ArrayList<HashMap<String, String>>();
        subResult.add(fileDelMap);
        result.put("jp.co.sj.xop.batch.jdbc.FileDelQuery", subResult);
        JsonConfig jsonConfig = new JsonConfig();
        jsonConfig.setCycleDetectionStrategy(CycleDetectionStrategy.LENIENT);
        JSONObject object = JSONObject.fromObject(result, jsonConfig);
        map.put(key, object.toString());
        return map;
      } catch (Exception e) {
        // エラーの場合、状態をセット（「error」を付ける）
        key = key + "error";
        map = new HashMap<String, String>();
        map.put(key, fileDelMap.get("FILE_NAME_JA"));
        return map;
      }
    }
    return map;
  }
}


