package jp.co.sj.xop.batch.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import jp.co.sj.xop.batch.common.constants.Constants;
import jp.co.sj.xop.batch.service.SqlLoaderService;

/**
 * 美術館英語お問合せデータを取得するのQueryクラス.
 *
 * @author SSD 曾洋
 *
 */
@Component
public class NightNoticeGetDataEnMuseumInquiry extends BaseQuery {

  private PreparedStatement preStmt = null;
  private ResultSet rs = null;

  /**
   * SQLファイルローダー
   */
  @Autowired
  SqlLoaderService sqlLoaderService;

  public NightNoticeGetDataEnMuseumInquiry() {
    super.setMsgHead(Constants.TBNAME_EN_MU_INQUIRY);
  }

  /**
   * Query実行するメソッドを呼び出す.
   *
   * @return ArrayList
   * @throws Exception
   */
  @Override
  protected ArrayList<HashMap<String, String>> subQuery(Map<String, String> condition,
      Connection conn, SqlLoaderService sqlLoaderService) throws Exception {
    ArrayList<HashMap<String, String>> result = new ArrayList<HashMap<String, String>>();
    // SQLを取得
    String sql = sqlLoaderService.getSql("NightNoticeGetDataEnMuseumInquiry");
    try {
      preStmt = conn.prepareStatement(sql);
      preStmt.setString(1, "0");
      preStmt.setString(2, condition.get("FORM_CODE"));
      preStmt.setString(3, condition.get("SYSTEM_TIME"));
      rs = preStmt.executeQuery();
      while (rs.next()) {
        // リターン結果にDBから取得したカラム値をセットする
        HashMap<String, String> recMap = new HashMap<String, String>();
        recMap.put("FORM_CODE", rs.getString("FORM_CODE"));
        recMap.put("INSERT_NUMBER", rs.getString("INSERT_NUMBER"));
        recMap.put("INSERT_DATETIME", rs.getString("INSERT_DATETIME"));
        recMap.put("EMAIL_ADD", rs.getString("EMAIL_ADD"));
        recMap.put("CONTENTS", rs.getString("CONTENTS"));
        recMap.put("FIRSTNAME", rs.getString("FIRSTNAME"));
        recMap.put("LASTNAME", rs.getString("LASTNAME"));
        recMap.put("AGE", rs.getString("AGE"));
        recMap.put("ADDRESS_ENG", rs.getString("ADDRESS_ENG"));
        result.add(recMap);
      }
    } finally {
      rs.close();
      preStmt.close();
    }
    return result;
  }

}
