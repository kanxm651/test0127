package jp.co.sj.xop.batch.tasklet;

import java.sql.Connection;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import javax.sql.DataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.ItemStreamException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;
import jp.co.sj.xop.batch.common.DateTimeUtil;
import jp.co.sj.xop.batch.common.LocalDateTimeEx;
import jp.co.sj.xop.batch.common.ParamConvert;
import jp.co.sj.xop.batch.common.constants.Constants;
import jp.co.sj.xop.batch.common.constants.DateTimeConstants;
import jp.co.sj.xop.batch.jdbc.BaseQuery;
import jp.co.sj.xop.batch.jdbc.DeliveryGetDataFireInsurance;
import jp.co.sj.xop.batch.service.S3Services;
import jp.co.sj.xop.batch.service.SqlLoaderService;
import net.sf.json.JSONObject;
import net.sf.json.JsonConfig;
import net.sf.json.util.CycleDetectionStrategy;

/**
 * 集配信システムへファイル転送（火災保険加入相談）についてのデータを取得
 *
 * @author SSD 曾
 *
 */
@Component
public class FireInsuranceExportDataReader extends BaseDataRead {
  private ExecutionContext executionContext;
  // 初回処理かどうかのフラグ
  private boolean firstFlag = true;
  // 火災保険加入相談テーブル（t_fire_insurance_inquiry）データ取得の配列
  ArrayList<HashMap<String, String>> fireInsuranceQueryArray = null;
  // 火災保険加入相談集配信F転テーブル（ t_fire_insurance_inquiry_shuhai 廃棄）データに転換の配列
  ArrayList<HashMap<String, String>> shuhaiQueryArray = null;
  // 火災保険加入相談の配列
  Map<String, String> fireInsuranceMap = null;
  // システム時間取得
  Timestamp nowTimestamp = Timestamp.valueOf(LocalDateTimeEx.now());
  String sys_date = DateTimeUtil.format(nowTimestamp, DateTimeConstants.DATETIMEFORMAT_DATE_TIME);
  // バチ状態
  private String key = "readend";
  private Connection conn = null;

  @Autowired
  S3Services s3Services;

  @Autowired
  public DataSource dataSource;

  @Autowired
  SqlLoaderService sqlLoaderService;

  /**
   * ロガー.
   */
  private static final Logger logger = LoggerFactory.getLogger(FireInsuranceExportDataReader.class);

  /**
   * メッセージソース.
   */
  @Autowired
  private MessageSource messagesource;

  @Override
  public void open(ExecutionContext executionContext) throws ItemStreamException {
    this.executionContext = executionContext;
  }

  /**
   * データを抽出する
   *
   */
  @Override
  public Object read() throws Exception {
    Map<String, String> map = new HashMap<String, String>();
    if (executionContext != null) {
      if (firstFlag) {
        conn = dataSource.getConnection();
        // 集配信システムへファイル転送（火災保険加入相談）バッチが既に正常に実行されている場合
        // ログを出力し、処理を正常終了する。
        IsRunSchedular.setLogHead(Constants.FIRE_INSURANCE_EXPORT_JOB_NAME_JAP);
        if (IsRunSchedular.isRunSchedularInHour(Constants.FIRE_INSURANCE_EXPORT_JOB_NAME_ENG,
            Constants.BATCH_COMPLETED)) {
          return null;
        } else if (s3Services.isFileExists(
            Constants.FILE_PATH_FIRE + Constants.FILE_NAME_FIRE + Constants.FILE_TYPE_TXT)) {
          logger.info(messagesource.getMessage("message.LOGMSG0003I",
              new String[] {Constants.FIRE_INSURANCE_EXPORT_JOB_NAME_JAP}, Locale.JAPAN));
          return null;
        }
        // SQL文の時間条件設定
        Map<String, String> condition = new HashMap<String, String>();
        condition.put("SYSTEM_TIME", sys_date);
        // 火災保険加入相談テーブル（t_fire_insurance_inquiry）データ取得
        BaseQuery bq = new DeliveryGetDataFireInsurance();
        fireInsuranceQueryArray = bq.query(condition, conn, sqlLoaderService, messagesource);
        if (fireInsuranceQueryArray == null || fireInsuranceQueryArray.size() == 0) {
          // データが取得しない または 0件取得の場合、ログを出力
          logger.info(messagesource.getMessage("message.LOGMSG0023I",
              new String[] {Constants.FIRE_INSURANCE, Constants.EMPTY}, Locale.JAPAN));
        }
        shuhaiQueryArray = ParamConvert.getFireInsurance(fireInsuranceQueryArray);
        firstFlag = false;
      } else {
        conn.close();
        return null;
      }
      // 取得データをJson型に転換する
      HashMap<String, ArrayList<HashMap<String, String>>> resultSet =
          new HashMap<String, ArrayList<HashMap<String, String>>>();
      resultSet.put("jp.co.sj.xop.batch.jdbc.FireInsuranceQuery", shuhaiQueryArray);
      JsonConfig jsonConfig = new JsonConfig();
      jsonConfig.setCycleDetectionStrategy(CycleDetectionStrategy.LENIENT);
      JSONObject object = JSONObject.fromObject(resultSet, jsonConfig);
      String result = object.toString();
      map.put(key, result);
    }
    return map;
  }
}
