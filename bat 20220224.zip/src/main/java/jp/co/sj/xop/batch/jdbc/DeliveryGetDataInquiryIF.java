package jp.co.sj.xop.batch.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import jp.co.sj.xop.batch.common.constants.Constants;
import jp.co.sj.xop.batch.service.SqlLoaderService;

/**
 * お問合せデータを取得するのQueryクラス.
 *
 * @author SSD 曾洋
 *
 */
@Component
public class DeliveryGetDataInquiryIF extends BaseQuery {

  private PreparedStatement preStmt = null;
  private ResultSet rs = null;

  /**
   * SQLファイルローダー
   */
  @Autowired
  SqlLoaderService sqlLoaderService;

  public DeliveryGetDataInquiryIF() {
    super.setMsgHead(Constants.TBNAME_INQUIRY);
  }

  /**
   * Query実行するメソッドを呼び出す.
   *
   * @return ArrayList
   * @throws Exception
   */
  @Override
  protected ArrayList<HashMap<String, String>> subQuery(Map<String, String> condition,
      Connection conn, SqlLoaderService sqlLoaderService) throws Exception {
    ArrayList<HashMap<String, String>> result = new ArrayList<HashMap<String, String>>();
    // SQLを取得
    String sql = sqlLoaderService.getSql("DeliveryGetDataInquiryIF");
    try {
      preStmt = conn.prepareStatement(sql);
      preStmt.setString(1, "0");
      preStmt.setString(2, condition.get("FORM_CODE"));
      preStmt.setString(3, condition.get("SYSTEM_TIME"));
      rs = preStmt.executeQuery();
      while (rs.next()) {
        // リターン結果にDBから取得したカラム値をセットする
        HashMap<String, String> recMap = new HashMap<String, String>();
        recMap.put("FORM_CODE", rs.getString("FORM_CODE"));
        recMap.put("INSERT_NUMBER", rs.getString("INSERT_NUMBER"));
        recMap.put("INSERT_DATETIME", rs.getString("INSERT_DATETIME"));
        recMap.put("CUSTOMER_NUMBER", rs.getString("CUSTOMER_NUMBER"));
        recMap.put("RECEPTION_DIV", rs.getString("RECEPTION_DIV"));
        recMap.put("INQUIRY_NAME", rs.getString("INQUIRY_NAME"));
        recMap.put("EXCHANGE", rs.getString("EXCHANGE"));
        recMap.put("BOND_NUMBER", rs.getString("BOND_NUMBER"));
        recMap.put("CONTENTS", rs.getString("CONTENTS"));
        recMap.put("CUSTOMER_DIV", rs.getString("CUSTOMER_DIV"));
        recMap.put("LASTNAME", rs.getString("LASTNAME"));
        recMap.put("FIRSTNAME", rs.getString("FIRSTNAME"));
        recMap.put("LASTNAME_KANA", rs.getString("LASTNAME_KANA"));
        recMap.put("FIRSTNAME_KANA", rs.getString("FIRSTNAME_KANA"));
        recMap.put("BIRTHDAY", rs.getString("BIRTHDAY"));
        recMap.put("SEX", rs.getString("SEX"));
        recMap.put("ZIP_CODE", rs.getString("ZIP_CODE"));
        recMap.put("ADDRESS_PREF", rs.getString("ADDRESS_PREF"));
        recMap.put("ADDRESS1", rs.getString("ADDRESS1"));
        recMap.put("ADDRESS2", rs.getString("ADDRESS2"));
        recMap.put("ADDRESS3", rs.getString("ADDRESS3"));
        recMap.put("TEL_HOME", rs.getString("TEL_HOME"));
        recMap.put("TEL_CONTACT", rs.getString("TEL_CONTACT"));
        recMap.put("CONTACT_CLASSIFY", rs.getString("CONTACT_CLASSIFY"));
        recMap.put("EMAIL_ADD", rs.getString("EMAIL_ADD"));
        recMap.put("COMPANY", rs.getString("COMPANY"));
        recMap.put("DEPARTMENT", rs.getString("DEPARTMENT"));
        recMap.put("INDUSTRY", rs.getString("INDUSTRY"));
        result.add(recMap);
      }
    } finally {
      rs.close();
      preStmt.close();
    }
    return result;
  }

}
