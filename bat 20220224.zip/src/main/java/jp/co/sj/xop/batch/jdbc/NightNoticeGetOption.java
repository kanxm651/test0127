package jp.co.sj.xop.batch.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Component;
import jp.co.sj.xop.batch.common.constants.Constants;
import jp.co.sj.xop.batch.service.SqlLoaderService;

/**
 * 夜間バッチ通知メールバッチ オプションテーブルからデータ取得Queryクラス
 *
 * @author SSD
 *
 */
@Component
public class NightNoticeGetOption extends BaseQuery {

  private PreparedStatement preStmt = null;
  private ResultSet rs = null;

  public NightNoticeGetOption() {
    super.setMsgHead(Constants.TBNAME_OPTION);
  }

  /**
   * Query実行メソッド
   *
   * @return ArrayList
   * @throws Exception
   */
  @Override
  protected ArrayList<HashMap<String, String>> subQuery(Map<String, String> condition,
      Connection conn, SqlLoaderService sqlLoaderService) throws Exception {
    ArrayList<HashMap<String, String>> result = new ArrayList<HashMap<String, String>>();
    // SQLを取得
    String sql = sqlLoaderService.getSql("NightNoticeGetOption");
    try {
      preStmt = conn.prepareStatement(sql);
      preStmt.setString(1, "1");
      rs = preStmt.executeQuery();
      while (rs.next()) {
        // リターン結果にDBから取得したカラム値をセットする
        HashMap<String, String> recMap = new HashMap<String, String>();
        recMap.put("FORM_CODE", rs.getString("FORM_CODE"));
        recMap.put("RETURN_MAIL", rs.getString("RETURN_MAIL"));
        recMap.put("INFORM_MAIL", rs.getString("INFORM_MAIL"));
        recMap.put("CSV_MAIL", rs.getString("CSV_MAIL"));
        recMap.put("CSV_MAIL_SUBJECT", rs.getString("CSV_MAIL_SUBJECT"));
        result.add(recMap);
      }
    } finally {
        rs.close();
        preStmt.close();
    }
    return result;
  }


}
