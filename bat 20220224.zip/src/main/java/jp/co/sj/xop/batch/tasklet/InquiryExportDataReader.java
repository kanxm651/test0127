package jp.co.sj.xop.batch.tasklet;

import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import javax.sql.DataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.ItemStreamException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;
import jp.co.sj.xop.batch.common.DateTimeUtil;
import jp.co.sj.xop.batch.common.LocalDateTimeEx;
import jp.co.sj.xop.batch.common.constants.Constants;
import jp.co.sj.xop.batch.common.constants.DateTimeConstants;
import jp.co.sj.xop.batch.jdbc.BaseQuery;
import jp.co.sj.xop.batch.jdbc.DeliveryGetDataOption;
import jp.co.sj.xop.batch.service.S3Services;
import jp.co.sj.xop.batch.service.SqlLoaderService;
import net.sf.json.JSONObject;
import net.sf.json.JsonConfig;
import net.sf.json.util.CycleDetectionStrategy;

/**
 * 集配信システムへファイル転送（お問合せ）についてのデータを取得
 *
 * @author SSD 曾
 *
 */
@Component
public class InquiryExportDataReader extends BaseDataRead {
  private ExecutionContext executionContext;
  // 初回処理かどうかのフラグ
  private boolean firstFlag = true;
  // オプションテーブル（m_option）データ取得の配列
  ArrayList<HashMap<String, String>> optionQueryArray = null;
  // オプションデータ取得配列
  Map<String, String> optionMap = null;
  // お問合せテーブル（t_inquiry_interface）データ取得の配列
  ArrayList<HashMap<String, String>> inquiryQueryArray = null;
  // お問合せ集配信F転テーブル(t_inquiry_shuhai 廃棄) データに転換の配列
  ArrayList<HashMap<String, String>> shuhaiArray = null;
  // お問合せの配列
  Map<String, String> inquiryMap = null;
  // バチ状態
  private String key = "readend";
  // システム時間取得
  Timestamp nowTimestamp = Timestamp.valueOf(LocalDateTimeEx.now());
  String sys_date = DateTimeUtil.format(nowTimestamp, DateTimeConstants.DATETIMEFORMAT_DATE_TIME);
  private Connection conn = null;
  HashMap<String, String> tableName = new HashMap<String, String>();
  ArrayList<HashMap<String, String>> tableNameList = new ArrayList<HashMap<String, String>>();
  @Autowired
  S3Services s3Services;

  @Autowired
  public DataSource dataSource;

  @Autowired
  SqlLoaderService sqlLoaderService;

  /**
   * ロガー.
   */
  private static final Logger logger = LoggerFactory.getLogger(InquiryExportDataReader.class);

  /**
   * メッセージソース.
   */
  @Autowired
  private MessageSource messagesource;

  @Override
  public void open(ExecutionContext executionContext) throws ItemStreamException {
    this.executionContext = executionContext;
  }

  /**
   * データを抽出する
   *
   */
  @SuppressWarnings("unchecked")
  @Override
  public Object read() throws Exception {
    Map<String, String> map = new HashMap<String, String>();
    if (executionContext != null) {
      if (firstFlag) {
        conn = dataSource.getConnection();
        // 集配信システムへファイル転送（お問合せ）バッチが既に正常に実行されている場合
        // ログを出力し、処理を正常終了する。
        IsRunSchedular.setLogHead(Constants.INQUIRY_EXPORT_JOB_NAME_JAP);
        if (IsRunSchedular.isRunSchedularInHour(Constants.INQUIRY_EXPORT_JOB_NAME_ENG,
            Constants.BATCH_COMPLETED)) {
          return null;
        } else if (s3Services.isFileExists(
            Constants.FILE_PATH_INQUIRY + Constants.FILE_NAME_INQUIRY + Constants.FILE_TYPE_TXT)) {
          logger.info(messagesource.getMessage("message.LOGMSG0003I",
              new String[] {Constants.INQUIRY_EXPORT_JOB_NAME_JAP}, Locale.JAPAN));
          return null;
        }
        // オプションテーブル（m_option）からテーブル名データ取得
        BaseQuery bq = new DeliveryGetDataOption();
        optionQueryArray = bq.query(null, conn, sqlLoaderService, messagesource);
        // データが取得しない または 0件取得の場合、ログを出力
        if (optionQueryArray == null || optionQueryArray.size() == 0) {
          String errorMessage = messagesource.getMessage("message.LOGMSG0023I",
              new String[] {Constants.TBNAME_OPTION, Constants.EMPTY}, Locale.JAPAN);
          logger.info(errorMessage);
          // バッチを中止する
          throw new Exception(errorMessage);
        }
        firstFlag = false;
      } else {
        conn.close();
        return null;
      }
      shuhaiArray = new ArrayList<HashMap<String, String>>();
      for (HashMap<String, String> optionMap : optionQueryArray) {
        // 相応なテーブルから各お問合せデータ抽出
        String className = Constants.INQUIRY_FORM_DAO_MAP.get(optionMap.get("SHUHAI_TBL"));
        Class<?> baseQueryClass = Class.forName(className);
        BaseQuery baseQuery = (BaseQuery) (baseQueryClass.getDeclaredConstructor().newInstance());
        Method queryMethod = baseQueryClass.getMethod("query", Map.class, Connection.class,
            SqlLoaderService.class, MessageSource.class);
        Map<String, String> condition = new HashMap<String, String>();
        // SQL文の条件設定
        condition.put("FORM_CODE", optionMap.get("FORM_CODE"));
        condition.put("SYSTEM_TIME", sys_date);
        // データ抽出
        inquiryQueryArray = (ArrayList<HashMap<String, String>>) queryMethod.invoke(baseQuery,
            new Object[] {condition, conn, sqlLoaderService, messagesource});
        // データが取得しない または 0件取得の場合、ログを出力
        if (inquiryQueryArray == null || inquiryQueryArray.size() == 0) {
          logger.info(messagesource.getMessage("message.LOGMSG0023I",
              new String[] {Constants.TABLE_NAME_MAP.get(optionMap.get("SHUHAI_TBL")),
                  Constants.EMPTY},
              Locale.JAPAN));
        }
        // 各お問合せデータ抽出なデータを統一書式にする
        Class<?> baseReaderImplClass = Class.forName("jp.co.sj.xop.batch.common.ParamConvert");
        Method getInquiryMethod = baseReaderImplClass.getMethod(
            Constants.PARAMCVT_DAO_MAP.get(optionMap.get("SHUHAI_TBL")), ArrayList.class);
        ArrayList<HashMap<String, String>> shuhailist = new ArrayList<HashMap<String, String>>();
        shuhailist = (ArrayList<HashMap<String, String>>) getInquiryMethod
            .invoke(baseReaderImplClass, new Object[] {inquiryQueryArray});
        // csv書き込みデータリスト
        shuhaiArray.addAll(shuhailist);
        // 各データ と 各お問合せテーブル名の一対一関係配列
        for (HashMap<String, String> shuhaimap : shuhailist) {
          tableName.put(shuhaimap.get("FORM_CODE") + shuhaimap.get("INSERT_NUMBER"),
              optionMap.get("SHUHAI_TBL"));
        }
      }
      tableNameList.add(tableName);

      // 取得データをJson型に転換する
      HashMap<String, ArrayList<HashMap<String, String>>> resultSet =
          new HashMap<String, ArrayList<HashMap<String, String>>>();
      resultSet.put("jp.co.sj.xop.batch.jdbc.InquiryQuery", shuhaiArray);
      resultSet.put("jp.co.sj.xop.batch.jdbc.DeliveryGetDataOption", tableNameList);
      JsonConfig jsonConfig = new JsonConfig();
      jsonConfig.setCycleDetectionStrategy(CycleDetectionStrategy.LENIENT);
      JSONObject object = JSONObject.fromObject(resultSet, jsonConfig);
      String result = object.toString();
      map.put(key, result);
    }
    return map;
  }
}

