package jp.co.sj.xop.batch.listener;

import org.springframework.stereotype.Component;

/**
 * 不要データ削除バッチ のRead前後に実施する処理。
 *
 * @author SSD
 *
 */
@Component
public class RegularDelItemReadListener extends BaseItemReadListener {
}
