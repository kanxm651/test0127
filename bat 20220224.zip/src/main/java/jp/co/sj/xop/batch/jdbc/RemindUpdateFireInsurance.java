package jp.co.sj.xop.batch.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.List;
import jp.co.sj.xop.batch.service.SqlLoaderService;
import jp.co.sj.xop.batch.service.SystemTimestampService;

/**
 * リマインドデータを更新するのUPDATEクラス.
 *
 * @author SSD 曾洋
 *
 */

public class RemindUpdateFireInsurance extends BaseUpdate {

  private PreparedStatement preStmt = null;

  /**
   * Update実行するメソッドを呼び出す.
   *
   * @return Map
   * @throws Exception
   */

  @Override
  protected int subExecute(List<String> condition, Connection conn,
      SqlLoaderService sqlLoaderService) throws Exception {

    int updateCount = 0;
    SystemTimestampService systemTimestampService = new SystemTimestampService();
    String updateTime = systemTimestampService.getDateTime();
    // SQLを取得
    String sql = sqlLoaderService.getSql("RemindUpdateFireInsurance");
    try {
      if (condition != null) {
        conn.setAutoCommit(false);
        preStmt = conn.prepareStatement(sql);
        for (int i = 0; i < condition.size(); i++) {
          preStmt.setString(1, "1");
          preStmt.setString(2, updateTime);
          preStmt.setString(3, condition.get(i).substring(0, 2));
          preStmt.setString(4, condition.get(i).substring(2));

          updateCount += preStmt.executeUpdate();
        }
        conn.commit();
      }
    } finally {
        preStmt.close();
    }
    return updateCount;
  }
}
