package jp.co.sj.xop.batch.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Component;
import jp.co.sj.xop.batch.common.constants.Constants;
import jp.co.sj.xop.batch.service.SqlLoaderService;

/**
 * 不要データ削除バッチ 削除管理テーブルからデータ取得Queryクラス
 *
 * @author SSD
 *
 */
@Component
public class DataDelGetTblData extends BaseQuery {

  private PreparedStatement preStmt = null;
  private ResultSet rs = null;

  public DataDelGetTblData() {
    super.setMsgHead(Constants.TBNAME_DATA_DEL);
  }

  /**
   * Query実行メソッド
   *
   * @return ArrayList
   * @throws Exception
   */
  @Override
  protected ArrayList<HashMap<String, String>> subQuery(Map<String, String> condition,
      Connection conn, SqlLoaderService sqlLoaderService) throws Exception {
    ArrayList<HashMap<String, String>> result = new ArrayList<HashMap<String, String>>();
    // SQLを取得
    String sql = sqlLoaderService.getSql("DataDelGetTblData");
    try {
      preStmt = conn.prepareStatement(sql);
      preStmt.setString(1, "1");
      rs = preStmt.executeQuery();
      while (rs.next()) {
        // リターン結果にDBから取得したカラム値をセットする
        HashMap<String, String> recMap = new HashMap<String, String>();
        recMap.put("TABLE_ID", rs.getString("TABLE_ID"));
        recMap.put("TABLE_NAME_EN", rs.getString("TABLE_NAME_EN"));
        recMap.put("TABLE_NAME_JA", rs.getString("TABLE_NAME_JA"));
        recMap.put("CONDITON_DATETIME", rs.getString("CONDITON_DATETIME"));
        recMap.put("CONDITON_FLAG", rs.getString("CONDITON_FLAG"));
        recMap.put("MONTHS_HELD", rs.getString("MONTHS_HELD"));
        result.add(recMap);
      }
    } finally {
        rs.close();
        preStmt.close();
    }
    return result;
  }
}
