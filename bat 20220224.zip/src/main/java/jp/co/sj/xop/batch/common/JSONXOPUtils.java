package jp.co.sj.xop.batch.common;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import jp.co.sj.xop.batch.common.constants.Constants;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

/**
 * JSONXOPUtilsクラス.
 *
 * @author SSD
 *
 */
public class JSONXOPUtils {
  /**
   * object2Mapするメソッドを呼び出す.
   *
   * @return Map
   * @throws Exception
   */
  @SuppressWarnings("unchecked")
  public static Map<String, Object> object2Map(Object item) throws Exception {
    String resultStr = Constants.EMPTY;
    item.getClass().getDeclaredFields();
    Class<?> itemClass = item.getClass();
    Method itemMethod = itemClass.getMethod("entrySet", null);
    Set<Map.Entry<String, String>> entrySet =
        (Set<Entry<String, String>>) itemMethod.invoke(item, new Object[] {});
    Iterator<Map.Entry<String, String>> it = entrySet.iterator();
    while (it.hasNext()) {
      Map.Entry<String, String> me = it.next();
      resultStr = me.getValue();
    }
    JSONObject json = JSONObject.fromObject(resultStr);
    Map<String, Object> result = new HashMap<String, Object>();
    result = prseJSON2Map(json);
    return result;
  }

  /**
   * prseJSON2Mapするメソッドを呼び出す.
   *
   * @return Map
   * @throws Exception
   */
  @SuppressWarnings("unchecked")
  public static Map<String, Object> prseJSON2Map(JSONObject json) {
    Map<String, Object> map = new HashMap<String, Object>();
    for (Object k : json.keySet()) {
      Object v = json.get(k);
      if (v instanceof JSONArray) {
        List<HashMap<String, Object>> list = new ArrayList<HashMap<String, Object>>();
        Iterator<JSONObject> it = ((JSONArray) v).iterator();
        while (it.hasNext()) {
          JSONObject json2 = it.next();
          list.add((HashMap<String, Object>) prseJSON2Map(json2));
        }
        map.put(k.toString(), list);
      } else if (v instanceof JSONObject) {
        map.put(k.toString(), prseJSON2Map((JSONObject) v));
      } else {
        map.put(k.toString(), v);
      }
    }
    return map;
  }
}
