package jp.co.sj.xop.batch.common;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.List;
import jp.co.sj.xop.batch.common.constants.Constants;

/**
 * TempFileUtilクラス.
 *
 * @author SSD
 *
 */
public class TempFileUtils {

  /**
   * TempFileファイルを作成するメソッドを呼び出す.
   *
   * @return ArrayList
   * @throws IOException
   * @throws Exception
   */
  public static String createTempFile(List<String> exportData, String outPutPath, String fileName,
      String suffix) throws Exception {
    String fileAbsolutePath = Constants.EMPTY;
    File tempFile = null;
    BufferedWriter tempFileoutputStream = null;
    File file = new File(outPutPath);

    if (file.exists()) {
      file.mkdir();
    }
    tempFile = File.createTempFile(fileName, suffix, new File(outPutPath));
    tempFileoutputStream =
        new BufferedWriter(new OutputStreamWriter(new FileOutputStream(tempFile), "MS932"), 1024);
    for (String row : exportData) {
      tempFileoutputStream.write(row);
      tempFileoutputStream.write(Constants.LINE_FEED);
    }

    tempFileoutputStream.close();
    fileAbsolutePath = tempFile.getAbsolutePath();
    return fileAbsolutePath;
  }
}
