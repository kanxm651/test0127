package jp.co.sj.xop;

import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import jp.co.sj.xop.batch.listener.InquiryExportItemProcessListener;
import jp.co.sj.xop.batch.listener.InquiryExportItemReadListener;
import jp.co.sj.xop.batch.listener.InquiryExportItemWriteListener;
import jp.co.sj.xop.batch.listener.InquiryExportJobListener;
import jp.co.sj.xop.batch.listener.InquiryExportStepListener;
import jp.co.sj.xop.batch.tasklet.InquiryExportDataProcessor;
import jp.co.sj.xop.batch.tasklet.InquiryExportDataReader;
import jp.co.sj.xop.batch.tasklet.InquiryExportDataWriter;

/**
 * 集配信システムへファイル転送（お問合せ）バッチのcontrollerクラス.
 *
 * @author SSD
 *
 */
@EnableBatchProcessing
@EnableAutoConfiguration
@ComponentScan
public class InquiryExportController extends BaseController {

  @Autowired
  public JobBuilderFactory jobBuilderFactory;

  /**
   * リスナー定義
   */
  @Autowired
  private InquiryExportItemProcessListener inquiryExportItemProcessListener;
  @Autowired
  private InquiryExportItemReadListener inquiryExportItemReadListener;
  @Autowired
  private InquiryExportItemWriteListener inquiryExportItemWriteListener;
  @Autowired
  private InquiryExportJobListener inquiryExportJobListener;
  @Autowired
  private InquiryExportStepListener inquiryExportStepListener;

  /**
   * 取得処理定義
   */
  @Autowired
  private InquiryExportDataReader inquiryExportDataReader;
  /**
   * 編集処理定義
   */
  @Autowired
  private InquiryExportDataProcessor inquiryExportDataProcessor;

  /**
   * 出力処理定義
   */
  @Autowired
  private InquiryExportDataWriter inquiryExportDataWriter;

  /**
   * mainメソッド.
   *
   * @param args 引数。「batchID」指定。
   */
  public static void main(String[] args) throws Exception {
    SpringApplication.run(InquiryExportController.class, args);
  }

  /**
   * Job実行するメソッドを呼び出す.
   *
   * @return Job
   * @throws Exception
   */
  @Bean(name = "InquiryExportBatchJob")
  public Job InquiryExportBatchJob(JobBuilderFactory jobBuilderFactory) throws Exception {
    // 集配信システムへファイル転送（お問合せ）Jobの取得データセット
    super.setBaseDataRead(inquiryExportDataReader);
    // 集配信システムへファイル転送（お問合せ）Jobの編集データセット
    super.setBaseDataProcessor(inquiryExportDataProcessor);
    // 集配信システムへファイル転送（お問合せ）Jobの出力データセット
    super.setBaseDataWriter(inquiryExportDataWriter);
    // 集配信システムへファイル転送（お問合せ）JobのStepリスナーセット
    super.setBaseStepListener(inquiryExportStepListener);
    // 集配信システムへファイル転送（お問合せ）JobのReadリスナーセット
    super.setBaseItemReadListener(inquiryExportItemReadListener);
    // 集配信システムへファイル転送（お問合せ）JobのProcessリスナーセット
    super.setBaseItemProcessListener(inquiryExportItemProcessListener);
    // 集配信システムへファイル転送（お問合せ）JobのWriteリスナーセット
    super.setBaseItemWriteListener(inquiryExportItemWriteListener);
    // 集配信システムへファイル転送（お問合せ）Jobを実行
    return jobBuilderFactory.get("InquiryExportBatchJob").incrementer(new RunIdIncrementer())
        // step処理開始
        .preventRestart().start(stepExecution())
        // 正常の場合、ステータスと終了コードを取得、Job完了
        .on(ExitStatus.COMPLETED.getExitCode()).end()
        // 異常した場合、ステータスと終了コードを取得、Job完了
        .on(ExitStatus.FAILED.getExitCode()).fail().end()
        // 集配信システムへファイル転送（お問合せ）Jobリスナーセット
        .listener(inquiryExportJobListener)
        // Job実行
        .build();
  }

}
