package jp.co.sj.xop.batch.listener;

import org.springframework.stereotype.Component;

/**
 * 夜間バッチ通知メール送信バッチ のWrite前後に実施する処理。
 *
 * @author SSD
 *
 */
@Component
public class NightnoticeExportItemWriteListener extends BaseItemWriteListener {
}
