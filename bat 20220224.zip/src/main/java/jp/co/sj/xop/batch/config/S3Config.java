package jp.co.sj.xop.batch.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;

/**
 * AmazonS3 接続情報を設定する.
 *
 * @author SSD
 *
 */
@Configuration
public class S3Config {

  @Value("${app.bucketeer_aws_access_key_id}")
  private String awsId;

  @Value("${app.bucketeer_aws_secret_access_key}")
  private String awsKey;

  @Value("${app.bucketeer_aws_region}")
  private String region;

  /**
   * AmazonS3 clientのKEY情報を設定する.
   */
  @Bean
  public AmazonS3 s3Client() {

    BasicAWSCredentials awsCreds = new BasicAWSCredentials(awsId, awsKey);
    AmazonS3 s3Client = AmazonS3ClientBuilder.standard().withRegion(Regions.fromName(region))
        .withCredentials(new AWSStaticCredentialsProvider(awsCreds)).build();

    return s3Client;
  }
}
