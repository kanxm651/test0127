package jp.co.sj.xop.batch.tasklet;

import java.lang.reflect.Method;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import javax.sql.DataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;
import jp.co.sj.xop.batch.common.constants.Constants;
import jp.co.sj.xop.batch.jdbc.BaseUpdate;
import jp.co.sj.xop.batch.service.S3Services;
import jp.co.sj.xop.batch.service.SqlLoaderService;

/**
 * 集配信システムへファイル転送（火災保険加入相談）についてのテーブルを更新.
 *
 * @author SSD 曾
 *
 */
@Component
public class FireInsuranceExportDataWriter extends BaseDataWriter {
  /**
   * ロガー.
   */
  private static final Logger logger = LoggerFactory.getLogger(FireInsuranceExportDataWriter.class);

  private ExecutionContext executionContext;
  private Connection conn = null;
  private StepExecution stepExecution;

  @Autowired
  S3Services s3Services;

  @Autowired
  public DataSource dataSource;

  @Autowired
  public SqlLoaderService sqlLoaderService;

  /**
   * メッセージソース.
   */
  @Autowired
  private MessageSource messagesource;

  @Override
  public void open(ExecutionContext executionContext) {
    this.executionContext = executionContext;
  }

  @BeforeStep
  public void beforeStep(StepExecution stepExecution) {
    this.stepExecution = stepExecution;
  }

  /**
   * データファイルアップロード状態をテーブルに更新
   *
   */
  @SuppressWarnings({"rawtypes", "unchecked"})
  @Override
  public void write(List items) throws Exception {
    if (executionContext != null) {

      // テーブルに更新データ配列
      Map<String, Object> writerParamMap = (Map<String, Object>) items.get(0);
      writerParamMap = (Map<String, Object>) items.get(0);
      // レコードキーサイズ
      int recordKeySize = 0;
      // テーブルに更新フラグ
      String updateFlag = null;
      // 加工エラーフラグ
      String processerrorFlag = null;
      // エラーフラグ
      Boolean errorFlag = false;
      updateFlag = (String) writerParamMap.get("UPDATE_FLAG");
      processerrorFlag = (String) writerParamMap.get("ERROR_FLAG");

      if (Constants.ERROR.equals(processerrorFlag)) {
        errorFlag = true;
      } else if (!Constants.DO_NOT.equals(updateFlag)) {
        // レコードキーリスト
        List<String> recordKey = new ArrayList<String>();
        recordKey = (List<String>) writerParamMap.get("RECORD_KEY");
        try {
          conn = dataSource.getConnection();
          Map<String, String> writeFunctionMap = new HashMap<String, String>();
          writeFunctionMap.put("jp.co.sj.xop.batch.jdbc.DeliveryUpdateFireInsurance", "execute");
          for (String key : writeFunctionMap.keySet()) {
            // 火災保険加入相談テーブルを更新する。
            Class<?> baseUpadateClass = Class.forName(key);
            BaseUpdate baseUpdate =
                (BaseUpdate) (baseUpadateClass.getDeclaredConstructor().newInstance());
            Method updateMethod = baseUpadateClass.getMethod(writeFunctionMap.get(key), List.class,
                Connection.class, SqlLoaderService.class);
            recordKeySize = (int) updateMethod.invoke(baseUpdate,
                new Object[] {recordKey, conn, sqlLoaderService});
            // 成功のログを出力する。
            logger
                .info(
                    messagesource
                        .getMessage("message.LOGMSG0018I",
                            new String[] {Constants.FIRE_INSURANCE_EXPORT_JOB_NAME_ENG
                                + Constants.FIRE_INSURANCE, String.valueOf(recordKeySize)},
                            Locale.JAPAN));
            conn.close();
          }
        } catch (Exception e) {
          // 失敗のログを出力する。
          logger.error(messagesource.getMessage("message.LOGMSG0009E",
              new String[] {Constants.FIRE_INSURANCE}, Locale.JAPAN));
          boolean delRtnFlg = false;

          // S3にアップロードしたファイル削除を処理する。
          if (s3Services.isFileExists(
              Constants.FILE_PATH_FIRE + Constants.FILE_NAME_FIRE + Constants.FILE_TYPE_TXT)) {
            delRtnFlg = s3Services.deleteFile(
                Constants.FILE_PATH_FIRE + Constants.FILE_NAME_FIRE + Constants.FILE_TYPE_TXT);

            if (!delRtnFlg) {
              // ファイル削除失敗した場合、ログを出力する。
              logger.error(messagesource.getMessage("message.LOGMSG0010E",
                  new String[] {Constants.FIRE_INSURANCE}, Locale.JAPAN));
            } else {
              // ファイル削除成功した場合、ログを出力する。
              logger.info(messagesource.getMessage("message.LOGMSG0019I",
                  new String[] {Constants.FIRE_INSURANCE}, Locale.JAPAN));
            }
          }
          // バックアップファイル名を取得する
          String bkFileName = writerParamMap.get("BK_FILE_NAME").toString();
          // S3にアップロードしたバックアップファイルの削除を処理する。
          if (delRtnFlg && s3Services.isFileExists(Constants.BKFILE_PATH_FIRE + bkFileName)) {
            delRtnFlg = s3Services.deleteFile(Constants.BKFILE_PATH_FIRE + bkFileName);

            if (!delRtnFlg) {
              // バックアップファイル削除失敗した場合、ログを出力する。
              logger.error(messagesource.getMessage("message.LOGMSG0010E",
                  new String[] {Constants.FIRE_INSURANCE_BACKUP}, Locale.JAPAN));
            } else {
              // バックアップファイル削除成功した場合、ログを出力する。
              logger.info(messagesource.getMessage("message.LOGMSG0019I",
                  new String[] {Constants.FIRE_INSURANCE_BACKUP}, Locale.JAPAN));
            }
          }
          // バッチを中止する
          throw e;
        }
      }
      if (errorFlag) {
        stepExecution.setExitStatus(ExitStatus.FAILED);
      }
    }
  }
}
