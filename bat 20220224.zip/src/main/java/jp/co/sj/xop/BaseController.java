package jp.co.sj.xop;

import java.util.ArrayList;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.step.tasklet.TaskletStep;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import jp.co.sj.xop.batch.listener.BaseItemProcessListener;
import jp.co.sj.xop.batch.listener.BaseItemReadListener;
import jp.co.sj.xop.batch.listener.BaseItemWriteListener;
import jp.co.sj.xop.batch.listener.BaseStepListener;
import jp.co.sj.xop.batch.tasklet.BaseDataProcessor;
import jp.co.sj.xop.batch.tasklet.BaseDataRead;
import jp.co.sj.xop.batch.tasklet.BaseDataWriter;

/**
 * バッチのcontrollerクラス.
 *
 * @author SSD
 *
 */
@ComponentScan
public class BaseController {

  @Autowired
  public StepBuilderFactory stepBuilderFactory;

  /**
   * バッチジョブリスナー.
   */
  private BaseItemReadListener baseItemReadListener;
  private BaseItemProcessListener baseItemProcessListener;
  private BaseItemWriteListener baseItemWriteListener;
  private BaseStepListener baseStepListener;

  /**
   * 作成処理Read.
   */
  private BaseDataRead baseDataRead;
  /**
   * 作成処理Processor.
   */
  private BaseDataProcessor baseDataProcessor;
  /**
   * 作成処理Writer.
   */
  private BaseDataWriter baseDataWriter;

  /**
   * Readのセットメソッド.
   *
   * @return void
   */
  protected void setBaseDataRead(BaseDataRead baseDataRead) {
    this.baseDataRead = baseDataRead;
  }

  /**
   * Processorのセットメソッド.
   *
   * @return void
   */
  protected void setBaseDataProcessor(BaseDataProcessor baseDataProcessor) {
    this.baseDataProcessor = baseDataProcessor;
  }

  /**
   * Writerのセットメソッド.
   *
   * @return void
   */
  protected void setBaseDataWriter(BaseDataWriter baseDataWriter) {
    this.baseDataWriter = baseDataWriter;
  }

  /**
   * Readリスナーのセットメソッド.
   *
   * @return void
   */
  protected void setBaseItemReadListener(BaseItemReadListener baseItemReadListener) {
    this.baseItemReadListener = baseItemReadListener;
  }

  /**
   * Processリスナーのセットメソッド.
   *
   * @return void
   */
  protected void setBaseItemProcessListener(BaseItemProcessListener baseItemProcessListener) {
    this.baseItemProcessListener = baseItemProcessListener;
  }

  /**
   * Writeリスナーのセットメソッド.
   *
   * @return void
   */
  protected void setBaseItemWriteListener(BaseItemWriteListener baseItemWriteListener) {
    this.baseItemWriteListener = baseItemWriteListener;
  }

  /**
   * Stepリスナーのセットメソッド.
   *
   * @return void
   */
  protected void setBaseStepListener(BaseStepListener baseStepListener) {
    this.baseStepListener = baseStepListener;
  }

  /**
   * Step実行メソッド
   *
   * @return step
   * @throws Exception
   */
  @Bean
  public Step stepExecution() throws Exception {
    // Step処理開始
    TaskletStep step = stepBuilderFactory.get("stepExecution").chunk(0)
        // Stepリスナーセット
        .listener(baseStepListener)
        // Readリスナーセット
        .listener(baseItemReadListener)
        // データ取得
        .reader(read())
        // Processリスナーセット
        .listener(baseItemProcessListener)
        // データ編集
        .processor(processor())
        // Writeリスナーセット
        .listener(baseItemWriteListener)
        // データ出力
        .writer(write()).startLimit(1).build();

    return step;
  }

  /**
   * Read実行メソッド
   *
   * @return BaseDataRead
   * @throws Exception
   */
  private BaseDataRead read() throws Exception {
    baseDataRead.read();
    return baseDataRead;
  }

  /**
   * Processor実行メソッド
   *
   * @return BaseDataProcessor
   * @throws Exception
   */
  private BaseDataProcessor processor() throws Exception {
    baseDataProcessor.process(new Object());
    return baseDataProcessor;
  }

  /**
   * Writer実行メソッド
   *
   * @return BaseDataWriter
   * @throws Exception
   */
  @SuppressWarnings("rawtypes")
  private BaseDataWriter write() throws Exception {
    baseDataWriter.write(new ArrayList());
    return baseDataWriter;
  }
}
