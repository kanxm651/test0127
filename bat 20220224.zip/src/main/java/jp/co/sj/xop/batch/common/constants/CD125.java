package jp.co.sj.xop.batch.common.constants;

/**
 * CD125:性別区分（英語）の列挙クラス
 *
 * @author SSD
 *
 */
public enum CD125 implements Encodable<String> {
  /**
   * 男性
   */
  SEX_MALE_EN("1", "male"),
  /**
   * 女性
   */
  SEX_FEMALE_EN("2", "female");

  /** デコーダー */
  private static final Decoder<String, CD125> DECODER = Decoder.create(values());

  /** コード値 */
  private final String code;

  /** 名称 */
  private final String name;

  /**
   * コンストラクタ.
   *
   * @param code コード値
   * @param name 名称
   */
  private CD125(String code, String name) {
    this.code = code;
    this.name = name;
  }

  @Override
  public String getCode() {
    return code;
  }

  /**
   * コード値からEnumクラスを取得する.
   *
   * @param code コード値
   * @return 受領形式Enumクラス
   */
  public static CD125 decode(String code) {
    return DECODER.decode(code);
  }

  /**
   * 名称を取得するメソッド.
   *
   * @return 名称
   */
  public String getName() {
    return name;
  }
}

