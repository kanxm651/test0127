package jp.co.sj.xop.batch.listener;

import org.springframework.stereotype.Component;
import jp.co.sj.xop.batch.common.constants.Constants;

/**
 * 集配信システムへファイル転送（お問合せ）バッチ のJob前後に実施する処理。
 *
 * @author SSD
 *
 */
@Component
public class InquiryExportJobListener extends BaseJobListener {
  public InquiryExportJobListener() {
    super.setLogHead(Constants.INQUIRY_EXPORT_JOB_NAME_JAP);
  }
}
