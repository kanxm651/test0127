package jp.co.sj.xop.batch.tasklet;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import javax.sql.DataSource;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;
import jp.co.sj.xop.batch.common.constants.Constants;
import jp.co.sj.xop.batch.service.S3Services;
import jp.co.sj.xop.batch.service.SqlLoaderService;

/**
 * 不要ファイル削除バッチ 出力処理
 *
 * @author SSD
 *
 */
@Component
public class S3FileDelWriter extends BaseDataWriter {
  /**
   * ロガー
   */
  private static final Logger logger = LoggerFactory.getLogger(S3FileDelWriter.class);

  private ExecutionContext executionContext;
  private boolean StepErrorFlag = false;
  private StepExecution stepExecution;

  @Autowired
  S3Services s3Services;

  @Autowired
  public DataSource dataSource;

  @Autowired
  public SqlLoaderService sqlLoaderService;

  /**
   * メッセージソース
   */
  @Autowired
  private MessageSource messagesource;


  @Override
  public void open(ExecutionContext executionContext) {
    this.executionContext = executionContext;
  }

  @BeforeStep
  public void beforeStep(StepExecution stepExecution) {
    this.stepExecution = stepExecution;
  }

  /**
   * 不要ファイルを削除する
   *
   */
  @SuppressWarnings({"rawtypes", "unchecked"})
  @Override
  public void write(List items) throws Exception {
    if (executionContext != null) {


      // 不要ファイル削除バッチ データ出力準備
      Map<String, Object> writerParamMap = (Map<String, Object>) items.get(0);
      writerParamMap = (Map<String, Object>) items.get(0);
      String filePathParam = Constants.EMPTY;
      String monthsHeld = Constants.EMPTY;
      String fileName = Constants.EMPTY;

      filePathParam = (String) writerParamMap.get("FILE_PATH_PARAM");
      monthsHeld = (String) writerParamMap.get("MONTHS_HELD");
      fileName = (String) writerParamMap.get("FILE_NAME_JA");

      String endFlag = Constants.EMPTY;
      String errorFlag = Constants.EMPTY;
      int delRtn;
      endFlag = (String) writerParamMap.get("END_FLAG");
      errorFlag = (String) writerParamMap.get("ERROR_FLAG");
      if (StringUtils.isEmpty(errorFlag)) {
        try {
          // 不要ファイルリスト
          List<String> newList = new ArrayList<String>();
          SimpleDateFormat df = new SimpleDateFormat("yyyyMMdd");
          Calendar calendar = Calendar.getInstance();
          int howMuch = Integer.parseInt(monthsHeld);
          calendar.add(Calendar.MONTH, -howMuch);
          String delFlag = df.format(calendar.getTime());
          // 不要ファイルパスのリスト取得
          List<String> list = s3Services.getFileNameInFolder(filePathParam);
          if (list == null || list.size() == 0) {
            logger.error(messagesource.getMessage("message.LOGMSG0010E", new String[] {fileName},
                Locale.JAPAN));
            StepErrorFlag = true;
          } else {
            // 不要データ削除バッチ または 集配信システムへファイル転送（お問合せ）バッチ の不要ファイル削除
            if (filePathParam.equals(Constants.BKFILE_PATH_REMIND)
                || filePathParam.equals(Constants.BKFILE_PATH_INQUIRY)) {
              for (int i = 0; i < list.size(); i++) {
                String[] str = list.get(i).split("_");
                if (str[2].substring(0, 8).compareTo(delFlag) < 0) {
                  newList.add(list.get(i));
                }
              }
            }
            // 集配信システムへファイル転送（火災保険加入相談）バッチ の不要ファイル削除
            if (filePathParam.equals(Constants.BKFILE_PATH_FIRE)) {
              for (int i = 0; i < list.size(); i++) {
                String[] str = list.get(i).split("_");
                if (str[3].substring(0, 8).compareTo(delFlag) < 0) {
                  newList.add(list.get(i));
                }
              }
            }
            // 夜間バッチ通知メール送信バッチ の不要ファイル削除
            if (filePathParam.equals(Constants.BKFILE_PATH_NIGHTNOTICE)) {
              for (int i = 0; i < list.size(); i++) {
                String str = list.get(i).substring(list.get(i).length() - 18);
                if (str.substring(0, 8).compareTo(delFlag) < 0) {
                  newList.add(list.get(i));
                }
              }
            }
            if (newList.size() > 0) {
              // 不要ファイル削減する
              delRtn = s3Services.deleteFiles(newList);
              // 削除成功した場合、ログを出力する
              logger.info(messagesource.getMessage("message.LOGMSG0019I",
                  new String[] {fileName, String.valueOf(delRtn)}, Locale.JAPAN));
            }
          }
        } catch (Exception e) {
          // 削除失敗した場合、エラーメッセージを出力する
          logger.error(messagesource.getMessage("message.LOGMSG0010E", new String[] {fileName},
              Locale.JAPAN), e);
          StepErrorFlag = true;
        }
      } else {
        StepErrorFlag = true;
      }
      if ("END".equals(endFlag) && StepErrorFlag == true) {
        stepExecution.setExitStatus(ExitStatus.FAILED);
      }
    }
  }
}
