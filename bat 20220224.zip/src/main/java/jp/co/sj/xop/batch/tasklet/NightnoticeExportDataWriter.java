package jp.co.sj.xop.batch.tasklet;

import java.lang.reflect.Method;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import javax.sql.DataSource;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;
import jp.co.sj.xop.batch.common.constants.Constants;
import jp.co.sj.xop.batch.jdbc.BaseUpdate;
import jp.co.sj.xop.batch.service.S3Services;
import jp.co.sj.xop.batch.service.SqlLoaderService;

/**
 * 夜間バッチ通知メール送信バッチ 出力処理
 *
 * @author SSD
 *
 */
@Component
public class NightnoticeExportDataWriter extends BaseDataWriter {
  /**
   * ロガー.
   */
  private static final Logger logger = LoggerFactory.getLogger(NightnoticeExportDataWriter.class);

  private ExecutionContext executionContext;
  private Connection conn = null;
  private boolean firstFlag = true;
  private boolean StepErrorFlag = false;
  private StepExecution stepExecution;

  @Autowired
  public DataSource dataSource;

  @Autowired
  S3Services s3Services;

  @Autowired
  public SqlLoaderService sqlLoaderService;

  /**
   * メッセージソース.
   */
  @Autowired
  private MessageSource messagesource;


  @Override
  public void open(ExecutionContext executionContext) {
    this.executionContext = executionContext;
  }

  @BeforeStep
  public void beforeStep(StepExecution stepExecution) {
    this.stepExecution = stepExecution;
  }

  /**
   * 送信結果を添付テーブルに更新する
   *
   */
  @SuppressWarnings({"rawtypes", "unchecked"})
  @Override
  public void write(List items) throws Exception {
    if (executionContext != null) {
      Map<String, Object> writerParamMap = (Map<String, Object>) items.get(0);
      writerParamMap = (Map<String, Object>) items.get(0);
      // 更新フラグ
      String update_flag = Constants.EMPTY;
      // csvフラグ
      String csv_flag = Constants.EMPTY;
      // メールフラグ
      String mail_flag = Constants.EMPTY;
      // エンドフラグ
      String endFlag = Constants.EMPTY;
      // エラーフラグ
      String errorFlag = Constants.EMPTY;
      // フォームコード
      String formCode = Constants.EMPTY;
      // 登録番号リスト
      List<String> insertNumberList = new ArrayList<String>();
      update_flag = (String) writerParamMap.get("UPDATE_FLAG");
      csv_flag = (String) writerParamMap.get("CSV_FLAG");
      mail_flag = (String) writerParamMap.get("MAIL_FLAG");
      endFlag = (String) writerParamMap.get("END_FLAG");
      errorFlag = (String) writerParamMap.get("ERROR_FLAG");
      formCode = (String) writerParamMap.get("FORM_CODE");

      if (StringUtils.isNotEmpty(errorFlag)) {
        StepErrorFlag = true;
      } else if (!Constants.DO_NOT.equals(update_flag)) {
        insertNumberList = (List<String>) writerParamMap.get("INSERT_NUMBER_LIST");
        // csvファイルありまたメール送信成功の場合
        if ("0".equals(csv_flag) && "0".equals(mail_flag)) {
          Map<String, String> writeFunctionMap = new HashMap<String, String>();
          writeFunctionMap.put(Constants.FORM_DAO_UPMAP.get(formCode), "execute");

          for (String key : writeFunctionMap.keySet()) {
            try {
              if (firstFlag) {
                conn = dataSource.getConnection();
                firstFlag = false;
              }
              // （対象フォーム）テーブルを更新する。
              Class<?> baseUpadateClass = Class.forName(key);
              BaseUpdate baseUpdate =
                  (BaseUpdate) (baseUpadateClass.getDeclaredConstructor().newInstance());
              Method updateMethod = baseUpadateClass.getMethod(writeFunctionMap.get(key),
                  List.class, Connection.class, SqlLoaderService.class);
              updateMethod.invoke(baseUpdate,
                  new Object[] {insertNumberList, conn, sqlLoaderService});
              int insertNumberListSize = 0;
              if (insertNumberList != null) {
                insertNumberListSize = insertNumberList.size();
              }
              // 更新成功の場合ログを出力する。
              logger.info(messagesource.getMessage("message.LOGMSG0018I",
                  new String[] {
                      Constants.NIGHT_NOTICE_EXPORT_JOB_NAME_ENG
                          + Constants.FORM_TBNAME_MAP.get(formCode),
                      String.valueOf(insertNumberListSize)},
                  Locale.JAPAN));
              if ("END".equals(endFlag)) {
                conn.close();
              }
            } catch (Exception e) {
              // 更新失敗の場合ログを出力する。
              logger.error(messagesource.getMessage("message.LOGMSG0009E",
                  new String[] {Constants.FORM_TBNAME_MAP.get(formCode)}, Locale.JAPAN), e);

              // S3にアップロードしたバックアップファイル削除を処理する。
              String bkFileName = writerParamMap.get("BK_FILE_NAME").toString();
              if (s3Services.isFileExists(Constants.BKFILE_PATH_NIGHTNOTICE + bkFileName)) {
                boolean delRtnFlg =
                    s3Services.deleteFile(Constants.BKFILE_PATH_NIGHTNOTICE + bkFileName);
                if (!delRtnFlg) {
                  // 削除失敗した場合、エラーメッセージを出力する
                  logger.error(messagesource.getMessage("message.LOGMSG0010E",
                      new String[] {Constants.CSV}, Locale.JAPAN));
                  StepErrorFlag = true;
                } else {
                  // 削除成功した場合、ログを出力する
                  logger.info(messagesource.getMessage("message.LOGMSG0019I",
                      new String[] {Constants.CSV}, Locale.JAPAN));
                }
              }
              StepErrorFlag = true;
            }
          }
        }
      }

      if ("END".equals(endFlag) && StepErrorFlag == true) {
        stepExecution.setExitStatus(ExitStatus.FAILED);
      }
    }
  }
}
