package jp.co.sj.xop.batch.listener;

import org.springframework.stereotype.Component;

/**
 * 不要ファイル削除バッチ のRead前後に実施する処理。
 *
 * @author SSD
 *
 */
@Component
public class S3FileDelItemReadListener extends BaseItemReadListener {
}
