package jp.co.sj.xop;

import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import jp.co.sj.xop.batch.listener.RemindExportItemProcessListener;
import jp.co.sj.xop.batch.listener.RemindExportItemReadListener;
import jp.co.sj.xop.batch.listener.RemindExportItemWriteListener;
import jp.co.sj.xop.batch.listener.RemindExportJobListener;
import jp.co.sj.xop.batch.listener.RemindExportStepListener;
import jp.co.sj.xop.batch.tasklet.RemindExportDataProcessor;
import jp.co.sj.xop.batch.tasklet.RemindExportDataReader;
import jp.co.sj.xop.batch.tasklet.RemindExportDataWriter;

/**
 * リマインドバッチのcontrollerクラス.
 *
 * @author SSD
 *
 */
@EnableBatchProcessing
@EnableAutoConfiguration
@ComponentScan
public class RemindExportController extends BaseController {

  @Autowired
  public JobBuilderFactory jobBuilderFactory;

  /**
   * リスナー定義
   */
  @Autowired
  private RemindExportItemProcessListener remindExportItemProcessListener;
  @Autowired
  private RemindExportItemReadListener remindExportItemReadListener;
  @Autowired
  private RemindExportItemWriteListener remindExportItemWriteListener;
  @Autowired
  private RemindExportJobListener remindExportJobListener;
  @Autowired
  private RemindExportStepListener remindExportStepListener;

  /**
   * 取得処理定義
   */
  @Autowired
  private RemindExportDataReader remindExportDataReader;
  /**
   * 編集処理定義
   */
  @Autowired
  private RemindExportDataProcessor remindExportDataProcessor;
  /**
   * 出力処理定義
   */
  @Autowired
  private RemindExportDataWriter remindExportDataWriter;

  /**
   * mainメソッド.
   *
   * @param args 引数。「batchID」指定。
   */
  public static void main(String[] args) throws Exception {
    SpringApplication.run(RemindExportController.class, args);
  }

  /**
   * Job実行するメソッドを呼び出す.
   *
   * @return Job
   * @throws Exception
   */
  @Bean(name = "RemindExportBatchJob")
  public Job RemindExportBatchJob(JobBuilderFactory jobBuilderFactory) throws Exception {
    // リマインドJobの取得データセット
    super.setBaseDataRead(remindExportDataReader);
    // リマインドJobの編集データセット
    super.setBaseDataProcessor(remindExportDataProcessor);
    // リマインドJobの出力データセット
    super.setBaseDataWriter(remindExportDataWriter);
    // リマインドJobのStepリスナーセット
    super.setBaseStepListener(remindExportStepListener);
    // リマインドJobのReadリスナーセット
    super.setBaseItemReadListener(remindExportItemReadListener);
    // リマインドJobのProcessリスナーセット
    super.setBaseItemProcessListener(remindExportItemProcessListener);
    // リマインドJobのWriteリスナーセット
    super.setBaseItemWriteListener(remindExportItemWriteListener);
    // リマインドJobを実行
    return jobBuilderFactory.get("RemindExportBatchJob").incrementer(new RunIdIncrementer())
        // step処理開始
        .preventRestart().start(stepExecution())
        // 正常の場合、ステータスと終了コードを取得、Job完了
        .on(ExitStatus.COMPLETED.getExitCode()).end()
        // 異常した場合、ステータスと終了コードを取得、Job完了
        .on(ExitStatus.FAILED.getExitCode()).fail().end()
        // リマインドJobリスナーセット
        .listener(remindExportJobListener)
        // Job実行
        .build();
  }
}
