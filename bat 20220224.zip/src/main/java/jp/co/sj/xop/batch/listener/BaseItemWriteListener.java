package jp.co.sj.xop.batch.listener;

import java.util.List;
import java.util.Locale;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.ItemWriteListener;
import org.springframework.batch.core.annotation.AfterWrite;
import org.springframework.batch.core.annotation.BeforeWrite;
import org.springframework.batch.core.annotation.OnWriteError;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;

/**
 * 出力前後に実施する処理
 *
 * @author SSD
 *
 */
@Component
public class BaseItemWriteListener implements ItemWriteListener<Object> {

  boolean display = false;
  /**
   * ロガー.
   */
  private static final Logger logger = LoggerFactory.getLogger(BaseItemWriteListener.class);

  /**
   * メッセージソース.
   */
  @Autowired
  private MessageSource messagesource;

  @BeforeWrite
  public void beforeWrite(List<? extends Object> items) {
      logger.info(messagesource.getMessage("message.LOGMSG0010I", new String[] {}, Locale.JAPAN));
      display = true;
  }

  @AfterWrite
  public void afterWrite(List<? extends Object> items) {
    if (display) {
      logger.info(messagesource.getMessage("message.LOGMSG0011I", new String[] {}, Locale.JAPAN));
    }
  }

  @OnWriteError
  public void onWriteError(Exception e, List<? extends Object> items) {}

}
