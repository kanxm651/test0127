package jp.co.sj.xop.batch.common;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;
import com.amazonaws.util.StringUtils;
import jp.co.sj.xop.batch.common.constants.CD012;
import jp.co.sj.xop.batch.common.constants.CD101;
import jp.co.sj.xop.batch.common.constants.CD103;
import jp.co.sj.xop.batch.common.constants.CD104;
import jp.co.sj.xop.batch.common.constants.CD105;
import jp.co.sj.xop.batch.common.constants.CD108;
import jp.co.sj.xop.batch.common.constants.CD117;
import jp.co.sj.xop.batch.common.constants.CD118;
import jp.co.sj.xop.batch.common.constants.CD125;
import jp.co.sj.xop.batch.common.constants.Constants;
import jp.co.sj.xop.batch.common.constants.DateTimeConstants;

public class ParamConvert {
  // システム時間取得
  static Timestamp nowTimestamp = Timestamp.valueOf(LocalDateTimeEx.now());
  static String the_date = DateTimeUtil.format(nowTimestamp, DateTimeConstants.DATETIMEFORMAT_DATE);
  static String the_time =
      DateTimeUtil.format(nowTimestamp, DateTimeConstants.DATETIMEFORMAT_TIME6);


  /**
   * 集配信システムへファイル転送（火災保険加入相談）バッチ データ転換
   *
   * @param 火災保険加入相談テーブル（t_fire_insurance_inquiry）から取得データ
   * @return リスト
   */
  public static ArrayList<HashMap<String, String>> getFireInsurance(
      ArrayList<HashMap<String, String>> fireInsuranceQueryArray) {
    ArrayList<HashMap<String, String>> fireInsuranceList = new ArrayList<HashMap<String, String>>();

    for (HashMap<String, String> dataResult : fireInsuranceQueryArray) {
      HashMap<String, String> fireInsuranceQueryMap = new HashMap<String, String>();
      // null2Blank
      for (Entry<String, String> entry : dataResult.entrySet()) {
        String mapKey = entry.getKey();
        String mapValue = null2Blank((String) entry.getValue());
        fireInsuranceQueryMap.put(mapKey, mapValue);
      }
      HashMap<String, String> fireInsuranceMap = new HashMap<String, String>();
      // 書き込みデータ設定
      fireInsuranceMap.put("START", Constants.START);
      if (StringUtil.isNullOrEmpty(fireInsuranceQueryMap.get("CUSTOMER_NUMBER"))) {
        fireInsuranceMap.put("RECEPTION_DIV1", CD101.RECEPTION_DIV_OHP.getCode());
      } else {
        fireInsuranceMap.put("RECEPTION_DIV1", CD101.RECEPTION_DIV_MYPAGE.getCode());
      }
      fireInsuranceMap.put("RECEPTION_DIV2", CD117.RECEPTION_DIV_NOTHING.getCode());
      fireInsuranceMap.put("BUSINESS_DIV", CD118.BUSINESS_DIV_FIRE_INSURANCE.getCode());
      try {
        Date date = new SimpleDateFormat(DateTimeConstants.DATETIMEFORMAT_DATE_TIME)
            .parse(fireInsuranceQueryMap.get("INSERT_DATETIME"));
        String reception_date =
            new SimpleDateFormat(DateTimeConstants.DATETIMEFORMAT_DATE).format(date);
        String reception_time =
            new SimpleDateFormat(DateTimeConstants.DATETIMEFORMAT_TIME4).format(date);
        // 受付日
        fireInsuranceMap.put("RECEPTION_DATE", reception_date);
        // 受付時間
        fireInsuranceMap.put("RECEPTION_TIME", reception_time);
      } catch (Exception e) {
        fireInsuranceMap.put("RECEPTION_DATE", Constants.EIGHT_SPACE);
        fireInsuranceMap.put("RECEPTION_TIME", Constants.FOUR_SPACE);
      }
      fireInsuranceMap.put("NAME1", fireInsuranceQueryMap.get("LASTNAME"));
      fireInsuranceMap.put("NAME2", fireInsuranceQueryMap.get("FIRSTNAME"));
      fireInsuranceMap.put("NAME_KANA1", fireInsuranceQueryMap.get("LASTNAME_KANA"));
      fireInsuranceMap.put("NAME_KANA2", fireInsuranceQueryMap.get("FIRSTNAME_KANA"));
      if (StringUtils.isNullOrEmpty(fireInsuranceQueryMap.get("ZIP_CODE"))) {
        fireInsuranceMap.put("ZIP_CODE", Constants.SEVEN_SPACE);
      } else {
        fireInsuranceMap.put("ZIP_CODE", fireInsuranceQueryMap.get("ZIP_CODE"));
      }
      fireInsuranceMap.put("TEL_HOME", fireInsuranceQueryMap.get("TEL_HOME"));
      fireInsuranceMap.put("CONTACT_CLASSIFY", Constants.HALF_SPACE);
      fireInsuranceMap.put("TEL_CONTACT", fireInsuranceQueryMap.get("TEL_CONTACT"));
      fireInsuranceMap.put("FAX_CLASSIFY", Constants.HALF_SPACE);
      fireInsuranceMap.put("TEL_FAX", fireInsuranceQueryMap.get("TEL_FAX"));
      fireInsuranceMap.put("ADDRESS_PREF", fireInsuranceQueryMap.get("ADDRESS_PREF"));
      fireInsuranceMap.put("ADDRESS1", fireInsuranceQueryMap.get("ADDRESS1"));
      fireInsuranceMap.put("ADDRESS2", fireInsuranceQueryMap.get("ADDRESS2"));
      fireInsuranceMap.put("ADDRESS3", fireInsuranceQueryMap.get("ADDRESS3"));
      fireInsuranceMap.put("EMAIL_ADD", fireInsuranceQueryMap.get("EMAIL_ADD"));
      try {
        fireInsuranceMap.put("SEX", CD105.decode(fireInsuranceQueryMap.get("SEX")).getCode());
      } catch (Exception e) {
        fireInsuranceMap.put("SEX", Constants.HALF_SPACE);
      }
      fireInsuranceMap.put("BIRTHDAY", Constants.EIGHT_SPACE);
      fireInsuranceMap.put("EXCHANGE", Constants.HALF_SPACE);
      fireInsuranceMap.put("CUSTOMER_NUMBER", fireInsuranceQueryMap.get("CUSTOMER_NUMBER"));
      fireInsuranceMap.put("OPTION5", fireInsuranceQueryMap.get("QUICK_PAGE_ID"));
      fireInsuranceMap.put("OWNER_ID", fireInsuranceQueryMap.get("OWNER_ID"));
      fireInsuranceMap.put("PARENT_ACCOUNT_CODE", fireInsuranceQueryMap.get("PARENT_ACCOUNT_CODE"));
      if (StringUtils.isNullOrEmpty(fireInsuranceQueryMap.get("AGENCY_EXPLANATION"))) {
        fireInsuranceMap.put("AGENCY_EXPLANATION", Constants.HALF_SPACE);
      } else {
        // 代理店割振り区分
        fireInsuranceMap.put("AGENCY_EXPLANATION", fireInsuranceQueryMap.get("AGENCY_EXPLANATION"));
      }
      fireInsuranceMap.put("AGENCY_EXCLUDING", fireInsuranceQueryMap.get("AGENCY_EXCLUDING"));
      // リーズ番号(加入相談依頼番号、資料請求番号)
      if (StringUtils.isNullOrEmpty(fireInsuranceQueryMap.get("FORM_CODE"))
          || StringUtils.isNullOrEmpty(fireInsuranceQueryMap.get("INSERT_NUMBER"))) {
        fireInsuranceMap.put("LEEDS_REQUEST_NUMBER", Constants.TWELVE_SPACE);
      } else {
        fireInsuranceMap.put("LEEDS_REQUEST_NUMBER",
          fireInsuranceQueryMap.get("FORM_CODE") + fireInsuranceQueryMap.get("INSERT_NUMBER"));
      }

      // *4
      if(Constants.CONSTANT_2.equals(fireInsuranceQueryMap.get("AGENCY_EXPLANATION"))
          || Constants.CONSTANT_3.equals(fireInsuranceQueryMap.get("AGENCY_EXPLANATION")) ) {
        fireInsuranceMap.put("INSERT_CLASSIFY", Constants.CONSTANT_BT);
        fireInsuranceMap.put("CATEGORY_CLASSIFY", Constants.CONSTANT_02);
        fireInsuranceMap.put("CATEGORY_NUM", Constants.CONSTANT_12);
        fireInsuranceMap.put("SEND_DATE", the_date);
        fireInsuranceMap.put("SEND_TIME", the_time);
        if (StringUtil.isNullOrEmpty(fireInsuranceQueryMap.get("PARENT_ACCOUNT_CODE"))) {
          fireInsuranceMap.put("AIMPARENT_ACCOUNT_CODE", Constants.EIGHT_SPACE);
          fireInsuranceMap.put("PAR_ACCOUNT_CODE", Constants.EIGHT_SPACE);
        } else {
          // 配信先親代理店組織コード
          fireInsuranceMap.put("AIMPARENT_ACCOUNT_CODE",
              fireInsuranceQueryMap.get("PARENT_ACCOUNT_CODE"));
          // 親代理店組織コード
          fireInsuranceMap.put("PAR_ACCOUNT_CODE",
              fireInsuranceQueryMap.get("PARENT_ACCOUNT_CODE"));
        }
        try {
          Date date = new SimpleDateFormat(DateTimeConstants.DATETIMEFORMAT_DATE_TIME)
              .parse(fireInsuranceQueryMap.get("INSERT_DATETIME"));
          String reception_date =
              new SimpleDateFormat(DateTimeConstants.DATETIMEFORMAT_DATE).format(date);
          // 作成日
          fireInsuranceMap.put("CREATE_DATE", reception_date);
          // 受付日
          fireInsuranceMap.put("RECEIPT_DATE", reception_date);
        } catch (Exception e) {
          fireInsuranceMap.put("CREATE_DATE", Constants.EIGHT_SPACE);
          fireInsuranceMap.put("RECEIPT_DATE", Constants.EIGHT_SPACE);
        }
        // お客さま名
        List<String> custom_namelist = new ArrayList<String>();
        custom_namelist.add(fireInsuranceQueryMap.get("LASTNAME"));
        custom_namelist.add(fireInsuranceQueryMap.get("FIRSTNAME"));
        fireInsuranceMap.put("CUSTOM_NAME", characterMosaic(custom_namelist, Constants.FULL_SPACE));
        // 可変文言１
        if(Constants.CONSTANT_2.equals(fireInsuranceQueryMap.get("AGENCY_EXPLANATION"))) {
          fireInsuranceMap.put("MESSAGE1",
              Constants.DELIVERY_FIRE_INS_MESSAGE_IS2);
        }else if(Constants.CONSTANT_3.equals(fireInsuranceQueryMap.get("AGENCY_EXPLANATION"))) {
          fireInsuranceMap.put("MESSAGE1",
              Constants.DELIVERY_FIRE_INS_MESSAGE_IS3);
        }
        // リーズ番号
        if (StringUtils.isNullOrEmpty(fireInsuranceQueryMap.get("FORM_CODE"))
            || StringUtils.isNullOrEmpty(fireInsuranceQueryMap.get("INSERT_NUMBER"))) {
          fireInsuranceMap.put("LEEDS_NUMBER", Constants.TWELVE_SPACE);
        } else {
          fireInsuranceMap.put("LEEDS_NUMBER",
              fireInsuranceQueryMap.get("FORM_CODE") + fireInsuranceQueryMap.get("INSERT_NUMBER"));
        }
        // 提供元
        if (StringUtil.isNullOrEmpty(fireInsuranceQueryMap.get("CUSTOMER_NUMBER"))) {
          fireInsuranceMap.put("PRODUCT_SOURCE", CD101.RECEPTION_DIV_OHP.getName());
        } else {
          fireInsuranceMap.put("PRODUCT_SOURCE", CD101.RECEPTION_DIV_MYPAGE.getName());
        }
        fireInsuranceMap.put("INSURE_KIND", Constants.INSURE_KIND);
        // カナ
        List<String> kanalist = new ArrayList<String>();
        kanalist.add(fireInsuranceQueryMap.get("LASTNAME_KANA"));
        kanalist.add(fireInsuranceQueryMap.get("FIRSTNAME_KANA"));
        fireInsuranceMap.put("KANA", characterMosaic(kanalist, Constants.FULL_SPACE));
        // 郵便番号 （ハイフン付き）
        if (StringUtil.isNullOrEmpty(fireInsuranceQueryMap.get("ZIP_CODE"))) {
          fireInsuranceMap.put("ZIP_HY_CODE", Constants.EIGHT_SPACE);
        } else {
          fireInsuranceMap.put("ZIP_HY_CODE",
              zipCodeConvert(fireInsuranceQueryMap.get("ZIP_CODE")));
        }
        fireInsuranceMap.put("CITY_ADD",fireInsuranceQueryMap.get("ADDRESS1") );
        fireInsuranceMap.put("STREET_ADD",fireInsuranceQueryMap.get("ADDRESS2") );
        fireInsuranceMap.put("APARTMENT_ADD",fireInsuranceQueryMap.get("ADDRESS3") );
        // 性別(漢字)
        try {
          fireInsuranceMap.put("SEX_STR",
              CD105.decode((String) fireInsuranceQueryMap.get("SEX")).getName());
        } catch (Exception e) {
          fireInsuranceMap.put("SEX_STR", Constants.FOUR_SPACE);
        }
        // 生年月日
        fireInsuranceMap.put("BIRTHDAY_VAR", Constants.EIGHT_SPACE);
        // 電話
        fireInsuranceMap.put("TEL_HOME_VAR", fireInsuranceQueryMap.get("TEL_HOME"));
        // 電話(日中連絡先)
        fireInsuranceMap.put("TEL_CONTACT_VAR", fireInsuranceQueryMap.get("TEL_CONTACT"));
        // Fax
        fireInsuranceMap.put("TEL_FAX_VAR", fireInsuranceQueryMap.get("TEL_FAX"));
        // 電子メール
        fireInsuranceMap.put("EMAIL_ADD_VAR", fireInsuranceQueryMap.get("EMAIL_ADD"));
        // 可変文言２
        if (StringUtil.isNullOrEmpty(fireInsuranceQueryMap.get("QUICK_PAGE_ID"))) {
          fireInsuranceMap.put("MESSAGE2", Constants.EMPTY);
        } else {
          fireInsuranceMap.put("MESSAGE2",
              Constants.VARIABLE_MSG2 + Constants.VARIABLE_MSG2_IMAGEURL
                  + Constants.VARIABLE_MSG2_PAGEID + fireInsuranceQueryMap.get("QUICK_PAGE_ID")
                  + Constants.VARIABLE_MSG2_AFFIRM);
        }
        // 受付日時
        try {
          Date date = new SimpleDateFormat(DateTimeConstants.DATETIMEFORMAT_DATE_TIME)
              .parse(fireInsuranceQueryMap.get("INSERT_DATETIME"));
          String insertDate =
              new SimpleDateFormat(DateTimeConstants.DATETIMEFORMAT_ACCEPT_DATE).format(date);
          fireInsuranceMap.put("ACCEPT_DATE", insertDate);
        } catch (Exception e) {
          fireInsuranceMap.put("ACCEPT_DATE", Constants.NINETEEN_SPACE);
        }
      }
      // END
      fireInsuranceMap.put("END", Constants.END);

      // フラグデータ設定
      fireInsuranceMap.put("FORM_CODE", fireInsuranceQueryMap.get("FORM_CODE"));
      fireInsuranceMap.put("INSERT_NUMBER", fireInsuranceQueryMap.get("INSERT_NUMBER"));
      fireInsuranceList.add(fireInsuranceMap);
    }
    return fireInsuranceList;
  }

  /**
   * 集配信システムへファイル転送（お問合せ）バッチ データ転換
   *
   * @param お問合せテーブル（t_insurance_inquiry）から取得データ
   * @return リスト
   */
  public static ArrayList<HashMap<String, String>> getInquiry(
      ArrayList<HashMap<String, String>> inquiryQueryArray) {
    ArrayList<HashMap<String, String>> inquiryList = new ArrayList<HashMap<String, String>>();
    for (HashMap<String, String> dataResult : inquiryQueryArray) {
      HashMap<String, String> inquiryQueryMap = new HashMap<String, String>();
      // null2Blank
      for (Entry<String, String> entry : dataResult.entrySet()) {
        String mapKey = entry.getKey();
        String mapValue = null2Blank((String) entry.getValue());
        inquiryQueryMap.put(mapKey, mapValue);
      }
      HashMap<String, String> inquiryMap = new HashMap<String, String>();
      // 書き込みデータ設定
      // START
      inquiryMap.put("START", Constants.START);
      // 受付区分１
      if (StringUtil.isNullOrEmpty(inquiryQueryMap.get("RECEPTION_DIV"))) {
        inquiryMap.put("RECEPTION_DIV1", CD101.RECEPTION_DIV_OHP.getCode());
      } else {
        inquiryMap.put("RECEPTION_DIV1", inquiryQueryMap.get("RECEPTION_DIV"));
      }
      // 受付区分２
      inquiryMap.put("RECEPTION_DIV2", CD117.RECEPTION_DIV_NOTHING.getCode());
      // 業務区分
      inquiryMap.put("BUSINESS_DIV", CD118.BUSINESS_DIV_INQUIRY.getCode());

      try {
        Date date = new SimpleDateFormat(DateTimeConstants.DATETIMEFORMAT_DATE_TIME)
            .parse(inquiryQueryMap.get("INSERT_DATETIME"));
        String reception_date =
            new SimpleDateFormat(DateTimeConstants.DATETIMEFORMAT_DATE).format(date);
        String reception_time =
            new SimpleDateFormat(DateTimeConstants.DATETIMEFORMAT_TIME4).format(date);
        // 受付日
        inquiryMap.put("RECEPTION_DATE", reception_date);
        // 受付時間
        inquiryMap.put("RECEPTION_TIME", reception_time);
      } catch (Exception e) {
        inquiryMap.put("RECEPTION_DATE", Constants.EIGHT_SPACE);
        inquiryMap.put("RECEPTION_TIME", Constants.FOUR_SPACE);
      }
      // 氏名１
      inquiryMap.put("NAME1", inquiryQueryMap.get("LASTNAME"));
      // 氏名２
      inquiryMap.put("NAME2", inquiryQueryMap.get("FIRSTNAME"));
      // 氏名カナ１
      inquiryMap.put("NAME_KANA1", inquiryQueryMap.get("LASTNAME_KANA"));
      // 氏名カナ２
      inquiryMap.put("NAME_KANA2", inquiryQueryMap.get("FIRSTNAME_KANA"));
      // 郵便番号
      if (StringUtil.isNullOrEmpty(inquiryQueryMap.get("ZIP_CODE"))) {
        inquiryMap.put("ZIP_CODE", Constants.SEVEN_SPACE);
      } else {
        inquiryMap.put("ZIP_CODE", inquiryQueryMap.get("ZIP_CODE"));
      }
      // 自宅電話番号
      inquiryMap.put("TEL_HOME", inquiryQueryMap.get("TEL_HOME"));
      // 連絡先区分
      try {
        inquiryMap.put("CONTACT_CLASSIFY",
            CD104.decode(inquiryQueryMap.get("CONTACT_CLASSIFY")).getCode());
      } catch (Exception e) {
        inquiryMap.put("CONTACT_CLASSIFY", Constants.HALF_SPACE);
      }
      // 連絡先電話番号
      if (StringUtil.isNullOrEmpty(inquiryQueryMap.get("TEL_CONTACT"))) {
        inquiryMap.put("TEL_CONTACT", Constants.EMPTY);
      } else {
        inquiryMap.put("TEL_CONTACT", inquiryQueryMap.get("TEL_CONTACT"));
      }
      // FAX区分
      inquiryMap.put("FAX_CLASSIFY", Constants.HALF_SPACE);
      // 都道府県
      inquiryMap.put("ADDRESS_PREF", inquiryQueryMap.get("ADDRESS_PREF"));
      // 連絡先住所１
      inquiryMap.put("ADDRESS1", inquiryQueryMap.get("ADDRESS1"));
      // 連絡先住所２
      inquiryMap.put("ADDRESS2", inquiryQueryMap.get("ADDRESS2"));
      // 連絡先住所３
      inquiryMap.put("ADDRESS3", inquiryQueryMap.get("ADDRESS3"));
      // メールアドレス
      inquiryMap.put("EMAIL_ADD", inquiryQueryMap.get("EMAIL_ADD"));
      // 性別
      try {
        inquiryMap.put("SEX", CD105.decode(inquiryQueryMap.get("SEX")).getCode());
      } catch (Exception e) {
        inquiryMap.put("SEX", Constants.HALF_SPACE);
      }
      // 業種
      inquiryMap.put("INDUSTRY", inquiryQueryMap.get("INDUSTRY"));
      // 部署名
      inquiryMap.put("DEPARTMENT", inquiryQueryMap.get("DEPARTMENT"));
      // 勤務先名
      inquiryMap.put("COMPANY", inquiryQueryMap.get("COMPANY"));
      // 生年月日
        try {
          Date date = new SimpleDateFormat(DateTimeConstants.DATETIMEFORMAT_NIGHTBATDATE)
              .parse(inquiryQueryMap.get("BIRTHDAY"));
          String birthday =
              new SimpleDateFormat(DateTimeConstants.DATETIMEFORMAT_DATE).format(date);
          inquiryMap.put("BIRTHDAY", birthday);
        } catch (Exception e) {
          inquiryMap.put("BIRTHDAY", Constants.EIGHT_SPACE);
        }
      // 取引区分
      try {
        inquiryMap.put("EXCHANGE", CD103.decode(inquiryQueryMap.get("EXCHANGE")).getCode());
      } catch (Exception e) {
        inquiryMap.put("EXCHANGE", Constants.HALF_SPACE);
      }
      // 顧客番号
      inquiryMap.put("CUSTOMER_NUMBER", inquiryQueryMap.get("CUSTOMER_NUMBER"));
      // お問合せ内容
      inquiryMap.put("CONTENTS", inquiryQueryMap.get("CONTENTS"));
      // お問合せ区分名
      inquiryMap.put("INQUIRY_NAME", inquiryQueryMap.get("INQUIRY_NAME"));
      // 証券番号
      inquiryMap.put("BOND_NUMBER", inquiryQueryMap.get("BOND_NUMBER"));
      // END
      inquiryMap.put("END", Constants.END);

      // フラグデータ設定
      inquiryMap.put("FORM_CODE", inquiryQueryMap.get("FORM_CODE"));
      inquiryMap.put("INSERT_NUMBER", inquiryQueryMap.get("INSERT_NUMBER"));
      inquiryList.add(inquiryMap);
    }
    return inquiryList;
  }

  /**
   * 集配信システムへファイル転送（お問合せ）バッチ データ転換
   *
   * @param (inquiry)Englishテーブル（t_english_insurance_inquiry）から取得データ
   * @return リスト
   */
  public static ArrayList<HashMap<String, String>> getEnglishInquiry(
      ArrayList<HashMap<String, String>> inquiryQueryArray) {
    ArrayList<HashMap<String, String>> inquiryList = new ArrayList<HashMap<String, String>>();

      for (HashMap<String, String> dataResult : inquiryQueryArray) {
        HashMap<String, String> inquiryQueryMap = new HashMap<String, String>();
        // null2Blank
        for (Entry<String, String> entry : dataResult.entrySet()) {
          String mapKey = entry.getKey();
          String mapValue = null2Blank((String) entry.getValue());
          inquiryQueryMap.put(mapKey, mapValue);
        }
      HashMap<String, String> inquiryMap = new HashMap<String, String>();
      // 書き込みデータ設定
      // START
      inquiryMap.put("START", Constants.START);
      if (StringUtil.isNullOrEmpty(inquiryQueryMap.get("RECEPTION_DIV"))) {
        inquiryMap.put("RECEPTION_DIV1", CD101.RECEPTION_DIV_OHP.getCode());
      } else {
        inquiryMap.put("RECEPTION_DIV1", inquiryQueryMap.get("RECEPTION_DIV"));
      }
      inquiryMap.put("RECEPTION_DIV2", CD117.RECEPTION_DIV_NOTHING.getCode());
      inquiryMap.put("BUSINESS_DIV", CD118.BUSINESS_DIV_INQUIRY.getCode());
      try {
        Date date = new SimpleDateFormat(DateTimeConstants.DATETIMEFORMAT_DATE_TIME)
            .parse(inquiryQueryMap.get("INSERT_DATETIME"));
        String reception_date =
            new SimpleDateFormat(DateTimeConstants.DATETIMEFORMAT_DATE).format(date);
        String reception_time =
            new SimpleDateFormat(DateTimeConstants.DATETIMEFORMAT_TIME4).format(date);
        // 受付日
        inquiryMap.put("RECEPTION_DATE", reception_date);
        // 受付時間
        inquiryMap.put("RECEPTION_TIME", reception_time);
      } catch (Exception e) {
        inquiryMap.put("RECEPTION_DATE", Constants.EIGHT_SPACE);
        inquiryMap.put("RECEPTION_TIME", Constants.FOUR_SPACE);
      }
      inquiryMap.put("HALF_NAME_KANA1", inquiryQueryMap.get("FIRSTNAME"));
      inquiryMap.put("HALF_NAME_KANA2", inquiryQueryMap.get("LASTNAME"));
      inquiryMap.put("ZIP_CODE", Constants.SEVEN_SPACE);
      inquiryMap.put("CONTACT_CLASSIFY", Constants.HALF_SPACE);
      inquiryMap.put("FAX_CLASSIFY", Constants.HALF_SPACE);
      inquiryMap.put("ADDRESS_ENG", inquiryQueryMap.get("ADDRESS_ENG"));
      inquiryMap.put("EMAIL_ADD", inquiryQueryMap.get("EMAIL_ADD"));
      try {
        inquiryMap.put("SEX", CD105.decode(inquiryQueryMap.get("SEX")).getCode());
      } catch (Exception e) {
        inquiryMap.put("SEX", Constants.HALF_SPACE);
      }
      inquiryMap.put("BIRTHDAY", Constants.EIGHT_SPACE);
      inquiryMap.put("EXCHANGE", Constants.HALF_SPACE);
      inquiryMap.put("CONTENTS", inquiryQueryMap.get("CONTENTS"));
      // END
      inquiryMap.put("END", Constants.END);
      // フラグデータ設定
      inquiryMap.put("FORM_CODE", inquiryQueryMap.get("FORM_CODE"));
      inquiryMap.put("INSERT_NUMBER", inquiryQueryMap.get("INSERT_NUMBER"));
      inquiryList.add(inquiryMap);
    }
    return inquiryList;
  }

  /**
   * 夜間バッチ通知メール送信バッチ データ転換
   *
   * @param お問合せテーブル（t_insurance_inquiry）から取得データ
   * @return リスト
   */
  public static ArrayList<HashMap<String, String>> getInquiryInterface(
      ArrayList<HashMap<String, String>> inquiryInterfaceQuery) {
    ArrayList<HashMap<String, String>> attachmentList = new ArrayList<HashMap<String, String>>();

    for (HashMap<String, String> dataResult : inquiryInterfaceQuery) {
      HashMap<String, String> inquiryMap = new HashMap<String, String>();
      // null2Blank
      for (Entry<String, String> entry : dataResult.entrySet()) {
        String mapKey = entry.getKey();
        String mapValue = null2Blank((String) entry.getValue());
        inquiryMap.put(mapKey, mapValue);
      }
      HashMap<String, String> attachmentMap = new HashMap<String, String>();

      // 書き込みデータ設定
      try {
        Date date = new SimpleDateFormat(DateTimeConstants.DATETIMEFORMAT_DATE_TIME)
            .parse(inquiryMap.get("INSERT_DATETIME"));
        String reception_date =
            new SimpleDateFormat(DateTimeConstants.DATETIMEFORMAT_NIGHTBATDATE).format(date);
        String reception_time =
            new SimpleDateFormat(DateTimeConstants.DATETIMEFORMAT_NIGHTBATTIME).format(date);
        attachmentMap.put("DATE", reception_date);
        attachmentMap.put("TIME", reception_time);
      } catch (Exception e) {
        attachmentMap.put("DATE", Constants.EMPTY);
        attachmentMap.put("TIME", Constants.EMPTY);
      }
      attachmentMap.put("INQUIRY_NAME",inquiryMap.get("INQUIRY_NAME"));
      attachmentMap.put("CONTENTS",inquiryMap.get("CONTENTS"));
      try {
        attachmentMap.put("EXCHANGE", CD103.decode(inquiryMap.get("EXCHANGE")).getName());
      } catch (Exception e) {
        attachmentMap.put("EXCHANGE", Constants.EMPTY);
      }
      attachmentMap.put("BOND_NUMBER", inquiryMap.get("BOND_NUMBER"));
      attachmentMap.put("CUSTOMER_DIV", inquiryMap.get("CUSTOMER_DIV"));
      List<String> namelist = new ArrayList<String>();
      namelist.add(inquiryMap.get("LASTNAME"));
      namelist.add(inquiryMap.get("FIRSTNAME"));
      attachmentMap.put("NAME", characterMosaic(namelist, Constants.HALF_SPACE));

      List<String> name_kanalist = new ArrayList<String>();
      name_kanalist.add(inquiryMap.get("LASTNAME_KANA"));
      name_kanalist.add(inquiryMap.get("FIRSTNAME_KANA"));
      attachmentMap.put("NAME_KANA", characterMosaic(name_kanalist, Constants.HALF_SPACE));

      attachmentMap.put("BIRTHDAY", inquiryMap.get("BIRTHDAY"));
      try {
        attachmentMap.put("SEX", CD105.decode(inquiryMap.get("SEX")).getName());
      } catch (Exception e) {
        attachmentMap.put("SEX", Constants.EMPTY);
      }
      attachmentMap.put("ZIP_CODE", inquiryMap.get("ZIP_CODE"));
      attachmentMap.put("ADDRESS",
          inquiryMap.get("ADDRESS_PREF") + inquiryMap.get("ADDRESS1") + inquiryMap.get("ADDRESS2")
              + inquiryMap.get("ADDRESS3"));

      attachmentMap.put("TEL_HOME", inquiryMap.get("TEL_HOME"));
      String contact_classify = null;
      try {
        contact_classify = CD104.decode(inquiryMap.get("CONTACT_CLASSIFY")).getName();
      } catch (Exception e) {
        contact_classify = Constants.EMPTY;
      }
      List<String> contactlist = new ArrayList<String>();
      contactlist.add(inquiryMap.get("TEL_CONTACT"));
      contactlist.add(contact_classify);
      attachmentMap.put("CONTACT", characterMosaic(contactlist, Constants.FULL_SPACE));

      attachmentMap.put("EMAIL_ADD", inquiryMap.get("EMAIL_ADD"));
      attachmentMap.put("COMPANY", inquiryMap.get("COMPANY"));
      attachmentMap.put("DEPARTMENT", inquiryMap.get("DEPARTMENT"));
      attachmentMap.put("INDUSTRY", inquiryMap.get("INDUSTRY"));
      // フラグデータ設定
      attachmentMap.put("FORM_CODE", inquiryMap.get("FORM_CODE"));
      attachmentMap.put("INSERT_NUMBER", inquiryMap.get("INSERT_NUMBER"));
      // メソッド名
      String thismethodName = Thread.currentThread().getStackTrace()[1].getMethodName();
      attachmentMap.put("METHODNAME", thismethodName);
      attachmentList.add(attachmentMap);
    }
    return attachmentList;
  }

  /**
   * 夜間バッチ通知メール送信バッチ データ転換
   *
   * @param 火災保険加入相談テーブル（t_fire_insurance_inquiry）から取得データ
   * @return リスト
   */
  public static ArrayList<HashMap<String, String>> getFireInsuranceInquiryQuery(
      ArrayList<HashMap<String, String>> fireInsuranceInquiryQuery) {
    ArrayList<HashMap<String, String>> attachmentList = new ArrayList<HashMap<String, String>>();
    for (HashMap<String, String> dataResult : fireInsuranceInquiryQuery) {
      // null2Blank
      HashMap<String, String> fireInsuranceMap = new HashMap<String, String>();
        for (Entry<String, String> entry : dataResult.entrySet()) {
          String mapKey = entry.getKey();
          String mapValue = null2Blank((String) entry.getValue());
          fireInsuranceMap.put(mapKey, mapValue);
        }
        HashMap<String, String> attachmentMap = new HashMap<String, String>();

      // 書き込みデータ設定
      try {
        Date date = new SimpleDateFormat(DateTimeConstants.DATETIMEFORMAT_DATE_TIME)
            .parse(fireInsuranceMap.get("INSERT_DATETIME"));
        String reception_date =
            new SimpleDateFormat(DateTimeConstants.DATETIMEFORMAT_NIGHTBATDATE).format(date);
        String reception_time =
            new SimpleDateFormat(DateTimeConstants.DATETIMEFORMAT_NIGHTBATTIME).format(date);
        attachmentMap.put("DATE", reception_date);
        attachmentMap.put("TIME", reception_time);
      } catch (Exception e) {
        attachmentMap.put("DATE", Constants.EMPTY);
        attachmentMap.put("TIME", Constants.EMPTY);
      }
      List<String> namelist = new ArrayList<String>();
      namelist.add(fireInsuranceMap.get("LASTNAME"));
      namelist.add(fireInsuranceMap.get("FIRSTNAME"));
      attachmentMap.put("NAME", characterMosaic(namelist, Constants.HALF_SPACE));

      List<String> name_kanalist = new ArrayList<String>();
      name_kanalist.add(fireInsuranceMap.get("LASTNAME_KANA"));
      name_kanalist.add(fireInsuranceMap.get("FIRSTNAME_KANA"));
      attachmentMap.put("NAME_KANA", characterMosaic(name_kanalist, Constants.HALF_SPACE));
      try {
        attachmentMap.put("SEX", CD105.decode(fireInsuranceMap.get("SEX")).getName());
      } catch (Exception e) {
        attachmentMap.put("SEX", Constants.EMPTY);
      }
      attachmentMap.put("ZIP_CODE", fireInsuranceMap.get("ZIP_CODE"));
      attachmentMap.put("ADDRESS",
          fireInsuranceMap.get("ADDRESS_PREF") + fireInsuranceMap.get("ADDRESS1")
              + fireInsuranceMap.get("ADDRESS2")
              + fireInsuranceMap.get("ADDRESS3"));
      attachmentMap.put("TEL_HOME",fireInsuranceMap.get("TEL_HOME"));
      attachmentMap.put("TEL_CONTACT",fireInsuranceMap.get("TEL_CONTACT"));
      attachmentMap.put("TEL_FAX",fireInsuranceMap.get("TEL_FAX"));
      attachmentMap.put("EMAIL_ADD", fireInsuranceMap.get("EMAIL_ADD"));
      attachmentMap.put("AGENCY_NAME", fireInsuranceMap.get("AGENCY_NAME"));
      attachmentMap.put("AGENCY_ADDRESS", fireInsuranceMap.get("AGENCY_ADDRESS"));
      attachmentMap.put("AGENCY_TEL", fireInsuranceMap.get("AGENCY_TEL"));
      attachmentMap.put("AGENCY_URL", fireInsuranceMap.get("AGENCY_URL"));
      attachmentMap.put("AGENCY_EMAILADDRESS", fireInsuranceMap.get("AGENCY_EMAILADDRESS"));
      attachmentMap.put("QUICK_PAGE_ID", fireInsuranceMap.get("QUICK_PAGE_ID"));

      // フラグデータ設定
      attachmentMap.put("FORM_CODE", fireInsuranceMap.get("FORM_CODE"));
      attachmentMap.put("INSERT_NUMBER", fireInsuranceMap.get("INSERT_NUMBER"));
      attachmentMap.put("INSERT_DATETIME", fireInsuranceMap.get("INSERT_DATETIME"));
      // メソッド名
      String thismethodName = Thread.currentThread().getStackTrace()[1].getMethodName();
      attachmentMap.put("METHODNAME", thismethodName);
      attachmentList.add(attachmentMap);
    }
    return attachmentList;
  }

  /**
   * 夜間バッチ通知メール送信バッチ データ転換
   *
   * @param 英語お問合せテーブル（t_english_insurance_inquiry）から取得データ
   * @return リスト
   */
  public static ArrayList<HashMap<String, String>> getEnglishInquiryInterfaceQuery(
      ArrayList<HashMap<String, String>> englishInquiryInterfaceQuery) {
    ArrayList<HashMap<String, String>> attachmentList = new ArrayList<HashMap<String, String>>();
    for (HashMap<String, String> dataResult : englishInquiryInterfaceQuery) {
      HashMap<String, String> englishInquiryMap = new HashMap<String, String>();
      // null2Blank
      for (Entry<String, String> entry : dataResult.entrySet()) {
        String mapKey = entry.getKey();
        String mapValue = null2Blank((String) entry.getValue());
        englishInquiryMap.put(mapKey, mapValue);
      }
      HashMap<String, String> attachmentMap = new HashMap<String, String>();

      // 書き込みデータ設定
      try {
        Date date = new SimpleDateFormat(DateTimeConstants.DATETIMEFORMAT_DATE_TIME)
            .parse(englishInquiryMap.get("INSERT_DATETIME"));
        String reception_date =
            new SimpleDateFormat(DateTimeConstants.DATETIMEFORMAT_NIGHTBATDATE).format(date);
        String reception_time =
            new SimpleDateFormat(DateTimeConstants.DATETIMEFORMAT_NIGHTBATTIME).format(date);
        attachmentMap.put("DATE", reception_date);
        attachmentMap.put("TIME", reception_time);
      } catch (Exception e) {
        attachmentMap.put("DATE", Constants.EMPTY);
        attachmentMap.put("TIME", Constants.EMPTY);
      }
      attachmentMap.put("CONTENTS", englishInquiryMap.get("CONTENTS"));
      List<String> namelist = new ArrayList<String>();
      namelist.add(englishInquiryMap.get("FIRSTNAME"));
      namelist.add(englishInquiryMap.get("LASTNAME"));
      attachmentMap.put("NAME", characterMosaic(namelist, Constants.HALF_SPACE));

      attachmentMap.put("AGE", englishInquiryMap.get("AGE"));
      try {
        attachmentMap.put("SEX",
            CD125.decode(englishInquiryMap.get("SEX")).getName());
      } catch (Exception e) {
        attachmentMap.put("SEX", Constants.EMPTY);
      }
      attachmentMap.put("ADDRESS", englishInquiryMap.get("ADDRESS_ENG"));
      attachmentMap.put("EMAIL_ADD", englishInquiryMap.get("EMAIL_ADD"));

      // フラグデータ設定
      attachmentMap.put("FORM_CODE", englishInquiryMap.get("FORM_CODE"));
      attachmentMap.put("INSERT_NUMBER", englishInquiryMap.get("INSERT_NUMBER"));
      attachmentMap.put("INSERT_DATETIME", englishInquiryMap.get("INSERT_DATETIME"));
      // メソッド名
      String thismethodName = Thread.currentThread().getStackTrace()[1].getMethodName();
      attachmentMap.put("METHODNAME", thismethodName);
      attachmentList.add(attachmentMap);
    }
    return attachmentList;
  }

  /**
   * 夜間バッチ通知メール送信バッチ データ転換
   *
   * @param 美術館お問合せテーブルテーブルテーブル（t_museum_inquiry）から取得データ
   * @return リスト
   */
  public static ArrayList<HashMap<String, String>> getMuseumInquiryQuery(
      ArrayList<HashMap<String, String>> museumInquiryQuery) {
    ArrayList<HashMap<String, String>> attachmentList = new ArrayList<HashMap<String, String>>();
    for (HashMap<String, String> dataResult : museumInquiryQuery) {
      HashMap<String, String> museumInquiryMap = new HashMap<String, String>();
      // null2Blank
      for (Entry<String, String> entry : dataResult.entrySet()) {
        String mapKey = entry.getKey();
        String mapValue = null2Blank((String) entry.getValue());
        museumInquiryMap.put(mapKey, mapValue);
      }
      HashMap<String, String> attachmentMap = new HashMap<String, String>();
      // 書き込みデータ設定
      try {
        Date date = new SimpleDateFormat(DateTimeConstants.DATETIMEFORMAT_DATE_TIME)
            .parse(museumInquiryMap.get("INSERT_DATETIME"));
        String reception_date =
            new SimpleDateFormat(DateTimeConstants.DATETIMEFORMAT_NIGHTBATDATE).format(date);
        String reception_time =
            new SimpleDateFormat(DateTimeConstants.DATETIMEFORMAT_NIGHTBATTIME).format(date);
        attachmentMap.put("DATE", reception_date);
        attachmentMap.put("TIME", reception_time);
      } catch (Exception e) {
        attachmentMap.put("DATE", Constants.EMPTY);
        attachmentMap.put("TIME", Constants.EMPTY);
      }
      List<String> namelist = new ArrayList<String>();
      namelist.add(museumInquiryMap.get("LASTNAME"));
      namelist.add(museumInquiryMap.get("FIRSTNAME"));
      attachmentMap.put("NAME", characterMosaic(namelist, Constants.HALF_SPACE));

      List<String> name_kanalist = new ArrayList<String>();
      name_kanalist.add(museumInquiryMap.get("LASTNAME_KANA"));
      name_kanalist.add(museumInquiryMap.get("FIRSTNAME_KANA"));
      attachmentMap.put("NAME_KANA", characterMosaic(name_kanalist, Constants.HALF_SPACE));

      attachmentMap.put("ZIP_CODE",museumInquiryMap.get("ZIP_CODE"));

      attachmentMap.put("ADDRESS",museumInquiryMap.get("ADDRESS_PREF")
          + museumInquiryMap.get("ADDRESS1") + museumInquiryMap.get("ADDRESS2")
          + museumInquiryMap.get("ADDRESS3"));
      try {
        attachmentMap.put("CONTACT_CLASSIFY",
            CD012.decode(museumInquiryMap.get("CONTACT_CLASSIFY")).getName());
      } catch (Exception e) {
        attachmentMap.put("CONTACT_CLASSIFY",Constants.EMPTY);
      }
      attachmentMap.put("TEL_CONTACT",museumInquiryMap.get("TEL_CONTACT"));
      attachmentMap.put("EMAIL_ADD",museumInquiryMap.get("EMAIL_ADD"));
      attachmentMap.put("OCCUPATION",museumInquiryMap.get("OCCUPATION"));
      attachmentMap.put("INDUSTRY",museumInquiryMap.get("INDUSTRY"));
      attachmentMap.put("COMPANY",museumInquiryMap.get("COMPANY"));
      attachmentMap.put("DEPARTMENT",museumInquiryMap.get("DEPARTMENT"));
      attachmentMap.put("BIRTHDAY",museumInquiryMap.get("BIRTHDAY"));
      attachmentMap.put("CONTENTS",museumInquiryMap.get("CONTENTS"));

      // フラグデータ設定
      attachmentMap.put("FORM_CODE", museumInquiryMap.get("FORM_CODE"));
      attachmentMap.put("INSERT_NUMBER", museumInquiryMap.get("INSERT_NUMBER"));
      attachmentMap.put("INSERT_DATETIME", museumInquiryMap.get("INSERT_DATETIME"));
      // メソッド名
      String thismethodName = Thread.currentThread().getStackTrace()[1].getMethodName();
      attachmentMap.put("METHODNAME", thismethodName);
      attachmentList.add(attachmentMap);
    }
    return attachmentList;
  }

  /**
   * 夜間バッチ通知メール送信バッチ データ転換
   *
   * @param 美術館英語お問合せテーブルテーブル（t_english_insurance_inquiry）から取得データ
   * @return リスト
   */
  public static ArrayList<HashMap<String, String>> getEnglishMuseumInquiryQuery(
      ArrayList<HashMap<String, String>> englishMuseumInquiryQuery) {
    ArrayList<HashMap<String, String>> attachmentList = new ArrayList<HashMap<String, String>>();
    for (HashMap<String, String> dataResult : englishMuseumInquiryQuery) {
      HashMap<String, String> englishMuseumInquiryMap = new HashMap<String, String>();
      // null2Blank
      for (Entry<String, String> entry : dataResult.entrySet()) {
        String mapKey = entry.getKey();
        String mapValue = null2Blank((String) entry.getValue());
        englishMuseumInquiryMap.put(mapKey, mapValue);
      }
      HashMap<String, String> attachmentMap = new HashMap<String, String>();
      // 書き込みデータ設定
      try {
        Date date = new SimpleDateFormat(DateTimeConstants.DATETIMEFORMAT_DATE_TIME)
            .parse(englishMuseumInquiryMap.get("INSERT_DATETIME"));
        String reception_date =
            new SimpleDateFormat(DateTimeConstants.DATETIMEFORMAT_NIGHTBATDATE).format(date);
        String reception_time =
            new SimpleDateFormat(DateTimeConstants.DATETIMEFORMAT_NIGHTBATTIME).format(date);
        attachmentMap.put("DATE", reception_date);
        attachmentMap.put("TIME", reception_time);
      } catch (Exception e) {
        attachmentMap.put("DATE", Constants.EMPTY);
        attachmentMap.put("TIME", Constants.EMPTY);
      }
      attachmentMap.put("EMAIL_ADD",englishMuseumInquiryMap.get("EMAIL_ADD"));
      attachmentMap.put("CONTENTS",englishMuseumInquiryMap.get("CONTENTS"));
      List<String> namelist = new ArrayList<String>();
      namelist.add(englishMuseumInquiryMap.get("FIRSTNAME"));
      namelist.add(englishMuseumInquiryMap.get("LASTNAME"));
      attachmentMap.put("NAME", characterMosaic(namelist, Constants.HALF_SPACE));
      attachmentMap.put("AGE",englishMuseumInquiryMap.get("AGE"));
      attachmentMap.put("ADDRESS",englishMuseumInquiryMap.get("ADDRESS_ENG"));

      // フラグデータ設定
      attachmentMap.put("FORM_CODE", englishMuseumInquiryMap.get("FORM_CODE"));
      attachmentMap.put("INSERT_NUMBER", englishMuseumInquiryMap.get("INSERT_NUMBER"));
      attachmentMap.put("INSERT_DATETIME", englishMuseumInquiryMap.get("INSERT_DATETIME"));
      // メソッド名
      String thismethodName = Thread.currentThread().getStackTrace()[1].getMethodName();
      attachmentMap.put("METHODNAME", thismethodName);
      attachmentList.add(attachmentMap);
    }
    return attachmentList;
  }

  /**
   * リマインドファイル転送バッチ データ転換
   *
   * @param 火災保険加入相談テーブル（t_fire_insurance_inquiry）から取得データ
   * @return リスト
   */
  public static ArrayList<HashMap<String, String>> getRemind(
      ArrayList<HashMap<String, String>> fireInsuranceInquiryQuery) {
    ArrayList<HashMap<String, String>> remindList = new ArrayList<HashMap<String, String>>();

    // ファイルに書き込みデータ配列
    for (HashMap<String, String> dataResult : fireInsuranceInquiryQuery) {
      HashMap<String, String> fireInsuranceMap = new HashMap<String, String>();
      // null2Blank
      for (Entry<String, String> entry : dataResult.entrySet()) {
        String mapKey = entry.getKey();
        String mapValue = null2Blank((String) entry.getValue());
        fireInsuranceMap.put(mapKey, mapValue);
      }
      HashMap<String, String> remindMap = new HashMap<String, String>();
      // リーズ番号
      List<String> leads_numberlist = new ArrayList<String>();
      leads_numberlist.add(fireInsuranceMap.get("FORM_CODE"));
      leads_numberlist.add(fireInsuranceMap.get("INSERT_NUMBER"));
      remindMap.put("LEADS_NUMBER", characterMosaic(leads_numberlist, Constants.EMPTY));
      // 顧客番号
      remindMap.put("CUSTOMER_NUMBER", fireInsuranceMap.get("CUSTOMER_NUMBER"));
      // 顧客氏名
      List<String> customer_namelist = new ArrayList<String>();
      customer_namelist.add(fireInsuranceMap.get("LASTNAME"));
      customer_namelist.add(fireInsuranceMap.get("FIRSTNAME"));
      remindMap.put("CUSTOMER_NAME", characterMosaic(customer_namelist, Constants.FULL_SPACE));

      // 顧客住所
      remindMap.put("CUSTOMER_ADDRESS",
            fireInsuranceMap.get("ADDRESS_PREF") + fireInsuranceMap.get("ADDRESS1")
                + fireInsuranceMap.get("ADDRESS2")
                + fireInsuranceMap.get("ADDRESS3"));
      // 顧客連絡先電話番号
      remindMap.put("CUSTOMER_TEL", fireInsuranceMap.get("TEL_HOME"));
      // サブシステム区分
      remindMap.put("SUBSYSTEM_DIV", fireInsuranceMap.get("FORM_CODE"));
      // ルート区分
      try {
        remindMap.put("ROOT_DIV", CD108.decode(fireInsuranceMap.get("ROOT_DIV")).getCode());
      } catch (Exception e) {
        remindMap.put("ROOT_DIV",Constants.EMPTY);
      }
      // 日付
      try {
        Date date = new SimpleDateFormat(DateTimeConstants.DATETIMEFORMAT_DATE_TIME)
            .parse(fireInsuranceMap.get("INSERT_DATETIME"));
        String insertDate =
            new SimpleDateFormat(DateTimeConstants.DATETIMEFORMAT_DATE).format(date);
        remindMap.put("REMIND_DATE", insertDate);
      } catch (Exception e) {
        remindMap.put("REMIND_DATE", Constants.EMPTY);
      }
      // 次契約始期日
      remindMap.put("NEXTINCEPTION_DATE", Constants.EIGHT_SPACE);
      remindMap.put("PRODUCT_CODE01", Constants.TWENTYFOUR);
      for (int i = 2; i < 21; i++) {
        if (i < 10) {
          remindMap.put("PRODUCT_CODE0" + String.valueOf(i), Constants.TWO_SPACE);
        } else {
          remindMap.put("PRODUCT_CODE" + String.valueOf(i), Constants.TWO_SPACE);
        }

      }

      // 見積タイプ
      remindMap.put("QUOTE_TYPE", Constants.HALF_SPACE);
      // 代理店連番
      remindMap.put("AGENT_NUMBER", fireInsuranceMap.get("AGENCY_NUMBER"));
      // 親代理店組織コード
      remindMap.put("PARENT_ACCOUNT_CODE", fireInsuranceMap.get("PARENT_ACCOUNT_CODE"));
      remindList.add(remindMap);
    }
    return remindList;
  }

  /**
   * データを作成する
   */
  private static String characterMosaic(List<String> list, String divider) {

    String result = Constants.EMPTY;
    if (list == null || list.size() == 0) {
      return result;
    }
    int i = 0;
    while (i < list.size()) {
      if (StringUtil.isNullOrEmpty(list.get(i))) {
        result = Constants.EMPTY;
        break;
      } else {
        result = result + list.get(i) + divider;
      }
      i++;
    }
    if ((i == list.size()) && (result.indexOf(divider) > -1)) {
      result = result.substring(0, result.length() - divider.length());
    }
    return result;
  }

  /**
   * 郵便番号を作成する
   */
  private static String zipCodeConvert(String zipCode) {
    if (!(StringUtil.isNullOrEmpty(zipCode))) {
      if ((Constants.EMPTY).equals(zipCode.trim())) {
        return Constants.EMPTY;
      }
      if (zipCode.length() >= 4) {
        return zipCode.substring(0, 3) + "-" + zipCode.substring(3);
      }
      return zipCode;
    }
    return null2Blank(zipCode);
  }

  /**
   * NULLを作成する
   */
  private static String null2Blank(String str) {
    if (str == null) {
      return Constants.EMPTY;
    }
    return str;
  }

}
