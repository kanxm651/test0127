package jp.co.sj.xop.batch.tasklet;

import org.springframework.stereotype.Component;

/**
 * 出力する項目の加工処理.
 *
 * @author SSD
 *
 */
@Component
public class BaseWriterImpl {

}
