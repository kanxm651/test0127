package jp.co.sj.xop;

import java.lang.reflect.Method;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import jp.co.sj.xop.batch.common.constants.Constants;
import jp.co.sj.xop.batch.service.IsRunBatch;

/**
 * バッチ全体を制御するクラス.
 *
 * @author SSD
 *
 */

@SpringBootApplication
public class SpringBatchApplication {
  /**
   * ロガー.
   */
  private static final Logger logger = LoggerFactory.getLogger(SpringBatchApplication.class);

  /**
   * バッチ起動
   *
   */
  public static void main(String[] args) {
    try {
      // バッチ計画停止有無チェック
      IsRunBatch IsRunBatch = new IsRunBatch();
      if (IsRunBatch.isBatchOutage(args[0])) {
        // バッチ計画停止ログを出力
        logger.info(Constants.JOB_NAME_JAP.get(args[0]) + Constants.BATCH_OUTAGE_MSG);
      } else {
        // 実行パラメータ名を取得する
        Class<?> controller = Class.forName(Constants.JOB_NAME.get(args[0]));
        BaseController baseController =
            (BaseController) controller.getDeclaredConstructor().newInstance();
        // 実行パラメータ名より、バッチを起動する
        Method mainMethod = controller.getMethod("main", String[].class);
        mainMethod.invoke(baseController, new Object[] {args});
      }
    } catch (Exception e) {
      // バッチ異常終了ログを出力
      logger.error(Constants.BATCH_ERROR_STOP_MSG, e);
    }
  }
}
