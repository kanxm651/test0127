package jp.co.sj.xop.batch.tasklet;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import javax.sql.DataSource;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;
import jp.co.sj.xop.batch.common.constants.Constants;
import jp.co.sj.xop.batch.jdbc.BaseUpdate;
import jp.co.sj.xop.batch.jdbc.DataDelDelete;
import jp.co.sj.xop.batch.jdbc.DataDelDeleteBatch;
import jp.co.sj.xop.batch.service.SqlLoaderService;

/**
 * 不要データ削除バッチ 出力処理
 *
 * @author SSD
 *
 */
@Component
public class RegularDelDataWriter extends BaseDataWriter {
  /**
   * ロガー
   */
  private static final Logger logger = LoggerFactory.getLogger(RegularDelDataWriter.class);

  private ExecutionContext executionContext;
  private Connection conn = null;
  // 初回処理かどうかのフラグ
  private boolean firstFlag = true;
  private boolean StepErrorFlag = false;
  private StepExecution stepExecution;

  @Autowired
  public DataSource dataSource;

  @Autowired
  public SqlLoaderService sqlLoaderService;

  /**
   * メッセージソース
   */
  @Autowired
  private MessageSource messagesource;


  @Override
  public void open(ExecutionContext executionContext) {
    this.executionContext = executionContext;
  }

  @BeforeStep
  public void beforeStep(StepExecution stepExecution) {
    this.stepExecution = stepExecution;
  }

  /**
   * 不要データを削除する
   *
   */
  @SuppressWarnings({"rawtypes", "unchecked"})
  @Override
  public void write(List items) throws Exception {
    if (executionContext != null) {

      // 不要データ削除バッチのデータ出力準備
      Map<String, Object> writerParamMap = (Map<String, Object>) items.get(0);
      writerParamMap = (Map<String, Object>) items.get(0);
      String tableNameEN = Constants.EMPTY;
      String conditionDateTime = Constants.EMPTY;
      String tableNameJA = Constants.EMPTY;
      String conditionFlag = Constants.EMPTY;
      String monthsHeld = Constants.EMPTY;
      String rddSysDate = Constants.EMPTY;

      tableNameEN = (String) writerParamMap.get("TABLE_NAME_EN");
      conditionDateTime = (String) writerParamMap.get("CONDITON_DATETIME");
      conditionFlag = writerParamMap.get("CONDITON_FLAG").toString();
      monthsHeld = (String) writerParamMap.get("MONTHS_HELD");
      rddSysDate = (String) writerParamMap.get("RDDSYSDATE");
      tableNameJA = (String) writerParamMap.get("TABLE_NAME_JA");

      String endFlag = Constants.EMPTY;
      String errorFlag = Constants.EMPTY;
      endFlag = (String) writerParamMap.get("END_FLAG");
      errorFlag = (String) writerParamMap.get("ERROR_FLAG");
      List<String> condtionList = new ArrayList<String>();
      condtionList.add(tableNameEN);
      condtionList.add(conditionDateTime);
      condtionList.add(conditionFlag);
      condtionList.add(monthsHeld);
      condtionList.add(rddSysDate);
      if (StringUtils.isEmpty(errorFlag)) {
        try {
          // 初回処理否か判断
          if (firstFlag) {
            conn = dataSource.getConnection();
            firstFlag = false;
          }
          int deleteCount = 0;
          if ("batch_job_execution".equals(tableNameEN)) {
            // システムテーブルを一括削除する。
            BaseUpdate dataDelDeleteBatch = new DataDelDeleteBatch();
            // データを削除する。
            deleteCount = dataDelDeleteBatch.execute(condtionList, conn, sqlLoaderService);
          } else {
            // フォームテーブルを一つずつ削除する。
            BaseUpdate dataDelDelete = new DataDelDelete();
            // データを削除する。
            deleteCount = dataDelDelete.execute(condtionList, conn, sqlLoaderService);
          }
          // 削除成功の場合、ログ出力
          logger.info(messagesource.getMessage("message.LOGMSG0022I",
              new String[] {tableNameJA, String.valueOf(deleteCount)}, Locale.JAPAN));
          if ("END".equals(endFlag)) {
            conn.close();
          }
        } catch (Exception e) {
          // 削除失敗の場合、ログ出力
          logger.error(messagesource.getMessage("message.LOGMSG0011E", new String[] {tableNameJA},
              Locale.JAPAN), e);
          StepErrorFlag = true;
        }
      } else {
        StepErrorFlag = true;
      }
      if ("END".equals(endFlag) && StepErrorFlag == true) {
        stepExecution.setExitStatus(ExitStatus.FAILED);
      }
    }
  }
}
