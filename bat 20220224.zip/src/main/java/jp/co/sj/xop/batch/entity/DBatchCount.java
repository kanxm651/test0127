package jp.co.sj.xop.batch.entity;

/**
 * SpringBatch JOB履歴クエリ エンティティクラス.
 *
 * @author SSD
 *
 */

public class DBatchCount {

  /**
   * データ件数.
   */
  private Integer cmpCnt;

  public DBatchCount() {}

  /**
   * データ件数を取得する.
   *
   * @return データ件数
   */
  public int getCmpCnt() {

    return cmpCnt;
  }

  /**
   * データ件数を設定する.
   *
   * @param cmpCnts データ件数
   */
  public void setCmpCnt(Integer cmpCnt) {
    this.cmpCnt = cmpCnt;
  }

}
