package jp.co.sj.xop.batch.tasklet;

import org.springframework.stereotype.Component;

/**
 * データ加工処理
 *
 * @author SSD
 *
 */
@Component
public class BaseProcessImpl {

}
