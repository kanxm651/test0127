package jp.co.sj.xop.batch.service;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.DeleteObjectsRequest;
import com.amazonaws.services.s3.model.DeleteObjectsRequest.KeyVersion;
import com.amazonaws.services.s3.model.DeleteObjectsResult;
import com.amazonaws.services.s3.model.GetObjectRequest;
import com.amazonaws.services.s3.model.ObjectListing;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectInputStream;
import com.amazonaws.services.s3.model.S3ObjectSummary;

/**
 * S3 アクセス共通クラス.
 *
 * @author SSD
 */

@Component
public class S3Services {

  private Logger logger = LoggerFactory.getLogger(S3Services.class);

  /**
   * s3クライアント.
   */
  @Autowired
  private AmazonS3 s3Client;

  // パケット名
  @Value("${app.bucketeer_bucket_name}")
  private String bucketName;

  /**
   * S3にファイルが存在するかを確認する.
   *
   * @param keyName ファイル名
   * @return 実行結果（true：存在する，false：存在しない）
   */
  public boolean isFileExists(String keyName) {
    /**
     * ファイルの存在場合、TRUE。存在しない場合、FALSE
     */
    try {
      s3Client.getObjectMetadata(bucketName, keyName);
      return true;
    } catch (AmazonServiceException ase) {
      if (ase.getStatusCode() != 404) {
        logger.error("Caught an AmazonServiceException from GET requests, rejected reasons:");
        logger.error("Error Message: " + ase.getMessage());
        logger.error("HTTP Status Code: " + ase.getStatusCode());
        logger.error("AWS Error Code: " + ase.getErrorCode());
        logger.error("Error Type: " + ase.getErrorType());
        logger.error("Request ID: " + ase.getRequestId());
      }
      return false;
    } catch (AmazonClientException ace) {
      logger.error("Caught an AmazonClientException: ");
      logger.error("Error Message: " + ace.getMessage());
      return false;
    }
  }

  /**
   * S3にファイルをアップロードする.
   *
   * @param keyName ファイル名
   * @param uploadFilePath ファイルパス
   * @return 実行結果（true：成功，false：失敗）
   */
  public boolean uploadFile(String keyName, String uploadFilePath) {

    try {

      File file = new File(uploadFilePath);
      // S3にファイルをアップロードする
      s3Client.putObject(new PutObjectRequest(bucketName, keyName, file));
      return true;
    } catch (AmazonServiceException ase) {
      logger.error("Caught an AmazonServiceException from PUT requests, rejected reasons:");
      logger.error("Error Message: " + ase.getMessage());
      logger.error("HTTP Status Code: " + ase.getStatusCode());
      logger.error("AWS Error Code: " + ase.getErrorCode());
      logger.error("Error Type: " + ase.getErrorType());
      logger.error("Request ID: " + ase.getRequestId());
      return false;
    } catch (AmazonClientException ace) {
      logger.error("Caught an AmazonClientException: ");
      logger.error("Error Message: " + ace.getMessage());
      return false;
    }

  }

  /**
   * S3にファイルをバックアップする.
   *
   * @param bkFileName バックアップファイル名
   * @param uploadFilePath ファイルパス
   * @return 実行結果（true：成功，false：失敗）
   */
  public boolean uploadBackupFile(String bkFileName, String uploadFilePath) {
    try {
      File file = new File(uploadFilePath);
      // S3にファイルをアップロードする
      s3Client.putObject(new PutObjectRequest(bucketName, bkFileName, file));
      return true;
    } catch (AmazonServiceException ase) {
      logger.error("Caught an AmazonServiceException from PUT requests, rejected reasons:");
      logger.error("Error Message: " + ase.getMessage());
      logger.error("HTTP Status Code: " + ase.getStatusCode());
      logger.error("AWS Error Code: " + ase.getErrorCode());
      logger.error("Error Type: " + ase.getErrorType());
      logger.error("Request ID: " + ase.getRequestId());
      return false;
    } catch (AmazonClientException ace) {
      logger.error("Caught an AmazonClientException: ");
      logger.error("Error Message: " + ace.getMessage());
      return false;
    }

  }

  /**
   * S3のファイルを削除する.
   *
   * @param keyName ファイル名
   * @return 実行結果（true：成功，false：失敗）
   */
  public boolean deleteFile(String keyName) {

    try {
      DeleteObjectsRequest request = new DeleteObjectsRequest(bucketName).withKeys(keyName);
      // S3のファイルを削除する
      s3Client.deleteObjects(request);
      return true;
    } catch (AmazonServiceException ase) {
      logger.error("Caught an AmazonServiceException from PUT requests, rejected reasons:");
      logger.error("Error Message: " + ase.getMessage());
      logger.error("HTTP Status Code: " + ase.getStatusCode());
      logger.error("AWS Error Code: " + ase.getErrorCode());
      logger.error("Error Type: " + ase.getErrorType());
      logger.error("Request ID: " + ase.getRequestId());
      return false;
    } catch (AmazonClientException ace) {
      logger.error("Caught an AmazonClientException: ");
      logger.error("Error Message: " + ace.getMessage());
      return false;
    }

  }

  /**
   * S3のファイルを複数削除する.
   *
   * @param keyNames ファイル名リスト
   * @return 実行結果数
   */
  public int deleteFiles(List<String> keyNames) {
    try {
      ArrayList<KeyVersion> keys = new ArrayList<KeyVersion>();
      for (String key : keyNames) {
        keys.add(new KeyVersion(key));
      }
      DeleteObjectsRequest multiObjectDeleteRequest =
          new DeleteObjectsRequest(bucketName).withKeys(keys).withQuiet(false);
      // S3のファイルを削除する
      DeleteObjectsResult delObjRes = s3Client.deleteObjects(multiObjectDeleteRequest);
      int successfulDeletes = delObjRes.getDeletedObjects().size();
      return successfulDeletes;
    } catch (AmazonServiceException ase) {
      logger.error("Caught an AmazonServiceException from PUT requests, rejected reasons:");
      logger.error("Error Message: " + ase.getMessage());
      logger.error("HTTP Status Code: " + ase.getStatusCode());
      logger.error("AWS Error Code: " + ase.getErrorCode());
      logger.error("Error Type: " + ase.getErrorType());
      logger.error("Request ID: " + ase.getRequestId());
      throw ase;
    } catch (AmazonClientException ace) {
      logger.error("Caught an AmazonClientException: ");
      logger.error("Error Message: " + ace.getMessage());
      throw ace;
    }
  }


  /**
   * S3からファイルをダウンロードして、指定したフォルダに保存する.
   *
   * @param filePath 指定したフォルダ
   * @param keyName ファイル名
   * @return 実行結果（true：成功，false：失敗）
   */
  public boolean downloadWriteFile(String filePath, String keyName) {

    try {

      // S3オブジェクトを定義する
      S3Object s3object = s3Client.getObject(new GetObjectRequest(bucketName, keyName));

      // S3から対象ファイルをダウンロードする
      S3ObjectInputStream s3is = s3object.getObjectContent();
      FileOutputStream fos = new FileOutputStream(new File(filePath + keyName));
      byte[] read_buf = new byte[1024];
      int read_len = 0;
      while ((read_len = s3is.read(read_buf)) > 0) {
        fos.write(read_buf, 0, read_len);
      }
      s3is.close();
      fos.close();

      // 正常にダウンロードできた場合、trueを戻す
      return true;

    } catch (AmazonServiceException ase) {
      logger.error("Caught an AmazonServiceException from GET requests, rejected reasons:");
      logger.error("Error Message: " + ase.getMessage());
      logger.error("HTTP Status Code: " + ase.getStatusCode());
      logger.error("AWS Error Code: " + ase.getErrorCode());
      logger.error("Error Type: " + ase.getErrorType());
      logger.error("Request ID: " + ase.getRequestId());
      return false;
    } catch (AmazonClientException ace) {
      logger.error("Caught an AmazonClientException: ");
      logger.error("Error Message: " + ace.getMessage());
      return false;
    } catch (IOException ioe) {
      logger.error("IOE Error Message: " + ioe.getMessage());
      return false;
    }
  }

  /**
   * S3の指定prefixにファイル名を取得する。
   *
   * @param prefix
   * @return List<String>
   */
  public List<String> getFileNameInFolder(String prefix) {
    ObjectListing objects = s3Client.listObjects(bucketName, prefix);
    List<String> keyList = new ArrayList<>();
    do {
      for (S3ObjectSummary objectSummary : objects.getObjectSummaries()) {
        keyList.add(objectSummary.getKey());
      }
      objects = s3Client.listNextBatchOfObjects(objects);
    } while (objects.isTruncated());
    return keyList;
  }

}
