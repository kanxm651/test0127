package jp.co.sj.xop.batch.listener;

import org.springframework.stereotype.Component;
import jp.co.sj.xop.batch.common.constants.Constants;

/**
 * 不要データ削除バッチ のJob前後に実施する処理。
 *
 * @author SSD
 *
 */
@Component
public class RegularDelJobListener extends BaseJobListener {
  public RegularDelJobListener() {
    super.setLogHead(Constants.REGULAR_DEL_JOB_NAME_JAP);
  }
}
