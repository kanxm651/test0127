package jp.co.sj.xop.batch.common.constants;

/**
 * CD108:ルート区分の列挙クラス
 *
 * @author SSD
 *
 */
public enum CD108 implements Encodable<String> {
  /**
   * 公式ウェブサイト
   */
  ROOT_DIV_OHP("1", "公式ウェブサイト"),
  /**
   * マイページ
   */
  ROOT_DIV_MYPAGE("2", "マイページ");

  /** デコーダー */
  private static final Decoder<String, CD108> DECODER = Decoder.create(values());

  /** コード値 */
  private final String code;

  /** 名称 */
  private final String name;

  /**
   * コンストラクタ.
   *
   * @param code コード値
   * @param name 名称
   */
  private CD108(String code, String name) {
    this.code = code;
    this.name = name;
  }

  @Override
  public String getCode() {
    return code;
  }

  /**
   * コード値からEnumクラスを取得する.
   *
   * @param code コード値
   * @return 受領形式Enumクラス
   */
  public static CD108 decode(String code) {
    return DECODER.decode(code);
  }

  /**
   * 名称を取得するメソッド.
   *
   * @return 名称
   */
  public String getName() {
    return name;
  }
}

