package jp.co.sj.xop.batch.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import jp.co.sj.xop.batch.service.SqlLoaderService;

/**
 * おオプションデータを取得するのQueryクラス.
 *
 * @author SSD
 */
@Component
public class DeliveryGetDataOption extends BaseQuery {

  private PreparedStatement preStmt = null;
  private ResultSet rs = null;


  /**
   * SQLファイルローダー
   */
  @Autowired
  SqlLoaderService sqlLoaderService;

  public DeliveryGetDataOption() {
    super.setMsgHead("オプション");
  }

  /**
   * Query実行するメソッドを呼び出す.
   *
   * @return Map<String, String>
   * @throws Exception
   */
  @Override
  protected ArrayList<HashMap<String, String>> subQuery(Map<String, String> condition,
      Connection conn, SqlLoaderService sqlLoaderService) throws Exception {
    ArrayList<HashMap<String, String>> result = new ArrayList<HashMap<String, String>>();
    // SQLを取得
    String sql = sqlLoaderService.getSql("DeliveryGetDataOption");
    try {
      preStmt = conn.prepareStatement(sql);
      preStmt.setString(1, "1");
      rs = preStmt.executeQuery();
      while (rs.next()) {
        // リターン結果にDBから取得したカラム値をセットする
        HashMap<String, String> recMap = new HashMap<String, String>();
        recMap.put("FORM_CODE", rs.getString("FORM_CODE"));
        recMap.put("INFORM_MAIL", rs.getString("INFORM_MAIL"));
        recMap.put("CSV_MAIL", rs.getString("CSV_MAIL"));
        recMap.put("CSV_MAIL_SUBJECT", rs.getString("CSV_MAIL_SUBJECT"));
        recMap.put("RETURN_MAIL_TEMPLATE", rs.getString("RETURN_MAIL_TEMPLATE"));
        recMap.put("INFORM_MAIL_TEMPLATE", rs.getString("INFORM_MAIL_TEMPLATE"));
        recMap.put("SHUHAI_TBL", rs.getString("SHUHAI_TBL"));
        result.add(recMap);
      }
    } finally {
      rs.close();
      preStmt.close();
    }
    return result;
  }

}
