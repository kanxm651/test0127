package jp.co.sj.xop.batch.tasklet;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;
import jp.co.sj.xop.batch.common.JSONXOPUtils;
import jp.co.sj.xop.batch.common.constants.Constants;
import net.sf.json.JSONNull;

/**
 * 不要データ削除バッチ 編集処理
 *
 * @author SSD
 *
 */
@Component
public class RegularDelDataProcessor extends BaseDataProcessor {

  /**
   * ロガー.
   */
  private static final Logger logger =
      LoggerFactory.getLogger(RegularDelDataProcessor.class);

  /**
   * メッセージソース.
   */
  @Autowired
  private MessageSource messagesource;


  @SuppressWarnings({"unchecked", "unlikely-arg-type"})
  @Override
  public Object process(Object item) throws Exception {
    // 抽出したデータ
    String processorParam = Constants.EMPTY;
    // 加工処理フラグ
    boolean processorFlag = false;
    // 加工処理完了フラグ
    boolean processorEndFlag = false;
    // 出力レコード配列
    HashMap<String, Object> subFlagMap = null;
    // エラーフラグ
    boolean errorFlag = false;
    processorParam = item.toString();
    // 不要データ削除バッチ 状態検証
    if (!StringUtils.isEmpty(processorParam)) {
      if ("readerror".equals(processorParam.substring(1, 10))) {
        // バッチ状態より、各フラグ設定
        errorFlag = true;
        processorFlag = false;
      } else if ("readenderror".equals(processorParam.substring(1, 13))) {
        processorEndFlag = true;
        errorFlag = true;
        processorFlag = false;
      } else if ("readend".equals(processorParam.substring(1, 8))) {
        processorEndFlag = true;
        processorFlag = true;
      } else if ("read".equals(processorParam.substring(1, 5))) {
        processorFlag = true;
        processorEndFlag = false;
      }
    }

    // 不要データ削除バッチ データ編集処理
    Map<String, Object> result = new HashMap<String, Object>();
    List<HashMap<String, String>> dataDelList = new ArrayList<HashMap<String, String>>();
    if (processorFlag) {
      try {
        result = JSONXOPUtils.object2Map(item);
        dataDelList =
            (List<HashMap<String, String>>) result.get("jp.co.sj.xop.batch.jdbc.DataDelQuery");
        HashMap<String, String> dataDelMap = new HashMap<String, String>();
        for (String key : dataDelList.get(0).keySet()) {
          if (!JSONNull.getInstance().equals(dataDelList.get(0).get(key))) {
            dataDelMap.put(key, dataDelList.get(0).get(key));
          } else {
            dataDelMap.put(key, Constants.EMPTY);
          }
        }

        subFlagMap = new HashMap<String, Object>();
        subFlagMap.put("TABLE_ID", dataDelMap.get("TABLE_ID"));
        subFlagMap.put("TABLE_NAME_JA", dataDelMap.get("TABLE_NAME_JA"));
        subFlagMap.put("TABLE_NAME_EN", dataDelMap.get("TABLE_NAME_EN"));
        subFlagMap.put("CONDITON_FLAG", dataDelMap.get("CONDITON_FLAG"));
        subFlagMap.put("CONDITON_DATETIME", dataDelMap.get("CONDITON_DATETIME"));
        subFlagMap.put("MONTHS_HELD", dataDelMap.get("MONTHS_HELD"));
        subFlagMap.put("RDDSYSDATE", dataDelMap.get("RDDSYSDATE"));
        if (processorEndFlag) {
          subFlagMap.put("END_FLAG", "END");
        }
        return subFlagMap;
      } catch (Exception e) {
        errorFlag = true;
        // データ編集失敗ログ出力
        logger.error(messagesource.getMessage("message.LOGMSG0004E",
            new String[] {Constants.TBNAME_DATA_DEL}, Locale.JAPAN), e);

      }
    }
    if (errorFlag) {
      // エラーの場合、出力レコード配列に相関フラグ設定
      subFlagMap = new HashMap<String, Object>();
      subFlagMap.put("ERROR_FLAG", "ERROR");
      if (processorEndFlag) {
        subFlagMap.put("END_FLAG", "END");
      }
      return subFlagMap;
    }
    return null;
  }
}
