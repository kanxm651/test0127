package jp.co.sj.xop.batch.listener;

import org.springframework.stereotype.Component;

/**
 * 集配信システムへファイル転送（お問合せ）バッチ のWrite前後に実施する処理。
 *
 * @author SSD 曾洋
 *
 */
@Component
public class InquiryExportItemWriteListener extends BaseItemWriteListener {

}
