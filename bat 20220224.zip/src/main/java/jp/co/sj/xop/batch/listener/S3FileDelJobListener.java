package jp.co.sj.xop.batch.listener;

import org.springframework.stereotype.Component;
import jp.co.sj.xop.batch.common.constants.Constants;

/**
 * 不要ファイル削除バッチ のJob前後に実施する処理。
 *
 * @author SSD
 *
 */
@Component
public class S3FileDelJobListener extends BaseJobListener {
  public S3FileDelJobListener() {
    super.setLogHead(Constants.S3_FILE_JOB_NAME_JAP);
  }
}
