package jp.co.sj.xop.batch.tasklet;

import java.lang.reflect.Method;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;
import jp.co.sj.xop.batch.common.DateTimeUtil;
import jp.co.sj.xop.batch.common.JSONXOPUtils;
import jp.co.sj.xop.batch.common.LocalDateTimeEx;
import jp.co.sj.xop.batch.common.TempFileUtils;
import jp.co.sj.xop.batch.common.constants.Constants;
import jp.co.sj.xop.batch.common.constants.DateTimeConstants;
import jp.co.sj.xop.batch.service.S3Services;

/**
 * 集配信システムへファイル転送（お問合せ）の加工処理.
 *
 * @author SSD
 *
 */
@Component
public class InquiryExportDataProcessor extends BaseDataProcessor {

  /**
   * S3Services.
   */
  @Autowired
  S3Services s3Services;

  /**
   * フォルダパス文字列.
   */
  @Value("${app.temp_folder_path}")
  private String tempfolder;

  /**
   * ロガー.
   */
  private static final Logger logger = LoggerFactory.getLogger(InquiryExportDataProcessor.class);

  /**
   * メッセージソース.
   */
  @Autowired
  private MessageSource messagesource;

  /**
   * 抽出したデータをファイルに加工処理.
   *
   * @param item 抽出したデータ配列
   * @return 出力レコード配列
   */
  @SuppressWarnings("unchecked")
  @Override
  public Object process(Object item) throws Exception {
    // 抽出したデータ
    String processorParam = Constants.EMPTY;
    // バックアップファイル名
    String aftName = null;
    // Ｓ３サーバーにアップロードのフラグ
    boolean upFileFlg = false;
    // 加工処理フラグ
    boolean processorFlag = false;
    // データファイルパス
    String fileAbsolutePath = Constants.EMPTY;
    // 抽出したデータ配列
    Map<String, Object> result = new HashMap<String, Object>();
    // ファイルに書き込みデータリスト
    ArrayList<String> outputList = new ArrayList<String>();
    // 状態リスト
    // ArrayList<String> condition = new ArrayList<String>();
    HashMap<String, String> condition = new HashMap<String, String>();
    // 出力レコード配列
    HashMap<String, Object> subFlagMap = new HashMap<String, Object>();
    // クラス名
    String thisclassName = this.getClass().getName();
    // メソッド名
    String thismethodName = Thread.currentThread().getStackTrace()[1].getMethodName();
    // データ組み合わせメソッドのキー
    String StringMosaicKey = thisclassName + "_" + thismethodName;
    processorParam = item.toString();

    // バチ状態検証
    if ("read".equals(processorParam.substring(1, 5))) {
      try {
        // 抽出したデータ編集
        result = JSONXOPUtils.object2Map(item);
        List<HashMap<String, String>> inquiryList = new ArrayList<HashMap<String, String>>();
        inquiryList =
            (List<HashMap<String, String>>) result.get("jp.co.sj.xop.batch.jdbc.InquiryQuery");
        List<HashMap<String, String>> TbnameList = new ArrayList<HashMap<String, String>>();
        TbnameList = (List<HashMap<String, String>>) result
            .get("jp.co.sj.xop.batch.jdbc.DeliveryGetDataOption");
        // 抽出したデータは0件の場合
        // 空ファイル作成、テーブルに更新不要となります
        if (inquiryList.size() == 0) {
          subFlagMap.put("UPDATE_FLAG", "DO_NOT");

        } else {
          String resultstr = Constants.EMPTY;
          // データ組合せメソッド呼び出す
          Class<?> convertUtilClass = Class.forName("jp.co.sj.xop.batch.common.ConvertUtil");
          Method getMethod =
              convertUtilClass.getMethod("StringMosaic", List.class, HashMap.class, String.class);
          // 抽出したデータは複数件の場合
          for (HashMap<String, String> singleMap : inquiryList) {
            // ファイルに書き込みデータ作成
            resultstr = (String) getMethod.invoke(convertUtilClass,
                new Object[] {Constants.CLASS_CONVERT_MAP.get(StringMosaicKey.trim()), singleMap,
                    Constants.CLASS_DIVIDER_MAP.get(StringMosaicKey.trim())});
            outputList.add(resultstr);
            String str = singleMap.get("FORM_CODE") + singleMap.get("INSERT_NUMBER");
            condition.put(str, TbnameList.get(0).get(str));
            subFlagMap.put("RECORD_KEY", condition);
          }
        }
        processorFlag = true;
        // データ編集成功のログを出力する。
        logger.info(messagesource.getMessage("message.LOGMSG0013I",
            new String[] {Constants.INQUIRY}, Locale.JAPAN));
      } catch (Exception e) {
        processorFlag = false;
        // データ編集失敗のログを出力する。
        logger.error(messagesource.getMessage("message.LOGMSG0004E",
            new String[] {Constants.INQUIRY}, Locale.JAPAN), e);
        // バッチを中止する
        throw e;
      }

      // データファイルを作成する
      if (processorFlag) {
        try {
          // データファイルに書き込み
          fileAbsolutePath = TempFileUtils.createTempFile(outputList, tempfolder,
              Constants.FILE_NAME_INQUIRY, Constants.FILE_TYPE_TXT);
          // ファイルを作成成功のログを出力する。
          logger.info(messagesource.getMessage("message.LOGMSG0014I",
              new String[] {Constants.INQUIRY}, Locale.JAPAN));
        } catch (Exception e) {
          processorFlag = false;
          // ファイルを作成失敗ログを出力する。
          logger.error(messagesource.getMessage("message.LOGMSG0005E",
              new String[] {Constants.INQUIRY}, Locale.JAPAN), e);
          // バッチを中止する
          throw e;
        }
      }

      /*
       * Ｓ３サーバーにアップロードする
       */
      if (processorFlag) {
        // データファイル を Ｓ３サーバーにアップロードするuiry_info.
        upFileFlg = s3Services.uploadFile(
            Constants.FILE_PATH_INQUIRY + Constants.FILE_NAME_INQUIRY + Constants.FILE_TYPE_TXT,
            fileAbsolutePath);
        if (!upFileFlg) {
          processorFlag = false;
          // アップロード失敗のログを出力する。
          String errorMessage = messagesource.getMessage("message.LOGMSG0007E",
              new String[] {Constants.INQUIRY}, Locale.JAPAN);
          logger.error(errorMessage);
          // バッチを中止する
          throw new Exception(errorMessage);
        } else {
          // アップロード成功のログを出力する。
          logger.info(messagesource.getMessage("message.LOGMSG0016I",
              new String[] {Constants.INQUIRY}, Locale.JAPAN));
        }
      }
      /*
       * Ｓ３サーバーにバックアップファイルアップロードする
       */
      if (processorFlag) {
        // 時間を取得する
        Timestamp nowTimestamp = Timestamp.valueOf(LocalDateTimeEx.now());
        String strHour =
            DateTimeUtil.format(nowTimestamp, DateTimeConstants.DATETIMEFORMAT_DATETIME13);
        aftName = Constants.BKFILE_PATH_INQUIRY + Constants.FILE_NAME_INQUIRY + "_" + strHour
            + Constants.FILE_TYPE_AFT;
        subFlagMap.put("BK_FILE_NAME",
            Constants.FILE_NAME_INQUIRY + "_" + strHour + Constants.FILE_TYPE_AFT);
        // データファイルのバックアップ を Ｓ３サーバーにアップロードする
        upFileFlg = s3Services.uploadBackupFile(aftName, fileAbsolutePath);
        if (!upFileFlg) {
          // バックアップファイルアップロード失敗のログを出力する。
          logger.error(messagesource.getMessage("message.LOGMSG0007E",
              new String[] {Constants.INQUIRY_BACKUP}, Locale.JAPAN));
        } else {
          // バックアップファイルアップロード成功のログを出力する。
          logger.info(messagesource.getMessage("message.LOGMSG0016I",
              new String[] {Constants.INQUIRY_BACKUP}, Locale.JAPAN));
        }
      }
      if (!processorFlag) {
        // エラーの場合、状態をセット（「error」を付ける）
        subFlagMap.put("ERROR_FLAG", "ERROR");
        return subFlagMap;
      }
    }
    return subFlagMap;
  }
}
