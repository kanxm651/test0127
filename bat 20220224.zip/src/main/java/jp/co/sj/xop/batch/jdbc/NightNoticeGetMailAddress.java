package jp.co.sj.xop.batch.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import jp.co.sj.xop.batch.common.constants.Constants;
import jp.co.sj.xop.batch.service.SqlLoaderService;

/**
 * 夜間バッチ通知メールバッチ メールアドレステーブルからデータ取得Queryクラス
 *
 * @author SSD
 *
 */
public class NightNoticeGetMailAddress extends BaseQuery {

  private PreparedStatement preStmt = null;
  private ResultSet rs = null;

  public NightNoticeGetMailAddress() {
    super.setMsgHead(Constants.TBNAME_MAILADDRESS);
  }

  /**
   * Query実行メソッド
   *
   * @return ArrayList
   * @throws Exception
   */

  @Override
  protected ArrayList<HashMap<String, String>> subQuery(Map<String, String> condition,
      Connection conn, SqlLoaderService sqlLoaderService) throws Exception {

    ArrayList<HashMap<String, String>> result = new ArrayList<HashMap<String, String>>();
    // SQLを取得
    String sql = sqlLoaderService.getSql("NightNoticeGetMailAddress");
    try {
      preStmt = conn.prepareStatement(sql);
      preStmt.setString(1, condition.get("FORM_CODE"));
      rs = preStmt.executeQuery();
      while (rs.next()) {
        // リターン結果にDBから取得したカラム値をセットする
        HashMap<String, String> recMap = new HashMap<String, String>();
        recMap.put("FORM_CODE", rs.getString("FORM_CODE"));
        recMap.put("EMAIL_ADD1", rs.getString("EMAIL_ADD1"));
        recMap.put("EMAIL_ADD2", rs.getString("EMAIL_ADD2"));
        recMap.put("EMAIL_ADD3", rs.getString("EMAIL_ADD3"));
        recMap.put("EMAIL_ADD4", rs.getString("EMAIL_ADD4"));
        recMap.put("EMAIL_ADD5", rs.getString("EMAIL_ADD5"));
        recMap.put("EMAIL_ADD6", rs.getString("EMAIL_ADD6"));
        recMap.put("EMAIL_ADD7", rs.getString("EMAIL_ADD7"));
        recMap.put("EMAIL_ADD8", rs.getString("EMAIL_ADD8"));
        recMap.put("EMAIL_ADD9", rs.getString("EMAIL_ADD9"));
        recMap.put("EMAIL_ADD10", rs.getString("EMAIL_ADD10"));
        recMap.put("EMAIL_ADD11", rs.getString("EMAIL_ADD11"));
        recMap.put("EMAIL_ADD12", rs.getString("EMAIL_ADD12"));
        recMap.put("EMAIL_ADD13", rs.getString("EMAIL_ADD13"));
        recMap.put("EMAIL_ADD14", rs.getString("EMAIL_ADD14"));
        recMap.put("EMAIL_ADD15", rs.getString("EMAIL_ADD15"));
        result.add(recMap);
      }
    } finally {
        rs.close();
        preStmt.close();
    }
    return result;
  }
}
