package jp.co.sj.xop.batch.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.List;
import org.springframework.stereotype.Component;
import io.micrometer.core.instrument.util.StringUtils;
import jp.co.sj.xop.batch.common.constants.Constants;
import jp.co.sj.xop.batch.service.SqlLoaderService;

/**
 * 不要データ削除バッチ 削除管理テーブルのデータDeleteクラス
 *
 * @author SSD
 */
@Component
public class DataDelDelete extends BaseUpdate {

  private PreparedStatement preStmt = null;

  /**
   * Update実行メソッド
   *
   * @return updateCount
   * @throws Exception
   */

  @Override
  protected int subExecute(List<String> list, Connection conn, SqlLoaderService sqlLoaderService)
      throws Exception {
    int updateCount = 0;
    String sql = Constants.EMPTY;
    try {
      if (list != null) {
        conn.setAutoCommit(false);

        sql = "DELETE FROM " + list.get(0);

        if (StringUtils.isEmpty(list.get(1))) {
          return 0;
        } else {
          sql = sql + " WHERE " + list.get(1) + " < (to_timestamp('" + list.get(4)
              + "','yyyymmdd hh24:mi:ss') - interval '" + list.get(3) + " month')";
          if (StringUtils.isNotEmpty(list.get(2))) {
            String[] str = list.get(2).split("/");
            for (String i : str) {
              sql = sql + " AND " + i + " = '1'";
            }
          }
        }
        preStmt = conn.prepareStatement(sql);
        updateCount = preStmt.executeUpdate();
        conn.commit();
      }
    } finally {
        preStmt.close();
    }
    return updateCount;
  }
}
