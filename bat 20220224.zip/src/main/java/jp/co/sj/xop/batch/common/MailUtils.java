package jp.co.sj.xop.batch.common;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.sql.Timestamp;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.sendgrid.Method;
import com.sendgrid.Request;
import com.sendgrid.Response;
import com.sendgrid.SendGrid;
import com.sendgrid.helpers.mail.Mail;
import com.sendgrid.helpers.mail.objects.Attachments;
import com.sendgrid.helpers.mail.objects.Email;
import com.sendgrid.helpers.mail.objects.Personalization;
import io.micrometer.core.instrument.util.StringUtils;


/**
 * MailUtilクラス.
 *
 * @author SSD
 *
 */
public class MailUtils {

  /**
   * ロガー.
   */
  private static final Logger logger = LoggerFactory.getLogger(MailUtils.class);



  /**
   * レスポンスのステータスコード：要求が正常で、送信キューに加えられました。<br>
   * ※通常、正常にメール送信ができた場合はこちらが返される
   */
  public final static int STATUS_CODE_ACCEPTED = 200;

  public final static String SENDGRID_ENABLE = System.getenv("SENDGRID_ENABLE");

  public final static String API_KEY = System.getenv("SENDGRID_API_KEY");
  public final static String TEMPLATE_ID = System.getenv("SENDGRID_TEMPLATE_NIGHTNOTICE");

  /**
   * メール送信サービス
   *
   * @param from 送信者
   * @param template テンプレート
   * @param sendGridMailInfo 送信メール情報
   * @return レスポンスのステータスコード。2xxの場合、正常動作。4xxあるいは5xxの場合、エラー
   * @throws Exception
   */
  public static String sendMail(String address, String subject,
      HashMap<String, Object> templateData, String filePath)
      throws Exception {

    if ("FALSE".equals(SENDGRID_ENABLE)) {
      return "400";
    }

    String name = subject
        + DateTimeUtil.getDateFormat(new Timestamp(System.currentTimeMillis()), "yyyyMMddHHmmss");

    SendGrid sg = new SendGrid(API_KEY);
    Mail mail = new Mail();
    Email from = new Email(System.getenv("SENDGRID_FROM_CSV_ADDRESS"));
    mail.setFrom(from);
    Personalization personalization = new Personalization();
    String[] addressArray = address.split(";");
    for (String addr : addressArray) {
      personalization.addTo(new Email(addr));
    }
    for (Map.Entry<String, Object> entry : templateData.entrySet()) {
      personalization.addDynamicTemplateData(entry.getKey(), entry.getValue());
    }
    mail.setSubject(subject);
    mail.setTemplateId(TEMPLATE_ID);
    mail.addPersonalization(personalization);



    // 添付ファイルの作成
    if (StringUtils.isNotEmpty(filePath)) {
      byte[] fileData = null;
      try {
        fileData = InputStream2ByteArray(filePath);
      } catch (Exception e) {
        e.printStackTrace();
      }
      Attachments attachment = new Attachments();
      Base64.Encoder encoder = Base64.getEncoder();
      attachment.setContent(encoder.encodeToString(fileData));
      attachment.setFilename(name + ".csv");
      attachment.setType("plain/text");
      mail.addAttachments(attachment);
    }
    // リクエストの作成
    Request request = new Request();
    request.setMethod(Method.POST);
    request.setEndpoint("mail/send");
    request.setBody(mail.build());
    logger.debug("SendMail Request Body[{}]", request.getBody());
    // ★メール送信
    Response response;
    response = sg.api(request);
    logger.debug("SendMail Response Status[{}]", response.getStatusCode());
    logger.debug("SendMail Response Headers[{}]", response.getHeaders());
    logger.debug("SendMail Response Body[{}]", response.getBody());
    return response.getStatusCode() + "%" + name;
  }

  private static byte[] InputStream2ByteArray(String filePath) {
    FileInputStream fis;
    byte[] buff = null;
    File file = new File(filePath);
    ByteArrayOutputStream bos = new ByteArrayOutputStream();
    try {
      fis = new FileInputStream(file);
      byte[] b = new byte[1024];
      int n;
      while ((n = fis.read(b)) != -1) {
        bos.write(b, 0, n);
      }
      fis.close();
      bos.close();
      buff = bos.toByteArray();
    } catch (Exception e) {
      e.printStackTrace();
    }
    return buff;
  }
}
