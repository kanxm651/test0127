package jp.co.sj.xop.batch.listener;

import org.springframework.stereotype.Component;

/**
 * 不要データ削除バッチ のProcess前後に実施する処理。
 *
 * @author SSD
 *
 */
@Component
public class RegularDelItemProcessListener extends BaseItemProcessListener {
}
