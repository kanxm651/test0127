package jp.co.sj.xop.batch.common.constants;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 定数クラス.
 *
 * @author SSD
 *
 */
public class Constants {

  public static final String ON = "ON";
  public static final int SENDMAIL_RETYR_TIMES = 3;
  public static final String BATCH_ERROR_STOP_MSG = "バッチ処理が異常終了しました。";
  public static final String BATCH_OUTAGE_MSG = "バッチ計画停止中です。";
  public static final String BATCH_COMPLETED = "COMPLETED";
  public static final String ERROR = "ERROR";
  public static final String DO_NOT = "DO_NOT";
  public static final String START = "ST\r\n";
  public static final String END = "\r\nEN";
  public static final String LINE_FEED = "\r\n";
  public static final String REMIND_BACKUP = "リマインドバックアップ";
  public static final String REMIND = "リマインド";
  public static final String FIRE_INSURANCE = "火災保険加入相談";
  public static final String FIRE_INSURANCE_BACKUP = "火災保険加入相談バックアップ";
  public static final String INQUIRY = "お問い合わせ";
  public static final String INQUIRY_BACKUP = "お問い合わせバックアップ";
  public static final String CSV = "CSV";
  public static final String BACKUP = "バックアップ";
  public static final String EMPTY = "";
  public static final String COMMA = ",";
  public static final String VERTICAL_LINE = "|";
  public static final String HALF_SPACE = " ";
  public static final String FULL_SPACE = "　";
  public static final String TWO_SPACE = "  ";
  public static final String FOUR_SPACE = "    ";
  public static final String SEVEN_SPACE = "       ";
  public static final String EIGHT_SPACE = "        ";
  public static final String TEN_SPACE = "          ";
  public static final String TWELVE_SPACE = "            ";
  public static final String THIRTEEN_SPACE = "             ";
  public static final String NINETEEN_SPACE = "                   ";
  public static final String FORM_CODE06 = "06";
  public static final String TWENTYFOUR = "24";
  public static final String CONSTANT_0 = "0";
  public static final String CONSTANT_1 = "1";
  public static final String CONSTANT_2 = "2";
  public static final String CONSTANT_3 = "3";
  public static final String CONSTANT_4 = "4";
  public static final String CONSTANT_BT = "BT";
  public static final String CONSTANT_01 = "01";
  public static final String CONSTANT_02 = "02";
  public static final String CONSTANT_12 = "12";
  public static final String FILE_TYPE_TXT = ".txt";
  public static final String FILE_TYPE_AFT = ".aft";
  public static final String FILE_NAME_FIRE = "fire_insurance_info";
  public static final String FILE_NAME_INQUIRY = "inquiry_info";
  public static final String FILE_NAME_REMIND = "remind_info";
  public static final String FILE_PATH_FIRE = "shuhai/fire/";
  public static final String FILE_PATH_INQUIRY = "shuhai/inquiry/";
  public static final String FILE_PATH_REMIND = "remind/";
  public static final String BKFILE_PATH_FIRE = "shuhai/fire/backup/";
  public static final String BKFILE_PATH_INQUIRY = "shuhai/inquiry/backup/";
  public static final String BKFILE_PATH_REMIND = "remind/backup/";
  public static final String BKFILE_PATH_NIGHTNOTICE = "nightnotice/backup/";
  public static final String NIGHT_NOTICE_EXPORT_JOB_NAME_JAP = "夜間バッチ通知メール送信";
  public static final String NIGHT_NOTICE_EXPORT_JOB_NAME_ENG = "NightnoticeExportBatchJob";
  public static final String REMIND_EXPORT_JOB_NAME_JAP = "リマインドファイル転送";
  public static final String REMIND_EXPORT_JOB_NAME_ENG = "RemindExportBatchJob";
  public static final String REGULAR_DEL_JOB_NAME_JAP = "不要データ削除";
  public static final String REGULAR_DEL_JOB_NAME_ENG = "RegularDelBatchJob";
  public static final String S3_FILE_JOB_NAME_JAP = "不要ファイル削除";
  public static final String S3_FILE_JOB_NAME_ENG = "S3FileDelBatchJob";
  public static final String INQUIRY_EXPORT_JOB_NAME_JAP = "集配信システムへファイル転送(お問い合わせ)";
  public static final String INQUIRY_EXPORT_JOB_NAME_ENG = "InquiryExportBatchJob";
  public static final String FIRE_INSURANCE_EXPORT_JOB_NAME_JAP = "集配信システムへファイル転送(火災保険加入相談)";
  public static final String FIRE_INSURANCE_EXPORT_JOB_NAME_ENG = "FireInsuranceExportBatchJob";
  public static final String TBNAME_OPTION = "オプション";
  public static final String TBNAME_MAILADDRESS = "メールアドレス";
  public static final String TBNAME_INQUIRY = "お問い合わせ";
  public static final String TBNAME_EN_INQUIRY = "英語お問い合わせ";
  public static final String TBNAME_EN_MU_INQUIRY = "英語美術館お問い合わせ";
  public static final String TBNAME_MU_INQUIRY = "美術館お問い合わせ";
  public static final String TBNAME_DATA_DEL = "不要データ削除管理";
  public static final String TBNAME_FILE_DEL = "不要ファイル削除管理";
  public static final String NIGHT_NOTICE_EXPORT_MAIL_ARIMSGEN = "サーバー内の上記時点までのデータを全て添付しました。";
  public static final String NIGHT_NOTICE_EXPORT_MAIL_NASHIMSGEN = "サーバー内に上記時点までのデータはありませんでした。";
  public static final String DELIVERY_FIRE_INS_MESSAGE_IS2 =
      "下記のお客さまが公式ウェブサイト上で、火災保険の見積り・加入相談をご希望されました。直接ご対応願います。";
  public static final String DELIVERY_FIRE_INS_MESSAGE_IS3 =
      "すでにお取引のある、下記のお客さまが公式ウェブサイト上で、火災保険の見積り・加入相談をご希望されました。直接ご対応願います。";
  public static final String INSURE_KIND = "個人用火災総合保険 『ＴＨＥ すまいの保険』";
  public static final String VARIABLE_MSG2 =
      "お客さまの見積条件・見積結果は損保ジャパン公式ウェブサイト火災保険クイック試算画面よりＩＤを入力しご確認ください。（見積日より30日間有効）\\n"
          + "お客さまが入力された試算結果ＩＤは以下です。\\n" + "火災保険クイック試算画面\\n";
  public static final String VARIABLE_MSG2_IMAGEURL =
      "（http://web.sompo-japan.jp/kasai/simulation/index.html）\\n";
  public static final String VARIABLE_MSG2_PAGEID = "ページＩＤ（";
  public static final String VARIABLE_MSG2_AFFIRM =
      "）\\n見積結果確認方法（https://faq.sompo-japan.jp/other/faq_detail.html?menu=71900&category=71905&id=200901）";

  /**
   * バッチジョッブ論理名 と コントロールの対応配列
   */
  public static final Map<String, String> JOB_NAME = new HashMap<String, String>();
  static {
    JOB_NAME.put("NIGHT_NOTICE_EXPORT", "jp.co.sj.xop.NightnoticeExportController");
    JOB_NAME.put("REGULAR_DEL", "jp.co.sj.xop.RegularDelController");
    JOB_NAME.put("REMIND_EXPORT", "jp.co.sj.xop.RemindExportController");
    JOB_NAME.put("INQUIRY_EXPORT", "jp.co.sj.xop.InquiryExportController");
    JOB_NAME.put("FIRE_INSURANCE_EXPORT", "jp.co.sj.xop.FireInsuranceExportController");
    JOB_NAME.put("S3_FILE_DEL", "jp.co.sj.xop.S3FileDelController");
  }

  /**
   * バッチジョッブ論理名 と ジョッブ物理名の対応配列
   */
  public static final Map<String, String> JOB_NAME_JAP = new HashMap<String, String>();
  static {
    JOB_NAME_JAP.put("NIGHT_NOTICE_EXPORT", NIGHT_NOTICE_EXPORT_JOB_NAME_JAP);
    JOB_NAME_JAP.put("REGULAR_DEL", REGULAR_DEL_JOB_NAME_JAP);
    JOB_NAME_JAP.put("REMIND_EXPORT", REMIND_EXPORT_JOB_NAME_JAP);
    JOB_NAME_JAP.put("INQUIRY_EXPORT", INQUIRY_EXPORT_JOB_NAME_JAP);
    JOB_NAME_JAP.put("FIRE_INSURANCE_EXPORT", FIRE_INSURANCE_EXPORT_JOB_NAME_JAP);
    JOB_NAME_JAP.put("S3_FILE_DEL", S3_FILE_JOB_NAME_JAP);
  }

  /**
   * 集配信システムへファイル転送（お問い合わせ） バッチ 対応データを取得するのQueryクラス配列
   */
  public static final Map<String, String> INQUIRY_FORM_DAO_MAP = new HashMap<String, String>();
  static {
    INQUIRY_FORM_DAO_MAP.put("t_inquiry_interface",
        "jp.co.sj.xop.batch.jdbc.DeliveryGetDataInquiryIF");
    INQUIRY_FORM_DAO_MAP.put("t_english_inquiry_interface",
        "jp.co.sj.xop.batch.jdbc.DeliveryGetDataEnInquiryIF");
  }

  /**
   * 夜間バッチ通知メール送信バッチ 対応データを取得するのQueryクラス配列
   */
  public static final Map<String, String> FORM_DAO_MAP = new HashMap<String, String>();
  static {
    FORM_DAO_MAP.put("03", "jp.co.sj.xop.batch.jdbc.NightNoticeGetDataInquiryIF");
    FORM_DAO_MAP.put("06", "jp.co.sj.xop.batch.jdbc.NightNoticeGetDataFireInsurance");
    FORM_DAO_MAP.put("16", "jp.co.sj.xop.batch.jdbc.NightNoticeGetDataEnInquiryIF");
    FORM_DAO_MAP.put("23", "jp.co.sj.xop.batch.jdbc.NightNoticeGetDataMuseumInquiry");
    FORM_DAO_MAP.put("24", "jp.co.sj.xop.batch.jdbc.NightNoticeGetDataEnMuseumInquiry");
  }

  /**
   * 夜間バッチ通知メール送信バッチ Queryクラス と 対応convertメソッド配列
   */
  public static final List<String> DAO_LIST = new ArrayList<String>();
  static {
    DAO_LIST.add("jp.co.sj.xop.batch.jdbc.NightNoticeGetDataInquiryIF");
    DAO_LIST.add("jp.co.sj.xop.batch.jdbc.NightNoticeGetDataFireInsurance");
    DAO_LIST.add("jp.co.sj.xop.batch.jdbc.NightNoticeGetDataEnInquiryIF");
    DAO_LIST.add("jp.co.sj.xop.batch.jdbc.NightNoticeGetDataMuseumInquiry");
    DAO_LIST.add("jp.co.sj.xop.batch.jdbc.NightNoticeGetDataEnMuseumInquiry");
  }

  /**
   * 夜間バッチ通知メール送信バッチ Queryクラス と 対応convertメソッド配列
   */
  public static final Map<String, String> METHOD_MAP = new HashMap<String, String>();
  static {
    METHOD_MAP.put("jp.co.sj.xop.batch.jdbc.NightNoticeGetDataInquiryIF", "getInquiryInterface");
    METHOD_MAP.put("jp.co.sj.xop.batch.jdbc.NightNoticeGetDataFireInsurance",
        "getFireInsuranceInquiryQuery");
    METHOD_MAP.put("jp.co.sj.xop.batch.jdbc.NightNoticeGetDataEnInquiryIF",
        "getEnglishInquiryInterfaceQuery");
    METHOD_MAP.put("jp.co.sj.xop.batch.jdbc.NightNoticeGetDataMuseumInquiry",
        "getMuseumInquiryQuery");
    METHOD_MAP.put("jp.co.sj.xop.batch.jdbc.NightNoticeGetDataEnMuseumInquiry",
        "getEnglishMuseumInquiryQuery");
  }

  /**
   * 夜間バッチ通知メール送信バッチ 対応データを更新するのupdateクラス配列
   */
  public static final Map<String, String> FORM_DAO_UPMAP = new HashMap<String, String>();
  static {
    FORM_DAO_UPMAP.put("03", "jp.co.sj.xop.batch.jdbc.NightNoticeUpdateInquiryIF");
    FORM_DAO_UPMAP.put("06", "jp.co.sj.xop.batch.jdbc.NightNoticeUpdateFireInsurance");
    FORM_DAO_UPMAP.put("16", "jp.co.sj.xop.batch.jdbc.NightNoticeUpdateEnInquiryIF");
    FORM_DAO_UPMAP.put("23", "jp.co.sj.xop.batch.jdbc.NightNoticeUpdateMuseumInquiry");
    FORM_DAO_UPMAP.put("24", "jp.co.sj.xop.batch.jdbc.NightNoticeUpdateEnMuseumInquiry");
  }

  /**
   * 集配信システムへファイル転送（お問い合わせ）バッチ 対応convertメソッド配列
   */
  public static final Map<String, String> PARAMCVT_DAO_MAP = new HashMap<String, String>();
  static {
    PARAMCVT_DAO_MAP.put("t_inquiry_interface", "getInquiry");
    PARAMCVT_DAO_MAP.put("t_english_inquiry_interface", "getEnglishInquiry");
  }

  /**
   * テーブル名と テーブル物理名の対応配列
   */
  public static final Map<String, String> TABLE_NAME_MAP = new HashMap<String, String>();
  static {
    TABLE_NAME_MAP.put("t_inquiry_interface", "お問い合わせ");
    TABLE_NAME_MAP.put("t_english_inquiry_interface", "英語お問い合わせ");
  }

  /**
   *
   * CSV名と テーブル物理名の対応配列
   */
  public static final Map<String, String> FORM_TBNAME_MAP = new HashMap<String, String>();
  static {
    FORM_TBNAME_MAP.put("03", "お問い合わせ");
    FORM_TBNAME_MAP.put("06", "火災保険加入相談");
    FORM_TBNAME_MAP.put("16", "英語お問い合わせ");
    FORM_TBNAME_MAP.put("23", "美術館お問い合わせ");
    FORM_TBNAME_MAP.put("24", "英語美術館お問い合わせ");
  }

  /**
   * 集配信システムへファイル転送（火災保険加入相談）バッチ ファイル出力項目名文字列
   */
  public static final List<String> DELIVERY_FIRE_INS_EXP_COLUMNS = new ArrayList<String>();
  static {
    // START
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("START");
    // 受付区分１
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("RECEPTION_DIV1");
    // 受付区分２
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("RECEPTION_DIV2");
    // 業務区分
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("BUSINESS_DIV");
    // 受付日
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("RECEPTION_DATE");
    // 受付時間
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("RECEPTION_TIME");
    // 氏名１
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("NAME1");
    // 氏名２
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("NAME2");
    // 氏名３
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("NAME3");
    // 氏名カナ１
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("NAME_KANA1");
    // 氏名カナ２
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("NAME_KANA2");
    // 氏名カナ３
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("NAME_KANA3");
    // 氏名半角カナ１
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("HALF_NAME_KANA1");
    // 氏名半角カナ２
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("HALF_NAME_KANA2");
    // 氏名半角カナ３
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("HALF_NAME_KANA3");
    // 郵便番号
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("ZIP_CODE");
    // 自宅電話番号
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("TEL_HOME");
    // 連絡先区分
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("CONTACT_CLASSIFY");
    // 連絡先電話番号
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("TEL_CONTACT");
    // FAX区分
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("FAX_CLASSIFY");
    // FAX番号
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("TEL_FAX");
    // 都道府県
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("ADDRESS_PREF");
    // 連絡先住所１
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("ADDRESS1");
    // 連絡先住所２
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("ADDRESS2");
    // 連絡先住所３
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("ADDRESS3");
    // 英語住所
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("ADDRESS_ENG");
    // メールアドレス
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("EMAIL_ADD");
    // 性別
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("SEX");
    /** 値なし 可変長 ↓ **/
    // 職業
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("NOVALUE1");
    // 業種
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("NOVALUE2");
    // 部署名
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("NOVALUE3");
    // 勤務先名
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("NOVALUE4");
    /** 値なし 可変長 ↑ **/
    // 生年月日
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("BIRTHDAY");
    // 取引区分
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("EXCHANGE");
    // 顧客番号
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("CUSTOMER_NUMBER");
    /** 値なし 可変長 ↓ **/
    // 保険種目名称
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("NOVALUE5");
    // 形態と対象１
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("NOVALUE6");
    // 形態と対象２
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("NOVALUE7");
    // 建築時金額
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("NOVALUE8");
    // 築年数
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("NOVALUE9");
    // 占有延床面積
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("NOVALUE10");
    // 建物構造
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("NOVALUE11");
    // 地震保険
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("NOVALUE12");
    // 再調達価額（新品価額）
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("NOVALUE13");
    // オプション１
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("NOVALUE14");
    // オプション２
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("NOVALUE15");
    // オプション３
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("NOVALUE16");
    // オプション４
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("NOVALUE17");
    /** 値なし 可変長 ↑ **/
    // オプション５
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("OPTION5");
    // 所有者ID
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("OWNER_ID");
    // 親代理店組織コード
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("PARENT_ACCOUNT_CODE");
    // 代理店割振り区分
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("AGENCY_EXPLANATION");
    // 拒否既取引代理店(既取引代理店名)
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("AGENCY_EXCLUDING");
    // リーズ番号(加入相談依頼番号、資料請求番号)
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("LEEDS_REQUEST_NUMBER");
    // *4
    // 登録区分
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("INSERT_CLASSIFY");
    // カテゴリ区分
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("CATEGORY_CLASSIFY");
    // カテゴリ通番
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("CATEGORY_NUM");
    // 配信年月日
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("SEND_DATE");
    // 配信時刻
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("SEND_TIME");
    // 通番
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("NOVALUE18");
    // 配信先親代理店組織コード
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("AIMPARENT_ACCOUNT_CODE");
    // 親代理店組織コード
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("PAR_ACCOUNT_CODE");
    // 作成日
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("CREATE_DATE");
    /** 値なし 可変長 ↓ **/
    // 期限
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("NOVALUE18");
    // フリーエリア
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("NOVALUE19");
    // 掲示板アクセスコントロール
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("NOVALUE20");
    // 拠点コード（代理店）
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("NOVALUE21");
    // 拠点名称（代理店）
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("NOVALUE22");
    // 担当者コード（代理店）
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("NOVALUE23");
    // 担当者名称（代理店）
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("NOVALUE24");
    // 整理番号
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("NOVALUE25");
    // 募集人コード
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("NOVALUE26");
    /** 値なし 可変長 ↑ **/
    // 受付日
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("RECEIPT_DATE");
    // お客さま名
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("CUSTOM_NAME");
    // 可変文言１
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("MESSAGE1");
    /** 値なし 可変長 ↓ **/
    // 代理店名称
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("NOVALUE28");
    // リーズ料説明文言
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("NOVALUE29");
    /** 値なし 可変長 ↑ **/
    // リーズ番号
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("LEEDS_NUMBER");
    // 提供元
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("PRODUCT_SOURCE");
    // 保険種類
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("INSURE_KIND");
    // カナ
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("KANA");
    // 郵便番号 （ハイフン付き）
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("ZIP_HY_CODE");
    // 市区町村
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("CITY_ADD");
    // 町・番地
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("STREET_ADD");
    // マンション・建物名
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("APARTMENT_ADD");
    // 性別(漢字)
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("SEX_STR");
    // 生年月日
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("BIRTHDAY_VAR");
    // 電話
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("TEL_HOME_VAR");
    // 電話(日中連絡先)
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("TEL_CONTACT_VAR");
    // Fax
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("TEL_FAX_VAR");
    // 電子メール
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("EMAIL_ADD_VAR");
    /** 値なし 可変長 ↓ **/
    // 保険の対象
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("NOVALUE30");
    // 築年数
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("NOVALUE31");
    // 建築時の金額
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("NOVALUE32");
    // 地震保険
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("NOVALUE33");
    // 建物の構造
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("NOVALUE34");
    // 再調達価額
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("NOVALUE35");
    /** 値なし 可変長 ↑ **/
    // 可変文言２
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("MESSAGE2");
    // 受付日時
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("ACCEPT_DATE");
    // 可変項目内容２８
    // ：
    // 可変項目内容２００
    for (int i = 0; i < 173; i++) {
      DELIVERY_FIRE_INS_EXP_COLUMNS.add("VARIABLE_PROJECT" + i);
    }
    // END
    DELIVERY_FIRE_INS_EXP_COLUMNS.add("END");
  }

  /**
   * 集配信システムへファイル転送（お問い合わせ）出力項目名文字列
   */
  public static final List<String> DELIVERY_INQUIRY_EXP_COLUMNS = new ArrayList<String>();
  static {
    // START
    DELIVERY_INQUIRY_EXP_COLUMNS.add("START");
    // 受付区分１
    DELIVERY_INQUIRY_EXP_COLUMNS.add("RECEPTION_DIV1");
    // 受付区分２
    DELIVERY_INQUIRY_EXP_COLUMNS.add("RECEPTION_DIV2");
    // 業務区分
    DELIVERY_INQUIRY_EXP_COLUMNS.add("BUSINESS_DIV");
    // 受付日
    DELIVERY_INQUIRY_EXP_COLUMNS.add("RECEPTION_DATE");
    // 受付時間
    DELIVERY_INQUIRY_EXP_COLUMNS.add("RECEPTION_TIME");
    // 氏名１
    DELIVERY_INQUIRY_EXP_COLUMNS.add("NAME1");
    // 氏名２
    DELIVERY_INQUIRY_EXP_COLUMNS.add("NAME2");
    // 氏名３
    DELIVERY_INQUIRY_EXP_COLUMNS.add("NAME3");
    // 氏名カナ１
    DELIVERY_INQUIRY_EXP_COLUMNS.add("NAME_KANA1");
    // 氏名カナ２
    DELIVERY_INQUIRY_EXP_COLUMNS.add("NAME_KANA2");
    // 氏名カナ３
    DELIVERY_INQUIRY_EXP_COLUMNS.add("NAME_KANA3");
    // 氏名半角カナ１
    DELIVERY_INQUIRY_EXP_COLUMNS.add("HALF_NAME_KANA1");
    // 氏名半角カナ２
    DELIVERY_INQUIRY_EXP_COLUMNS.add("HALF_NAME_KANA2");
    // 氏名半角カナ３
    DELIVERY_INQUIRY_EXP_COLUMNS.add("HALF_NAME_KANA3");
    // 郵便番号
    DELIVERY_INQUIRY_EXP_COLUMNS.add("ZIP_CODE");
    // 自宅電話番号
    DELIVERY_INQUIRY_EXP_COLUMNS.add("TEL_HOME");
    // 連絡先区分
    DELIVERY_INQUIRY_EXP_COLUMNS.add("CONTACT_CLASSIFY");
    // 連絡先電話番号
    DELIVERY_INQUIRY_EXP_COLUMNS.add("TEL_CONTACT");
    // FAX区分
    DELIVERY_INQUIRY_EXP_COLUMNS.add("FAX_CLASSIFY");
    // FAX番号
    DELIVERY_INQUIRY_EXP_COLUMNS.add("TEL_FAX");
    // 都道府県
    DELIVERY_INQUIRY_EXP_COLUMNS.add("ADDRESS_PREF");
    // 連絡先住所１
    DELIVERY_INQUIRY_EXP_COLUMNS.add("ADDRESS1");
    // 連絡先住所２
    DELIVERY_INQUIRY_EXP_COLUMNS.add("ADDRESS2");
    // 連絡先住所３
    DELIVERY_INQUIRY_EXP_COLUMNS.add("ADDRESS3");
    // 英語住所
    DELIVERY_INQUIRY_EXP_COLUMNS.add("ADDRESS_ENG");
    // メールアドレス
    DELIVERY_INQUIRY_EXP_COLUMNS.add("EMAIL_ADD");
    // 性別
    DELIVERY_INQUIRY_EXP_COLUMNS.add("SEX");
    // 職業
    DELIVERY_INQUIRY_EXP_COLUMNS.add("JOB");
    // 業種
    DELIVERY_INQUIRY_EXP_COLUMNS.add("INDUSTRY");
    // 部署名
    DELIVERY_INQUIRY_EXP_COLUMNS.add("DEPARTMENT");
    // 勤務先名
    DELIVERY_INQUIRY_EXP_COLUMNS.add("COMPANY");
    // 生年月日
    DELIVERY_INQUIRY_EXP_COLUMNS.add("BIRTHDAY");
    // 取引区分
    DELIVERY_INQUIRY_EXP_COLUMNS.add("EXCHANGE");
    // 顧客番号
    DELIVERY_INQUIRY_EXP_COLUMNS.add("CUSTOMER_NUMBER");
    // お問い合わせ内容
    DELIVERY_INQUIRY_EXP_COLUMNS.add("CONTENTS");
    // お問い合わせ区分名
    DELIVERY_INQUIRY_EXP_COLUMNS.add("INQUIRY_NAME");
    // 証券番号
    DELIVERY_INQUIRY_EXP_COLUMNS.add("BOND_NUMBER");
    // END
    DELIVERY_INQUIRY_EXP_COLUMNS.add("END");
  }

  /**
   * リマインドバッチ ファイル出力項目名文字列
   */
  public static final List<String> REMIND_EXP_COLUMNS = new ArrayList<String>();
  static {

    // リーズ番号
    REMIND_EXP_COLUMNS.add("LEADS_NUMBER");
    // 顧客番号
    REMIND_EXP_COLUMNS.add("CUSTOMER_NUMBER");
    // 顧客氏名
    REMIND_EXP_COLUMNS.add("CUSTOMER_NAME");
    // 顧客住所
    REMIND_EXP_COLUMNS.add("CUSTOMER_ADDRESS");
    // 顧客連絡先電話番号
    REMIND_EXP_COLUMNS.add("CUSTOMER_TEL");
    // サブシステム区分
    REMIND_EXP_COLUMNS.add("SUBSYSTEM_DIV");
    // ルート区分
    REMIND_EXP_COLUMNS.add("ROOT_DIV");
    // 日付
    REMIND_EXP_COLUMNS.add("REMIND_DATE");
    // 次契約始期日
    REMIND_EXP_COLUMNS.add("NEXTINCEPTION_DATE");
    // 種目種類1
    REMIND_EXP_COLUMNS.add("PRODUCT_CODE01");
    // 種目種類2
    REMIND_EXP_COLUMNS.add("PRODUCT_CODE02");
    // 種目種類3
    REMIND_EXP_COLUMNS.add("PRODUCT_CODE03");
    // 種目種類4
    REMIND_EXP_COLUMNS.add("PRODUCT_CODE04");
    // 種目種類5
    REMIND_EXP_COLUMNS.add("PRODUCT_CODE05");
    // 種目種類6
    REMIND_EXP_COLUMNS.add("PRODUCT_CODE06");
    // 種目種類7
    REMIND_EXP_COLUMNS.add("PRODUCT_CODE07");
    // 種目種類8
    REMIND_EXP_COLUMNS.add("PRODUCT_CODE08");
    // 種目種類9
    REMIND_EXP_COLUMNS.add("PRODUCT_CODE09");
    // 種目種類10
    REMIND_EXP_COLUMNS.add("PRODUCT_CODE10");
    // 種目種類11
    REMIND_EXP_COLUMNS.add("PRODUCT_CODE11");
    // 種目種類12
    REMIND_EXP_COLUMNS.add("PRODUCT_CODE12");
    // 種目種類13
    REMIND_EXP_COLUMNS.add("PRODUCT_CODE13");
    // 種目種類14
    REMIND_EXP_COLUMNS.add("PRODUCT_CODE14");
    // 種目種類15
    REMIND_EXP_COLUMNS.add("PRODUCT_CODE15");
    // 種目種類16
    REMIND_EXP_COLUMNS.add("PRODUCT_CODE16");
    // 種目種類17
    REMIND_EXP_COLUMNS.add("PRODUCT_CODE17");
    // 種目種類18
    REMIND_EXP_COLUMNS.add("PRODUCT_CODE18");
    // 種目種類19
    REMIND_EXP_COLUMNS.add("PRODUCT_CODE19");
    // 種目種類20
    REMIND_EXP_COLUMNS.add("PRODUCT_CODE20");
    // 見積タイプ
    REMIND_EXP_COLUMNS.add("QUOTE_TYPE");
    // 代理店連番
    REMIND_EXP_COLUMNS.add("AGENT_NUMBER");
    // 親代理店組織コード
    REMIND_EXP_COLUMNS.add("PARENT_ACCOUNT_CODE");

  }

  /**
   * 夜間バッチ通知メール送信バッチ お問い合わせ出力項目名文字列
   */
  public static final List<String> NIGHT_INQUIRY_EXP_COLUMNS = new ArrayList<String>();
  static {
    NIGHT_INQUIRY_EXP_COLUMNS.add("DATE");
    NIGHT_INQUIRY_EXP_COLUMNS.add("TIME");
    NIGHT_INQUIRY_EXP_COLUMNS.add("INQUIRY_NAME");
    NIGHT_INQUIRY_EXP_COLUMNS.add("CONTENTS");
    NIGHT_INQUIRY_EXP_COLUMNS.add("EXCHANGE");
    NIGHT_INQUIRY_EXP_COLUMNS.add("BOND_NUMBER");
    NIGHT_INQUIRY_EXP_COLUMNS.add("CUSTOMER_DIV");
    NIGHT_INQUIRY_EXP_COLUMNS.add("NAME");
    NIGHT_INQUIRY_EXP_COLUMNS.add("NAME_KANA");
    NIGHT_INQUIRY_EXP_COLUMNS.add("BIRTHDAY");
    NIGHT_INQUIRY_EXP_COLUMNS.add("SEX");
    NIGHT_INQUIRY_EXP_COLUMNS.add("ZIP_CODE");
    NIGHT_INQUIRY_EXP_COLUMNS.add("ADDRESS");
    NIGHT_INQUIRY_EXP_COLUMNS.add("TEL_HOME");
    NIGHT_INQUIRY_EXP_COLUMNS.add("CONTACT");
    NIGHT_INQUIRY_EXP_COLUMNS.add("EMAIL_ADD");
    NIGHT_INQUIRY_EXP_COLUMNS.add("COMPANY");
    NIGHT_INQUIRY_EXP_COLUMNS.add("DEPARTMENT");
    NIGHT_INQUIRY_EXP_COLUMNS.add("INDUSTRY");
  }

  /**
   * 夜間バッチ通知メール送信バッチ 加入相談（火災保険）出力項目名文字列
   */
  public static final List<String> NIGHT_FIRE_EXP_COLUMNS = new ArrayList<String>();
  static {
    NIGHT_FIRE_EXP_COLUMNS.add("DATE");
    NIGHT_FIRE_EXP_COLUMNS.add("TIME");
    NIGHT_FIRE_EXP_COLUMNS.add("NAME");
    NIGHT_FIRE_EXP_COLUMNS.add("NAME_KANA");
    NIGHT_FIRE_EXP_COLUMNS.add("SEX");
    NIGHT_FIRE_EXP_COLUMNS.add("ZIP_CODE");
    NIGHT_FIRE_EXP_COLUMNS.add("ADDRESS");
    NIGHT_FIRE_EXP_COLUMNS.add("TEL_HOME");
    NIGHT_FIRE_EXP_COLUMNS.add("TEL_CONTACT");
    NIGHT_FIRE_EXP_COLUMNS.add("TEL_FAX");
    NIGHT_FIRE_EXP_COLUMNS.add("EMAIL_ADD");
    NIGHT_FIRE_EXP_COLUMNS.add("AGENCY_NAME");
    NIGHT_FIRE_EXP_COLUMNS.add("AGENCY_ADDRESS");
    NIGHT_FIRE_EXP_COLUMNS.add("AGENCY_TEL");
    NIGHT_FIRE_EXP_COLUMNS.add("AGENCY_URL");
    NIGHT_FIRE_EXP_COLUMNS.add("AGENCY_EMAILADDRESS");
    NIGHT_FIRE_EXP_COLUMNS.add("QUICK_PAGE_ID");
  }

  /**
   * 夜間バッチ通知メール送信バッチ 英語お問合わ出力項目名文字列
   */
  public static final List<String> NIGHT_ENGLISH_EXP_COLUMNS = new ArrayList<String>();
  static {
    NIGHT_ENGLISH_EXP_COLUMNS.add("DATE");
    NIGHT_ENGLISH_EXP_COLUMNS.add("TIME");
    NIGHT_ENGLISH_EXP_COLUMNS.add("CONTENTS");
    NIGHT_ENGLISH_EXP_COLUMNS.add("NAME");
    NIGHT_ENGLISH_EXP_COLUMNS.add("AGE");
    NIGHT_ENGLISH_EXP_COLUMNS.add("SEX");
    NIGHT_ENGLISH_EXP_COLUMNS.add("ADDRESS");
    NIGHT_ENGLISH_EXP_COLUMNS.add("EMAIL_ADD");
  }

  /**
   * 夜間バッチ通知メール送信バッチ 美術館お問合わ出力項目名文字列
   */
  public static final List<String> NIGHT_MUSEUM_EXP_COLUMNS = new ArrayList<String>();
  static {
    NIGHT_MUSEUM_EXP_COLUMNS.add("DATE");
    NIGHT_MUSEUM_EXP_COLUMNS.add("TIME");
    NIGHT_MUSEUM_EXP_COLUMNS.add("NAME");
    NIGHT_MUSEUM_EXP_COLUMNS.add("NAME_KANA");
    NIGHT_MUSEUM_EXP_COLUMNS.add("ZIP_CODE");
    NIGHT_MUSEUM_EXP_COLUMNS.add("ADDRESS");
    NIGHT_MUSEUM_EXP_COLUMNS.add("CONTACT_CLASSIFY");
    NIGHT_MUSEUM_EXP_COLUMNS.add("TEL_CONTACT");
    NIGHT_MUSEUM_EXP_COLUMNS.add("EMAIL_ADD");
    NIGHT_MUSEUM_EXP_COLUMNS.add("OCCUPATION");
    NIGHT_MUSEUM_EXP_COLUMNS.add("INDUSTRY");
    NIGHT_MUSEUM_EXP_COLUMNS.add("COMPANY");
    NIGHT_MUSEUM_EXP_COLUMNS.add("DEPARTMENT");
    NIGHT_MUSEUM_EXP_COLUMNS.add("BIRTHDAY");
    NIGHT_MUSEUM_EXP_COLUMNS.add("CONTENTS");
  }

  /**
   * 夜間バッチ通知メール送信バッチ 美術館英語お問合わ出力項目名文字列
   */
  public static final List<String> NIGHT_MUSEUM_ENGLISH_EXP_COLUMNS = new ArrayList<String>();
  static {
    NIGHT_MUSEUM_ENGLISH_EXP_COLUMNS.add("DATE");
    NIGHT_MUSEUM_ENGLISH_EXP_COLUMNS.add("TIME");
    NIGHT_MUSEUM_ENGLISH_EXP_COLUMNS.add("EMAIL_ADD");
    NIGHT_MUSEUM_ENGLISH_EXP_COLUMNS.add("CONTENTS");
    NIGHT_MUSEUM_ENGLISH_EXP_COLUMNS.add("NAME");
    NIGHT_MUSEUM_ENGLISH_EXP_COLUMNS.add("AGE");
    NIGHT_MUSEUM_ENGLISH_EXP_COLUMNS.add("ADDRESS");
  }

  /**
   * クラス名とConvertパラメータの対応配列
   */
  public static final Map<String, List<String>> CLASS_CONVERT_MAP =
      new HashMap<String, List<String>>();
  static {
    CLASS_CONVERT_MAP.put("jp.co.sj.xop.batch.tasklet.RemindExportDataProcessor_process",
        REMIND_EXP_COLUMNS);
    CLASS_CONVERT_MAP.put("jp.co.sj.xop.batch.tasklet.InquiryExportDataProcessor_process",
        DELIVERY_INQUIRY_EXP_COLUMNS);
    CLASS_CONVERT_MAP.put("jp.co.sj.xop.batch.tasklet.FireInsuranceExportDataProcessor_process",
        DELIVERY_FIRE_INS_EXP_COLUMNS);
    CLASS_CONVERT_MAP.put(
        "jp.co.sj.xop.batch.tasklet.NightnoticeExportDataProcessor_getInquiryInterface",
        NIGHT_INQUIRY_EXP_COLUMNS);
    CLASS_CONVERT_MAP.put(
        "jp.co.sj.xop.batch.tasklet.NightnoticeExportDataProcessor_getFireInsuranceInquiryQuery",
        NIGHT_FIRE_EXP_COLUMNS);
    CLASS_CONVERT_MAP.put(
        "jp.co.sj.xop.batch.tasklet.NightnoticeExportDataProcessor_getEnglishInquiryInterfaceQuery",
        NIGHT_ENGLISH_EXP_COLUMNS);
    CLASS_CONVERT_MAP.put(
        "jp.co.sj.xop.batch.tasklet.NightnoticeExportDataProcessor_getMuseumInquiryQuery",
        NIGHT_MUSEUM_EXP_COLUMNS);
    CLASS_CONVERT_MAP.put(
        "jp.co.sj.xop.batch.tasklet.NightnoticeExportDataProcessor_getEnglishMuseumInquiryQuery",
        NIGHT_MUSEUM_ENGLISH_EXP_COLUMNS);
  }

  /**
   * クラス名とdividerパラメータの対応配列
   */
  public static final Map<String, String> CLASS_DIVIDER_MAP = new HashMap<String, String>();
  static {
    CLASS_DIVIDER_MAP.put("jp.co.sj.xop.batch.tasklet.RemindExportDataProcessor_process",
        Constants.COMMA);
    CLASS_DIVIDER_MAP.put("jp.co.sj.xop.batch.tasklet.InquiryExportDataProcessor_process",
        Constants.VERTICAL_LINE);
    CLASS_DIVIDER_MAP.put("jp.co.sj.xop.batch.tasklet.FireInsuranceExportDataProcessor_process",
        Constants.VERTICAL_LINE);
    CLASS_DIVIDER_MAP.put(
        "jp.co.sj.xop.batch.tasklet.NightnoticeExportDataProcessor_getInquiryInterface",
        Constants.COMMA);
    CLASS_DIVIDER_MAP.put(
        "jp.co.sj.xop.batch.tasklet.NightnoticeExportDataProcessor_getFireInsuranceInquiryQuery",
        Constants.COMMA);
    CLASS_DIVIDER_MAP.put(
        "jp.co.sj.xop.batch.tasklet.NightnoticeExportDataProcessor_getEnglishInquiryInterfaceQuery",
        Constants.COMMA);
    CLASS_DIVIDER_MAP.put(
        "jp.co.sj.xop.batch.tasklet.NightnoticeExportDataProcessor_getMuseumInquiryQuery",
        Constants.COMMA);
    CLASS_DIVIDER_MAP.put(
        "jp.co.sj.xop.batch.tasklet.NightnoticeExportDataProcessor_getEnglishMuseumInquiryQuery",
        Constants.COMMA);
  }

}
