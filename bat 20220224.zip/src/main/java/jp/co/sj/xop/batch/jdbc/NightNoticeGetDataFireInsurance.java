package jp.co.sj.xop.batch.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import jp.co.sj.xop.batch.common.constants.Constants;
import jp.co.sj.xop.batch.service.SqlLoaderService;

/**
 * 火災保険加入相談データを取得するのQueryクラス.
 *
 * @author SSD 曾洋
 *
 */
@Component
public class NightNoticeGetDataFireInsurance extends BaseQuery {

  private PreparedStatement preStmt = null;
  private ResultSet rs = null;

  /**
   * SQLファイルローダー
   */
  @Autowired
  SqlLoaderService sqlLoaderService;

  public NightNoticeGetDataFireInsurance() {
    super.setMsgHead(Constants.FIRE_INSURANCE);
  }

  /**
   * Query実行するメソッドを呼び出す.
   *
   * @return ArrayList
   * @throws Exception
   */
  @Override
  protected ArrayList<HashMap<String, String>> subQuery(Map<String, String> condition,
      Connection conn, SqlLoaderService sqlLoaderService) throws Exception {
    ArrayList<HashMap<String, String>> result = new ArrayList<HashMap<String, String>>();
    // SQLを取得
    String sql = sqlLoaderService.getSql("NightNoticeGetDataFireInsurance");
    try {
      preStmt = conn.prepareStatement(sql);
      preStmt.setString(1, "0");
      preStmt.setString(2, condition.get("FORM_CODE"));
      preStmt.setString(3, condition.get("SYSTEM_TIME"));
      rs = preStmt.executeQuery();
      while (rs.next()) {
        // リターン結果にDBから取得したカラム値をセットする
        HashMap<String, String> recMap = new HashMap<String, String>();
        recMap.put("FORM_CODE", rs.getString("FORM_CODE"));
        recMap.put("INSERT_NUMBER", rs.getString("INSERT_NUMBER"));
        recMap.put("INSERT_DATETIME", rs.getString("INSERT_DATETIME"));
        recMap.put("LASTNAME", rs.getString("LASTNAME"));
        recMap.put("FIRSTNAME", rs.getString("FIRSTNAME"));
        recMap.put("LASTNAME_KANA", rs.getString("LASTNAME_KANA"));
        recMap.put("FIRSTNAME_KANA", rs.getString("FIRSTNAME_KANA"));
        recMap.put("SEX", rs.getString("SEX"));
        recMap.put("ZIP_CODE", rs.getString("ZIP_CODE"));
        recMap.put("ADDRESS_PREF", rs.getString("ADDRESS_PREF"));
        recMap.put("ADDRESS1", rs.getString("ADDRESS1"));
        recMap.put("ADDRESS2", rs.getString("ADDRESS2"));
        recMap.put("ADDRESS3", rs.getString("ADDRESS3"));
        recMap.put("TEL_HOME", rs.getString("TEL_HOME"));
        recMap.put("TEL_CONTACT", rs.getString("TEL_CONTACT"));
        recMap.put("TEL_FAX", rs.getString("TEL_FAX"));
        recMap.put("EMAIL_ADD", rs.getString("EMAIL_ADD"));
        recMap.put("OWNER_ID", rs.getString("OWNER_ID"));
        recMap.put("PARENT_ACCOUNT_CODE", rs.getString("PARENT_ACCOUNT_CODE"));
        recMap.put("CUSTOMER_NUMBER", rs.getString("CUSTOMER_NUMBER"));
        recMap.put("AGENCY_NUMBER", rs.getString("AGENCY_NUMBER"));
        recMap.put("AGENCY_EXPLANATION", rs.getString("AGENCY_EXPLANATION"));
        recMap.put("AGENCY_EXCLUDING", rs.getString("AGENCY_EXCLUDING"));
        recMap.put("AGENCY_NAME", rs.getString("AGENCY_NAME"));
        recMap.put("AGENCY_ADDRESS", rs.getString("AGENCY_ADDRESS"));
        recMap.put("AGENCY_TEL", rs.getString("AGENCY_TEL"));
        recMap.put("AGENCY_URL", rs.getString("AGENCY_URL"));
        recMap.put("AGENCY_EMAILADDRESS", rs.getString("AGENCY_EMAILADDRESS"));
        recMap.put("QUICK_PAGE_ID", rs.getString("QUICK_PAGE_ID"));
        recMap.put("ROOT_DIV", rs.getString("ROOT_DIV"));
        recMap.put("RETURN_MAIL_SEND_FLG", rs.getString("RETURN_MAIL_SEND_FLG"));
        recMap.put("INFORM_MAIL_SEND_FLG", rs.getString("INFORM_MAIL_SEND_FLG"));
        recMap.put("CSV_MAIL_SEND_FLG", rs.getString("CSV_MAIL_SEND_FLG"));
        recMap.put("CSV_MAIL_SEND_DATETIME", rs.getString("CSV_MAIL_SEND_DATETIME"));
        recMap.put("REMIND_SEND_FLAG", rs.getString("REMIND_SEND_FLAG"));
        recMap.put("REMIND_SEND_DATETIME", rs.getString("REMIND_SEND_DATETIME"));
        recMap.put("SHUHAI_SEND_FLAG", rs.getString("SHUHAI_SEND_FLAG"));
        recMap.put("SHUHAI_SEND_DATETIME", rs.getString("SHUHAI_SEND_DATETIME"));
        result.add(recMap);
      }
    } finally {
      rs.close();
      preStmt.close();
    }
    return result;
  }
}
