package jp.co.sj.xop.batch.listener;

import java.util.Locale;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.ItemProcessListener;
import org.springframework.batch.core.annotation.AfterProcess;
import org.springframework.batch.core.annotation.BeforeProcess;
import org.springframework.batch.core.annotation.OnProcessError;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;

/**
 * 編集前後に実施する処理
 *
 * @author SSD
 *
 */
@Component
public class BaseItemProcessListener implements ItemProcessListener<Object, Object> {

  /**
   * ロガー.
   */
  private static final Logger logger = LoggerFactory.getLogger(BaseItemProcessListener.class);

  /**
   * メッセージソース.
   */
  @Autowired
  private MessageSource messagesource;


  @BeforeProcess
  public void beforeProcess(Object item) {
    logger.info(messagesource.getMessage("message.LOGMSG0008I", new String[] {}, Locale.JAPAN));
  }

  @AfterProcess
  public void afterProcess(Object item, Object result) {
    logger.info(messagesource.getMessage("message.LOGMSG0009I", new String[] {}, Locale.JAPAN));
  }

  @OnProcessError
  public void onProcessError(Object item, Exception e) {}
}
