package jp.co.sj.xop.batch.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import jp.co.sj.xop.batch.service.SqlLoaderService;
import jp.co.sj.xop.batch.service.SystemTimestampService;

/**
 * 夜間バッチ通知メールバッチ 添付テーブルのデータUpdateクラス
 *
 * @author SSD
 *
 */
@Component
public class NightNoticeUpdateEnMuseumInquiry extends BaseUpdate {

  /**
   * SQLファイルローダー
   */
  @Autowired
  SqlLoaderService sqlLoaderService;


  private PreparedStatement preStmt = null;

  /**
   * Update実行メソッド
   *
   * @return updateCount
   * @throws Exception
   */

  @Override
  protected int subExecute(List<String> list, Connection conn, SqlLoaderService sqlLoaderService)
      throws Exception {
    int updateCount = 0;
    SystemTimestampService systemTimestampService = new SystemTimestampService();
    String updateTime = systemTimestampService.getDateTime();
    // SQLを取得
    String sql = sqlLoaderService.getSql("NightNoticeUpdateEnMuseumInquiry");
    try {
      if (list != null) {
        conn.setAutoCommit(false);
        preStmt = conn.prepareStatement(sql);
        for (int i = 0; i < list.size(); i++) {
          preStmt.setString(1, updateTime);
          preStmt.setString(2, "1");
          preStmt.setString(3, list.get(i).substring(0, 2));
          preStmt.setString(4, list.get(i).substring(2));

          updateCount += preStmt.executeUpdate();
        }
        conn.commit();
      }
    } finally {
        preStmt.close();
    }
    return updateCount;
  }

}
