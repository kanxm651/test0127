package jp.co.sj.xop.batch.listener;

import org.springframework.stereotype.Component;

/**
 * リマインドファイル転送バッチ のProcess前後に実施する処理。
 *
 * @author SSD 曾洋
 *
 */
@Component
public class RemindExportItemProcessListener extends BaseItemProcessListener {

}
