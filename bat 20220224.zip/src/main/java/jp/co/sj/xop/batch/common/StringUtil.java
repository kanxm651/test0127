package jp.co.sj.xop.batch.common;

import jp.co.sj.xop.batch.common.constants.Constants;

/**
 * 文字に関する共通処理.
 *
 * @author SSD 曾洋
 *
 */
public class StringUtil {

  /**
   * 空白判断.
   *
   * @param obj 判断対象
   * @return NULLと空白の場合はtrueをreturn
   */
  public static boolean isNullOrEmpty(Object obj) {
    if (obj == null || Constants.EMPTY.equals(String.valueOf(obj))) {
      return true;
    }
    return false;
  }

  /**
   * 文字列の前後に「""」を追加する.
   *
   * @param beforeEdit 編集前文字列
   *
   * @return 編集後文字列
   */
  public static String addQuotes(String beforeEdit) {
    StringBuffer sb = new StringBuffer();
    if (null == beforeEdit) {
      sb.append("\"\"");
    } else {
      sb.append("\"");
      sb.append(beforeEdit);
      sb.append("\"");
    }
    return sb.toString();
  }
}
