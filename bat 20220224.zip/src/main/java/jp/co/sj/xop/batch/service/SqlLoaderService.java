package jp.co.sj.xop.batch.service;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Component;

/**
 * Resource/sqlに格納されているSQLファイルを読み込むサービス
 *
 * @author SSD
 *
 */
@Component
public class SqlLoaderService {

  /**
   * SQL取得
   *
   * @param sqlName 読み込むSQLのファイル名(拡張子などは除く)
   * @return 読み込んだSQL
   * @throws Exception
   */
  public String getSql(String sqlName) throws Exception {
    StringBuilder sql = new StringBuilder();
    // リソースの指定
    Resource resource = new ClassPathResource(String.format("sql/%s.sql", sqlName));
    // SQLファイルの読み込み
    BufferedReader br = new BufferedReader(new InputStreamReader(resource.getInputStream()));
    String line;
    // 1行ずつSQLファイルを読み込む
    while ((line = br.readLine()) != null) {
      // コメント行は読み飛ばす
      if (line.trim().indexOf("--") == 0) {
        continue;
      }
      // 念のため、読み込んだ行の後ろに空文字を追加しておく
      sql.append(line).append(" ");
    }
    br.close();
    return sql.toString();
  }
}
