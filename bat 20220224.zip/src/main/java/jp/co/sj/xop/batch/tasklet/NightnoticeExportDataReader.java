package jp.co.sj.xop.batch.tasklet;

import java.lang.reflect.Method;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import javax.sql.DataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.ItemStreamException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;
import jp.co.sj.xop.batch.common.StringUtil;
import jp.co.sj.xop.batch.common.constants.Constants;
import jp.co.sj.xop.batch.jdbc.BaseQuery;
import jp.co.sj.xop.batch.jdbc.NightNoticeGetOption;
import jp.co.sj.xop.batch.service.SqlLoaderService;
import net.sf.json.JSONObject;
import net.sf.json.JsonConfig;
import net.sf.json.util.CycleDetectionStrategy;

/**
 * 夜間バッチ通知メール送信バッチ 取得処理
 *
 * @author SSD
 *
 */
@Component
public class NightnoticeExportDataReader extends BaseDataRead {
  private ExecutionContext executionContext;
  // インデックス
  private int idx = 0;
  // 初回処理かどうかのフラグ
  private boolean firstFlag = true;
  // オプションデータ取得リスト
  ArrayList<HashMap<String, String>> optionAllQueryArray = null;
  // オプションデータ取得配列
  HashMap<String, String> optionMap = null;

  private Connection conn = null;

  @Autowired
  public DataSource dataSource;

  @Autowired
  public SqlLoaderService sqlLoaderService;

  /**
   * ロガー.
   */
  private static final Logger logger = LoggerFactory.getLogger(NightnoticeExportDataReader.class);

  /**
   * メッセージソース
   */
  @Autowired
  private MessageSource messagesource;

  @Override
  public void open(ExecutionContext executionContext) throws ItemStreamException {
    this.executionContext = executionContext;
  }

  /**
   * データを抽出する
   *
   */
  @SuppressWarnings("unchecked")
  @Override
  public Object read() throws Exception {
    Map<String, String> map = new HashMap<String, String>();
    String key = "read";

    if (executionContext != null) {
      // バチ状態
      if (firstFlag) {
        conn = dataSource.getConnection();
        // 夜間バッチ通知メール送信バッチが既に正常に実行されている場合
        // ログを出力し、処理を正常終了する。
        IsRunSchedular.setLogHead(Constants.NIGHT_NOTICE_EXPORT_JOB_NAME_JAP);
        if (IsRunSchedular.isRunSchedularinDay(Constants.NIGHT_NOTICE_EXPORT_JOB_NAME_ENG,
            Constants.BATCH_COMPLETED)) {
          return null;
        }
        // オプションテーブル（m_option）データ取得
        BaseQuery bq = new NightNoticeGetOption();
        optionAllQueryArray = bq.query(null, conn, sqlLoaderService, messagesource);
        firstFlag = false;
      }
      if (optionAllQueryArray == null || optionAllQueryArray.size() == 0) {
        // オプションテーブルデータ取得0件の場合、処理を中止する。
        String errorMessage = messagesource.getMessage("message.LOGMSG0023I",
            new String[] {Constants.TBNAME_OPTION, Constants.EMPTY}, Locale.JAPAN);
        logger.info(errorMessage);
        throw new Exception(errorMessage);
      } else {
        // 終了の場合、状態をセット（「end」を付ける）
        if (optionAllQueryArray.size() == idx + 1) {
          key = key + "end";
        }
        if (optionAllQueryArray.size() == idx) {
          conn.close();
          return null;
        }
        optionMap = optionAllQueryArray.get(idx);
        idx++;
      }
      try {
        // メールアドレステーブル（m_mail_address）からデータ取得
        // 対象フォームテーブルからデータ取得
        Class<?> baseReaderImplClass =
            Class.forName("jp.co.sj.xop.batch.tasklet.NightnoticeExportReaderImpl");
        BaseReaderImpl baseReaderImpl =
            (BaseReaderImpl) (baseReaderImplClass.getDeclaredConstructor().newInstance());
        Method baseReaderImplMethod = baseReaderImplClass.getMethod("getReaderResult", Map.class,
            Connection.class, SqlLoaderService.class, MessageSource.class);
        HashMap<String, ArrayList<HashMap<String, String>>> result =
            new HashMap<String, ArrayList<HashMap<String, String>>>();
        result = (HashMap<String, ArrayList<HashMap<String, String>>>) baseReaderImplMethod.invoke(
            baseReaderImpl, new Object[] {optionMap, conn, sqlLoaderService, messagesource});
        // 添付リストが0件の場合
        if (result.get("jp.co.sj.xop.batch.jdbc.AttachmentQuery") == null
            || result.get("jp.co.sj.xop.batch.jdbc.AttachmentQuery").size() == 0) {
          // データが0件ログ出力
          logger.info(messagesource.getMessage(
              "message.LOGMSG0023I", new String[] {
                  Constants.FORM_TBNAME_MAP.get(optionMap.get("FORM_CODE")), Constants.EMPTY},
              Locale.JAPAN));
        }
        // メールタイトルチェック
        if (StringUtil.isNullOrEmpty(optionMap.get("CSV_MAIL_SUBJECT"))) {
          // / 対象フォームのメールタイトルが0件の場合、ログを出力する。
          String tbname = Constants.FORM_TBNAME_MAP.get(optionMap.get("FORM_CODE"));
          String errorMessage = messagesource.getMessage("message.LOGMSG0014E",
              new String[] {Constants.TBNAME_OPTION, tbname}, Locale.JAPAN);
          logger.error(errorMessage);
          throw new Exception(errorMessage);
        }
        // オプションテーブル（m_option）データセット
        ArrayList<HashMap<String, String>> NightNoticeGetFormOption =
            new ArrayList<HashMap<String, String>>();
        NightNoticeGetFormOption.add(optionMap);
        result.put("jp.co.sj.xop.batch.jdbc.NightNoticeGetFormOption", NightNoticeGetFormOption);

        // 取得データをJson型に転換する
        JsonConfig jsonConfig = new JsonConfig();
        jsonConfig.setCycleDetectionStrategy(CycleDetectionStrategy.LENIENT);
        JSONObject object = JSONObject.fromObject(result, jsonConfig);
        map.put(key, object.toString());
        return map;
      } catch (Exception e) {
        // エラーの場合、状態をセット（「error」を付ける）
        key = key + "error";
        map = new HashMap<String, String>();
        if (!StringUtil.isNullOrEmpty(optionMap.get("CSV_MAIL_SUBJECT"))) {
          map.put(key, optionMap.get("CSV_MAIL_SUBJECT"));
        } else {
          map.put(key, "ERROR");
        }
        return map;
      }
    }
    return map;
  }
}
