package jp.co.sj.xop;

import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import jp.co.sj.xop.batch.listener.S3FileDelItemProcessListener;
import jp.co.sj.xop.batch.listener.S3FileDelItemReadListener;
import jp.co.sj.xop.batch.listener.S3FileDelItemWriteListener;
import jp.co.sj.xop.batch.listener.S3FileDelJobListener;
import jp.co.sj.xop.batch.listener.S3FileDelStepListener;
import jp.co.sj.xop.batch.tasklet.S3FileDelProcessor;
import jp.co.sj.xop.batch.tasklet.S3FileDelReader;
import jp.co.sj.xop.batch.tasklet.S3FileDelWriter;

/**
 * 不要ファイル削除バッチ Controllerクラス
 *
 * @author SSD
 *
 */
@EnableBatchProcessing
@EnableAutoConfiguration
@ComponentScan
public class S3FileDelController extends BaseController {

  @Autowired
  public JobBuilderFactory jobBuilderFactory;

  /**
   * リスナー定義
   */
  @Autowired
  private S3FileDelItemProcessListener s3FileDelItemProcessListener;
  @Autowired
  private S3FileDelItemReadListener s3FileDelItemReadListener;
  @Autowired
  private S3FileDelItemWriteListener s3FileDelItemWriteListener;
  @Autowired
  private S3FileDelJobListener s3FileDelJobListener;
  @Autowired
  private S3FileDelStepListener s3FileDelStepListener;

  /**
   * 取得処理定義
   */
  @Autowired
  private S3FileDelReader s3FileDelReader;
  /**
   * 編集処理定義
   */
  @Autowired
  private S3FileDelProcessor s3FileDelProcessor;
  /**
   * 出力処理定義
   */
  @Autowired
  private S3FileDelWriter s3FileDelWriter;

  /**
   * mainメソッド
   *
   * @param args 引数
   */
  public static void main(String[] args) throws Exception {
    SpringApplication.run(S3FileDelController.class, args);
  }

  /**
   * Job実行メソッド
   *
   * @return Job
   * @throws Exception
   */
  @Bean(name = "S3FileDelBatchJob")
  public Job NightnoticeExportBatchJob(JobBuilderFactory jobBuilderFactory) throws Exception {
    // 不要ファイル削除Jobの取得ファイルセット
    super.setBaseDataRead(s3FileDelReader);
    // 不要ファイル削除Jobの編集ファイルセット
    super.setBaseDataProcessor(s3FileDelProcessor);
    // 不要ファイル削除Jobの出力ファイルセット
    super.setBaseDataWriter(s3FileDelWriter);
    // 不要ファイル削除JobのStepリスナーセット
    super.setBaseStepListener(s3FileDelStepListener);
    // 不要ファイル削除JobのReadリスナーセット
    super.setBaseItemReadListener(s3FileDelItemReadListener);
    // 不要ファイル削除JobのProcessリスナーセット
    super.setBaseItemProcessListener(s3FileDelItemProcessListener);
    // 不要ファイル削除JobのWriteリスナーセット
    super.setBaseItemWriteListener(s3FileDelItemWriteListener);
    // 不要ファイル削除Jobを実行
    return jobBuilderFactory.get("S3FileDelBatchJob").incrementer(new RunIdIncrementer())
        // step処理開始
        .preventRestart().start(stepExecution())
        // 正常の場合、ステータスと終了コードを取得、Job完了
        .on(ExitStatus.COMPLETED.getExitCode()).end()
        // 異常した場合、ステータスと終了コードを取得、Job完了
        .on(ExitStatus.FAILED.getExitCode()).fail().end()
        // 不要ファイル削除Jobリスナーセット
        .listener(s3FileDelJobListener)
        // Job実行
        .build();
  }
}
