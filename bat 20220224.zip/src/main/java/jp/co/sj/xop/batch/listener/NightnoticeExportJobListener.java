package jp.co.sj.xop.batch.listener;

import org.springframework.stereotype.Component;
import jp.co.sj.xop.batch.common.constants.Constants;

/**
 * 夜間バッチ通知メール送信バッチ のJob前後に実施する処理。
 *
 * @author SSD
 *
 */
@Component
public class NightnoticeExportJobListener extends BaseJobListener {
  public NightnoticeExportJobListener() {
    super.setLogHead(Constants.NIGHT_NOTICE_EXPORT_JOB_NAME_JAP);
  }
}
