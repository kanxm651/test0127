package jp.co.sj.xop.batch.tasklet;

import java.lang.reflect.Method;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import javax.sql.DataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;
import jp.co.sj.xop.batch.common.constants.Constants;
import jp.co.sj.xop.batch.jdbc.BaseUpdate;
import jp.co.sj.xop.batch.service.S3Services;
import jp.co.sj.xop.batch.service.SqlLoaderService;

/**
 * リマインドテーブルの更新処理.
 *
 * @author SSD 曾
 *
 */
@Component
public class RemindExportDataWriter extends BaseDataWriter {
  /**
   * ロガー.
   */
  private static final Logger logger = LoggerFactory.getLogger(RemindExportDataWriter.class);

  private ExecutionContext executionContext;
  private Connection conn = null;
  private StepExecution stepExecution;

  @Autowired
  S3Services s3Services;

  @Autowired
  public DataSource dataSource;

  @Autowired
  public SqlLoaderService sqlLoaderService;

  /**
   * メッセージソース.
   */
  @Autowired
  private MessageSource messagesource;

  @Override
  public void open(ExecutionContext executionContext) {
    this.executionContext = executionContext;
  }

  @BeforeStep
  public void beforeStep(StepExecution stepExecution) {
    this.stepExecution = stepExecution;
  }

  /**
   * データファイルアップロード状態をテーブルに更新
   *
   */
  @SuppressWarnings({"rawtypes", "unchecked"})
  @Override
  public void write(List items) throws Exception {

    boolean delRtnFlg = false;

    if (executionContext != null) {

      // テーブルに更新データ配列
      Map<String, Object> writerParamMap = new HashMap<String, Object>();
      writerParamMap = (Map<String, Object>) items.get(0);
      // リーズ番号リストサイズ
      int leadsNumberListSize = 0;
      // エラーフラグ
      String processerrorFlag = null;
      // エラーフラグ
      Boolean errorFlag = false;
      // テーブルに更新フラグ
      String updateFlag = null;
      updateFlag = (String) writerParamMap.get("UPDATE_FLAG");
      processerrorFlag = (String) writerParamMap.get("ERROR_FLAG");

      if (Constants.ERROR.equals(processerrorFlag)) {
        errorFlag = true;
      } else if (!Constants.DO_NOT.equals(updateFlag)) {
        // リーズ番号リスト
        List<String> leadsNumberList = new ArrayList<String>();
        leadsNumberList = (List<String>) writerParamMap.get("LEADS_NUMBER_LIST");
        try {
          conn = dataSource.getConnection();
          // リマインドテーブルを更新する。
          Map<String, String> writeFunctionMap = new HashMap<String, String>();
          writeFunctionMap.put("jp.co.sj.xop.batch.jdbc.RemindUpdateFireInsurance", "execute");

          for (String key : writeFunctionMap.keySet()) {
            // リマインドテーブルを更新する。
            Class<?> baseUpadateClass = Class.forName(key);
            BaseUpdate baseUpdate =
                (BaseUpdate) (baseUpadateClass.getDeclaredConstructor().newInstance());
            Method updateMethod = baseUpadateClass.getMethod(writeFunctionMap.get(key), List.class,
                Connection.class, SqlLoaderService.class);
            leadsNumberListSize = (int) updateMethod.invoke(baseUpdate,
                new Object[] {leadsNumberList, conn, sqlLoaderService});
            // 更新成功の場合ログを出力する。
            logger.info(messagesource.getMessage("message.LOGMSG0018I",
                new String[] {Constants.REMIND_EXPORT_JOB_NAME_ENG + Constants.FIRE_INSURANCE,
                    String.valueOf(leadsNumberListSize)},
                Locale.JAPAN));
            conn.close();
          }
        } catch (Exception e) {
          // 更新失敗の場合ログを出力する。
          logger.error(messagesource.getMessage("message.LOGMSG0009E",
              new String[] {Constants.FIRE_INSURANCE}, Locale.JAPAN));

          // S3にアップロードしたファイル削除を処理する。
          if (s3Services.isFileExists(
              Constants.FILE_PATH_REMIND + Constants.FILE_NAME_REMIND + Constants.FILE_TYPE_TXT)) {
            delRtnFlg = s3Services.deleteFile(
                Constants.FILE_PATH_REMIND + Constants.FILE_NAME_REMIND + Constants.FILE_TYPE_TXT);

            if (!delRtnFlg) {
              // ファイル削除失敗ログを出力する
              logger.error(messagesource.getMessage("message.LOGMSG0010E",
                  new String[] {Constants.REMIND}, Locale.JAPAN));
            } else {
              // ファイル削除成功ログを出力する
              logger.info(messagesource.getMessage("message.LOGMSG0019I",
                  new String[] {Constants.REMIND}, Locale.JAPAN));
            }
          }
          // バックアップファイル名を取得する
          String bkFileName = writerParamMap.get("BK_FILE_NAME").toString();
          // S3にアップロードしたバックアップファイルの削除を処理する。
          if (delRtnFlg && s3Services.isFileExists(Constants.BKFILE_PATH_REMIND + bkFileName)) {
            delRtnFlg = s3Services.deleteFile(Constants.BKFILE_PATH_REMIND + bkFileName);

            if (!delRtnFlg) {
              // バックアップファイル削除失敗ログを出力する
              logger.error(messagesource.getMessage("message.LOGMSG0010E",
                  new String[] {Constants.REMIND_BACKUP}, Locale.JAPAN));
            } else {
              // バックアップファイル削除成功ログを出力する
              logger.info(messagesource.getMessage("message.LOGMSG0019I",
                  new String[] {Constants.REMIND_BACKUP}, Locale.JAPAN));
            }
          }
          // バッチを中止する
          throw e;
        }
      }
      if (errorFlag) {
        stepExecution.setExitStatus(ExitStatus.FAILED);
      }
    }
  }
}

