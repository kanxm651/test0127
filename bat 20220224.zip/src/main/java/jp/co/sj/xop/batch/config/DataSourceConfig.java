package jp.co.sj.xop.batch.config;

import java.net.URI;
import java.net.URISyntaxException;
import javax.sql.DataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * データソース初期化用コンフィグ
 *
 * @author SSD
 *
 */
@Configuration
public class DataSourceConfig {
  /**
   * ロガー
   */
  private static final Logger logger = LoggerFactory.getLogger(DataSourceConfig.class);

  /**
   * ロガー
   */
  @Value("${app.database_url}")
  private String databaseUrl;

  /**
   * データソース初期設定.
   *
   * @return
   */
  @Bean
  public DataSource createDataSource() {
    DataSource dataSource = null;

    // 環境変数DATABASE_URLからpostgresql接続情報を取得
    logger.debug("Initializing PostgreSQL database: {}", databaseUrl);

    try {
      // 接続情報からホスト名/ユーザ名/パスワードを取得
      URI dbUri = new URI(databaseUrl);

      String username = dbUri.getUserInfo().split(":")[0];
      String password = dbUri.getUserInfo().split(":")[1];

      // jdbc接続用のURLを作成
      String dbUrl = String.format("jdbc:postgresql://%s:%s%s", dbUri.getHost(), dbUri.getPort(),
          dbUri.getPath());

      // データソース作成
      dataSource =
          DataSourceBuilder.create().url(dbUrl).username(username).password(password).build();
    } catch (URISyntaxException e) {
      logger.error("Invalid DATABASE_URL: {}", databaseUrl, e);
    }

    return dataSource;
  }
}
