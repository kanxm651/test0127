package jp.co.sj.xop.batch.tasklet;

import java.lang.reflect.Method;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;
import jp.co.sj.xop.batch.common.DateTimeUtil;
import jp.co.sj.xop.batch.common.JSONXOPUtils;
import jp.co.sj.xop.batch.common.LocalDateTimeEx;
import jp.co.sj.xop.batch.common.TempFileUtils;
import jp.co.sj.xop.batch.common.constants.Constants;
import jp.co.sj.xop.batch.common.constants.DateTimeConstants;
import jp.co.sj.xop.batch.service.S3Services;

/**
 * リマインドファイルの加工処理.
 *
 * @author SSD
 *
 */
@Component
public class RemindExportDataProcessor extends BaseDataProcessor {

  /**
   * S3Services.
   */
  @Autowired
  S3Services s3Services;

  /**
   * メッセージソース.
   */
  @Autowired
  private MessageSource messagesource;

  /**
   * フォルダパス文字列.
   */
  @Value("${app.temp_folder_path}")
  private String tempfolder;

  /**
   * ロガー.
   */
  private static final Logger logger = LoggerFactory.getLogger(RemindExportDataProcessor.class);

  /**
   * 抽出したデータをファイルに加工処理.
   *
   * @param item 抽出したデータ配列
   * @return 出力レコード配列
   */
  @SuppressWarnings("unchecked")
  @Override
  public Object process(Object item) throws Exception {
    // データファイルパス
    String fileAbsolutePath = Constants.EMPTY;
    // バックアップファイル名
    String aftName = null;
    // 加工処理フラグ
    boolean processorFlag = false;
    // Ｓ３サーバーにアップロードのフラグ
    boolean upFileFlg = false;
    // ファイルに書き込みデータリスト
    ArrayList<String> outputList = new ArrayList<String>();
    // リザルトデータ配列
    Map<String, Object> result = new HashMap<String, Object>();
    // 状態リスト
    ArrayList<String> condition = new ArrayList<String>();
    // 抽出したデータ
    String processorParam = Constants.EMPTY;
    // クラス名
    String thisclassName = this.getClass().getName();
    // メソッド名
    String thismethodName = Thread.currentThread().getStackTrace()[1].getMethodName();
    // データ作成メソッドキー
    String StringMosaicKey = thisclassName + "_" + thismethodName;
    processorParam = item.toString();
    // 出力レコード配列
    HashMap<String, Object> subFlagMap = new HashMap<String, Object>();

    // バチ状態検証
    if ("read".equals(processorParam.substring(1, 5))) {

      try {
        // 出力レコード配列取得
        result = JSONXOPUtils.object2Map(item);
        // リマインドデータ
        List<HashMap<String, String>> remindList = new ArrayList<HashMap<String, String>>();
        remindList =
            (List<HashMap<String, String>>) result.get("jp.co.sj.xop.batch.jdbc.RemindQuery");
        // 抽出したリマインドデータは0件の場合
        // 空ファイル作成、テーブルに更新不要となります
        if (remindList.size() == 0) {
          subFlagMap.put("UPDATE_FLAG", "DO_NOT");

        } else {
          String resultstr = Constants.EMPTY;
          // データ組合せメソッド呼び出す
          Class<?> convertUtilClass = Class.forName("jp.co.sj.xop.batch.common.ConvertUtil");
          Method getMethod = convertUtilClass.getMethod("StringMosaiWithQuotes", List.class,
              HashMap.class, String.class);
          // 抽出したリマインドデータは複数件の場合
          for (HashMap<String, String> singleMap : remindList) {
            // ファイルに書き込みデータ作成
            resultstr = (String) getMethod.invoke(convertUtilClass,
                new Object[] {Constants.CLASS_CONVERT_MAP.get(StringMosaicKey.trim()), singleMap,
                    Constants.CLASS_DIVIDER_MAP.get(StringMosaicKey.trim())});
            outputList.add(resultstr);
            condition.add(singleMap.get("LEADS_NUMBER"));
            subFlagMap.put("LEADS_NUMBER_LIST", condition);
          }
        }
        // 出力レコード配列に書き込みデータ追加
        subFlagMap.put("OUTPUT_LIST", outputList);
        processorFlag = true;
        // データ編集成功のログを出力する。
        logger.info(messagesource.getMessage("message.LOGMSG0013I", new String[] {Constants.REMIND},
            Locale.JAPAN));

      } catch (Exception e) {
        // データ編集失敗のログを出力する。
        logger.error(messagesource.getMessage("message.LOGMSG0004E",
            new String[] {Constants.REMIND}, Locale.JAPAN));
        processorFlag = false;
        // バッチを中止する
        throw e;

      }

      /*
       * リマインドのtempファイル作成する
       */
      if (processorFlag) {
        outputList = (ArrayList<String>) subFlagMap.get("OUTPUT_LIST");
        try {
          // データファイルに書き込み
          fileAbsolutePath = TempFileUtils.createTempFile(outputList, tempfolder,
              Constants.FILE_NAME_REMIND, Constants.FILE_TYPE_TXT);
          // ファイルを作成成功のログを出力する。
          logger.info(messagesource.getMessage("message.LOGMSG0014I",
              new String[] {Constants.REMIND}, Locale.JAPAN));
        } catch (Exception e) {
          processorFlag = false;
          // ファイルを作成失敗ログを出力する。
          logger.error(messagesource.getMessage("message.LOGMSG0005E",
              new String[] {Constants.REMIND}, Locale.JAPAN));
          // バッチを中止する
          throw e;
        }
      }
      /*
       * Ｓ３サーバーにアップロードする
       */
      if (processorFlag) {
        // データファイル を Ｓ３サーバーにアップロードする
        upFileFlg = s3Services.uploadFile(
            Constants.FILE_PATH_REMIND + Constants.FILE_NAME_REMIND + Constants.FILE_TYPE_TXT,
            fileAbsolutePath);
        if (!upFileFlg) {
          processorFlag = false;
          // アップロード失敗のログを出力する。
          String ErrorMsg = messagesource.getMessage("message.LOGMSG0007E",
              new String[] {Constants.REMIND}, Locale.JAPAN);
          logger.error(ErrorMsg);
          // バッチを中止する
          throw new Exception(ErrorMsg);
        } else {
          // アップロード成功のログを出力する。
          logger.info(messagesource.getMessage("message.LOGMSG0016I",
              new String[] {Constants.REMIND}, Locale.JAPAN));
        }
      }
      /*
       * Ｓ３サーバーにバックアップファイルアップロードする
       */
      if (processorFlag) {
        // 時間を取得する
        Timestamp nowTimestamp = Timestamp.valueOf(LocalDateTimeEx.now());
        String strHour =
            DateTimeUtil.format(nowTimestamp, DateTimeConstants.DATETIMEFORMAT_DATETIME13);
        aftName = Constants.BKFILE_PATH_REMIND + Constants.FILE_NAME_REMIND + "_" + strHour
            + Constants.FILE_TYPE_AFT;
        // バックアップファイルに書き込み
        // データファイルのバックアップ を Ｓ３サーバーにアップロードする
        upFileFlg = s3Services.uploadBackupFile(aftName, fileAbsolutePath);

        subFlagMap.put("BK_FILE_NAME",
            Constants.FILE_NAME_REMIND + "_" + strHour + Constants.FILE_TYPE_AFT);
        if (!upFileFlg) {
          // bkファイルアップロード失敗のログを出力する。
          logger.error(messagesource.getMessage("message.LOGMSG0007E",
              new String[] {Constants.REMIND_BACKUP}, Locale.JAPAN));
        } else {
          // bkファイルアップロード成功のログを出力する。
          logger.info(messagesource.getMessage("message.LOGMSG0016I",
              new String[] {Constants.REMIND_BACKUP}, Locale.JAPAN));
        }
      }

      if (!processorFlag) {
        // エラーの場合、状態をセット（「error」を付ける）
        subFlagMap.put("ERROR_FLAG", "ERROR");
        return subFlagMap;
      }
    }
    return subFlagMap;
  }

}
