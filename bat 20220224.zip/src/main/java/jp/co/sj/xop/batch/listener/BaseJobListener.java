package jp.co.sj.xop.batch.listener;

import java.util.Locale;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;
import jp.co.sj.xop.batch.common.constants.Constants;

/**
 * job処理の前後に実施する処理
 *
 * @author SSD
 *
 */
@Component
public class BaseJobListener implements JobExecutionListener {

  /**
   * ロガー.
   */
  private static final Logger logger = LoggerFactory.getLogger(BaseJobListener.class);

  /**
   * メッセージソース.
   */
  @Autowired
  private MessageSource messagesource;

  private String logHead = Constants.EMPTY;

  protected void setLogHead(String logHead) {
    this.logHead = logHead;
  }

  @Override
  public void beforeJob(JobExecution jobExecution) {
    logger.info(
        messagesource.getMessage("message.LOGMSG0001I", new String[] {this.logHead}, Locale.JAPAN));
  }

  @Override
  public void afterJob(JobExecution jobExecution) {
    ExitStatus status = jobExecution.getExitStatus();
    if (ExitStatus.COMPLETED.equals(status)) {
      logger.info(messagesource.getMessage("message.LOGMSG0002I", new String[] {this.logHead},
          Locale.JAPAN));
    } else {
      logger.error(messagesource.getMessage("message.LOGMSG0001E", new String[] {this.logHead},
          Locale.JAPAN));
    }
  }
}
