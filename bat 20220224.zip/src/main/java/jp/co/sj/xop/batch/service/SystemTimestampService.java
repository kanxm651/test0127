package jp.co.sj.xop.batch.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.springframework.stereotype.Component;
import jp.co.sj.xop.batch.common.constants.Constants;

/**
 * S3 アクセス共通クラス.
 *
 * @author SSD
 */

@Component
public class SystemTimestampService {

  // ローカル日付 yyyyMMdd HH:mm:ss
  // @Value("${LOCAL_DATE_TIME}")
  // private String localDateTime = "20210301 22:59:59";
  private String localDateTime = Constants.EMPTY;

  /**
   * 日付を取得する
   *
   * @param localDateTime ローカル日付 (yyyyMMdd HH:mm:ss)
   * @return 実行結果（ローカル日付 や システム日付）
   */
  public String getDateTime() {
    String result = Constants.EMPTY;
    boolean localDateTimeFlag = true;
    SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd HH:mm:ss");
    try {
      sdf.parse(localDateTime);
      result = localDateTime;
    } catch (ParseException e) {
      localDateTimeFlag = false;
    }
    if (!localDateTimeFlag) {
      Date now = new Date();
      result = sdf.format(now);
    }
    return result;
  }
}
