package jp.co.sj.xop;

import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import jp.co.sj.xop.batch.listener.FireInsuranceExportItemProcessListener;
import jp.co.sj.xop.batch.listener.FireInsuranceExportItemReadListener;
import jp.co.sj.xop.batch.listener.FireInsuranceExportItemWriteListener;
import jp.co.sj.xop.batch.listener.FireInsuranceExportJobListener;
import jp.co.sj.xop.batch.listener.FireInsuranceExportStepListener;
import jp.co.sj.xop.batch.tasklet.FireInsuranceExportDataProcessor;
import jp.co.sj.xop.batch.tasklet.FireInsuranceExportDataReader;
import jp.co.sj.xop.batch.tasklet.FireInsuranceExportDataWriter;

/**
 * 集配信システムへファイル転送（火災保険加入相談）バッチのcontrollerクラス.
 *
 * @author SSD
 *
 */
@EnableBatchProcessing
@EnableAutoConfiguration
@ComponentScan
public class FireInsuranceExportController extends BaseController {

  @Autowired
  public JobBuilderFactory jobBuilderFactory;

  /**
   * リスナー定義
   */
  @Autowired
  private FireInsuranceExportItemProcessListener fireInsuranceExportItemProcessListener;
  @Autowired
  private FireInsuranceExportItemReadListener fireInsuranceExportItemReadListener;
  @Autowired
  private FireInsuranceExportItemWriteListener fireInsuranceExportItemWriteListener;
  @Autowired
  private FireInsuranceExportJobListener fireInsuranceExportJobListener;
  @Autowired
  private FireInsuranceExportStepListener fireInsuranceExportStepListener;

  /**
   * 取得処理定義
   */
  @Autowired
  private FireInsuranceExportDataReader fireInsuranceExportDataReader;
  /**
   * 編集処理定義
   */
  @Autowired
  private FireInsuranceExportDataProcessor fireInsuranceExportDataProcessor;

  /**
   * 出力処理定義
   */
  @Autowired
  private FireInsuranceExportDataWriter fireInsuranceExportDataWriter;

  /**
   * mainメソッド.
   *
   * @param args 引数。「batchID」指定。
   */
  public static void main(String[] args) throws Exception {
    SpringApplication.run(FireInsuranceExportController.class, args);
  }

  /**
   * Job実行するメソッドを呼び出す.
   *
   * @return Job
   * @throws Exception
   */
  @Bean(name = "FireInsuranceExportBatchJob")
  public Job FireInsuranceExportBatchJob(JobBuilderFactory jobBuilderFactory) throws Exception {
    // 集配信システムへファイル転送（火災保険加入相談）Jobの取得データセット
    super.setBaseDataRead(fireInsuranceExportDataReader);
    // 集配信システムへファイル転送（火災保険加入相談）Jobの編集データセット
    super.setBaseDataProcessor(fireInsuranceExportDataProcessor);
    // 集配信システムへファイル転送（火災保険加入相談）Jobの出力データセット
    super.setBaseDataWriter(fireInsuranceExportDataWriter);
    // 集配信システムへファイル転送（火災保険加入相談）JobのStepリスナーセット
    super.setBaseStepListener(fireInsuranceExportStepListener);
    // 集配信システムへファイル転送（火災保険加入相談）JobのReadリスナーセット
    super.setBaseItemReadListener(fireInsuranceExportItemReadListener);
    // 集配信システムへファイル転送（火災保険加入相談）JobのProcessリスナーセット
    super.setBaseItemProcessListener(fireInsuranceExportItemProcessListener);
    // 集配信システムへファイル転送（火災保険加入相談）JobのWriteリスナーセット
    super.setBaseItemWriteListener(fireInsuranceExportItemWriteListener);
    // 集配信システムへファイル転送（火災保険加入相談）Jobを実行
    return jobBuilderFactory.get("FireInsuranceExportBatchJob").incrementer(new RunIdIncrementer())
        // step処理開始
        .preventRestart().start(stepExecution())
        // 正常の場合、ステータスと終了コードを取得、Job完了
        .on(ExitStatus.COMPLETED.getExitCode()).end()
        // 異常した場合、ステータスと終了コードを取得、Job完了
        .on(ExitStatus.FAILED.getExitCode()).fail().end()
        // 集配信システムへファイル転送（火災保険加入相談）Jobリスナーセット
        .listener(fireInsuranceExportJobListener)
        // Job実行
        .build();
  }

}
