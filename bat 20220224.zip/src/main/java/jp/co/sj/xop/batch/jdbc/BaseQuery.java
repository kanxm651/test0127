package jp.co.sj.xop.batch.jdbc;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;
import jp.co.sj.xop.batch.common.constants.Constants;
import jp.co.sj.xop.batch.service.SqlLoaderService;

/**
 * データ取得Queryクラス
 *
 * @author SSD
 *
 */
@Component
public class BaseQuery {

  /**
   * ロガー
   */
  private static final Logger logger = LoggerFactory.getLogger(BaseQuery.class);

  private String msgHead = Constants.EMPTY;

  protected void setMsgHead(String msg) {
    this.msgHead = msg;
  }

  // 成功の場合
  private void successLog(MessageSource messagesource) {
    logger.info(
        messagesource.getMessage("message.LOGMSG0012I", new String[] {this.msgHead}, Locale.JAPAN));
  }

  // 失敗の場合
  private void errorLog(MessageSource messagesource, Exception e) {
    logger.error(
        messagesource.getMessage("message.LOGMSG0003E", new String[] {this.msgHead}, Locale.JAPAN),
        e);
  }

  /**
   * Query実行メソッド
   *
   * @return ArrayList
   * @throws Exception
   */
  public ArrayList<HashMap<String, String>> query(Map<String, String> condition, Connection conn,
      SqlLoaderService sqlLoaderService, MessageSource messagesource) throws Exception {
    ArrayList<HashMap<String, String>> result = new ArrayList<HashMap<String, String>>();
    try {
      result = subQuery(condition, conn, sqlLoaderService);
      successLog(messagesource);
    } catch (Exception e) {
      errorLog(messagesource, e);
      throw e;
    }
    return result;
  }

  /**
   * Query実行メソッド
   *
   * @return ArrayList
   * @throws Exception
   */
  protected ArrayList<HashMap<String, String>> subQuery(Map<String, String> condition,
      Connection conn, SqlLoaderService sqlLoaderService) throws Exception {
    return null;
  }
}
