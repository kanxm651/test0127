package jp.co.sj.xop.batch.tasklet;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import javax.sql.DataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.ItemStreamException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;
import jp.co.sj.xop.batch.common.ParamConvert;
import jp.co.sj.xop.batch.common.constants.Constants;
import jp.co.sj.xop.batch.jdbc.BaseQuery;
import jp.co.sj.xop.batch.jdbc.RemindGetDataFireInsurance;
import jp.co.sj.xop.batch.service.S3Services;
import jp.co.sj.xop.batch.service.SqlLoaderService;
import net.sf.json.JSONObject;
import net.sf.json.JsonConfig;
import net.sf.json.util.CycleDetectionStrategy;

/**
 * リマインドのデータを取得
 *
 * @author SSD 曾
 *
 */
@Component
public class RemindExportDataReader extends BaseDataRead {
  private ExecutionContext executionContext;
  // 初回処理かどうかのフラグ
  private boolean firstFlag = true;
  // バチ状態
  private String key = "readend";
  // 火災保険加入相談テーブル（t_fire_insurance_inquiry）データ取得の配列
  ArrayList<HashMap<String, String>> fireInsuranceInquiryQueryArray = null;
  // リマインドデータ配列
  ArrayList<HashMap<String, String>> remindQueryArray = null;
  private Connection conn = null;


  @Autowired
  S3Services s3Services;

  @Autowired
  public DataSource dataSource;

  @Autowired
  SqlLoaderService sqlLoaderService;

  @Autowired
  private MessageSource messagesource;


  /**
   * ロガー.
   */
  private static final Logger logger = LoggerFactory.getLogger(RemindExportDataReader.class);

  @Override
  public void open(ExecutionContext executionContext) throws ItemStreamException {
    this.executionContext = executionContext;
  }

  /**
   * データを抽出する
   *
   */
  @Override
  public Object read() throws Exception {
    Map<String, String> map = new HashMap<String, String>();
    if (executionContext != null) {
      if (firstFlag) {
        conn = dataSource.getConnection();
        // リマインドファイル転送バッチが既に正常に実行されている場合
        // ログを出力し、処理を正常終了する。
        IsRunSchedular.setLogHead(Constants.REMIND_EXPORT_JOB_NAME_JAP);
        if (IsRunSchedular.isRunSchedularinDay(Constants.REMIND_EXPORT_JOB_NAME_ENG,
            Constants.BATCH_COMPLETED)) {
          return null;
        }
        // 火災保険加入相談テーブル(t_fire_insurance_inquiry)データ取得
        BaseQuery bq = new RemindGetDataFireInsurance();
        fireInsuranceInquiryQueryArray = bq.query(null, conn, sqlLoaderService, messagesource);
        if (fireInsuranceInquiryQueryArray == null || fireInsuranceInquiryQueryArray.size() == 0) {
          // データが取得しない または 0件取得の場合、ログを出力
          logger.info(messagesource.getMessage("message.LOGMSG0023I",
              new String[] {Constants.FIRE_INSURANCE, Constants.EMPTY}, Locale.JAPAN));
        }
        remindQueryArray = ParamConvert.getRemind(fireInsuranceInquiryQueryArray);
        firstFlag = false;
      } else {
        conn.close();
        return null;
      }
      // データをJson型に転換する
      HashMap<String, ArrayList<HashMap<String, String>>> resultSet =
          new HashMap<String, ArrayList<HashMap<String, String>>>();
      resultSet.put("jp.co.sj.xop.batch.jdbc.RemindQuery", remindQueryArray);
      JsonConfig jsonConfig = new JsonConfig();
      jsonConfig.setCycleDetectionStrategy(CycleDetectionStrategy.LENIENT);
      JSONObject object = JSONObject.fromObject(resultSet, jsonConfig);
      String result = object.toString();
      map.put(key, result);
    }
    return map;

  }
}
