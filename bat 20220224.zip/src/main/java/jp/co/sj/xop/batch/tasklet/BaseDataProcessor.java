package jp.co.sj.xop.batch.tasklet;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.stereotype.Component;

/**
 * 編集処理
 *
 * @author SSD
 *
 */
@Component
public class BaseDataProcessor implements ItemProcessor<Object, Object> {

  @Override
  public Object process(Object item) throws Exception {
    // TODO 自動生成されたメソッド・スタブ
    return null;
  }
}
