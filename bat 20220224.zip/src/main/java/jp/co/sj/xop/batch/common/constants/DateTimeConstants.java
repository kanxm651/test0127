package jp.co.sj.xop.batch.common.constants;

/**
 * 日付フォーマット定数クラス.
 *
 * @author SSD
 *
 */
public class DateTimeConstants {

  /**
   * バッチ用共通定数：DateTimeFormatterで指定する日付の書式.
   */
  public static final String DATETIMEFORMAT_DATE = "yyyyMMdd";

  /**
   * バッチ用共通定数：DateTimeFormatterで指定する日付の書式.
   */
  public static final String DATETIMEFORMAT_DATETIME = "yyyyMMddHHmmss";
  /**
   * バッチ用共通定数：DateTimeFormatterで指定する日付の書式.
   */
  public static final String DATETIMEFORMAT_DATEHOUR = "yyyyMMddHH";
  /**
   * DateTimeFormatterで指定する日時の書式.
   */
  public static final String DATETIMEFORMAT_DATETIME13 = "yyyyMMdd_HHmm";

  /**
   * バッチ用共通定数：DateTimeFormatterで指定する日付の書式.
   */
  public static final String DATETIMEFORMAT_TIME4 = "HHmm";

  /**
   * バッチ用共通定数：DateTimeFormatterで指定する日付の書式.
   */
  public static final String DATETIMEFORMAT_TIME6 = "HHmmss";

  /**
   * バッチ用共通定数：DateTimeFormatterで指定する日付の書式.
   */
  public static final String DATETIMEFORMAT_ACCEPT_DATE = "yyyy/MM/dd HH:mm:ss";

  /**
   * バッチ用共通定数：DateTimeFormatterで指定する日付の書式.
   */
  public static final String DATETIMEFORMAT_DATE_TIME = "yyyy-MM-dd HH:mm:ss";

  /**
   * バッチ用共通定数：DateTimeFormatterで指定する日付の書式.
   */
  public static final String DATETIMEFORMAT_NIGHTBATDATE = "yyyy-MM-dd";

  /**
   * バッチ用共通定数：DateTimeFormatterで指定する日付の書式.
   */
  public static final String DATETIMEFORMAT_NIGHTBATTIME = "HH:mm:ss";
}
