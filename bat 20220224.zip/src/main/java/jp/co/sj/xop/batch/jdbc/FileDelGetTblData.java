package jp.co.sj.xop.batch.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Component;
import jp.co.sj.xop.batch.common.constants.Constants;
import jp.co.sj.xop.batch.service.SqlLoaderService;

/**
 * 不要ファイル削除データ取得Queryクラス
 *
 * @author SSD
 *
 */
@Component
public class FileDelGetTblData extends BaseQuery {

  private PreparedStatement preStmt = null;
  private ResultSet rs = null;

  public FileDelGetTblData() {
    super.setMsgHead(Constants.TBNAME_FILE_DEL);
  }

  /**
   * Query実行メソッド
   *
   * @return ArrayList
   * @throws Exception
   */
  @Override
  protected ArrayList<HashMap<String, String>> subQuery(Map<String, String> condition,
      Connection conn, SqlLoaderService sqlLoaderService) throws Exception {
    ArrayList<HashMap<String, String>> result = new ArrayList<HashMap<String, String>>();
    // SQLを取得
    String sql = sqlLoaderService.getSql("FileDelGetTblData");
    try {
      preStmt = conn.prepareStatement(sql);
      rs = preStmt.executeQuery();
      while (rs.next()) {
        // リターン結果にDBから取得したカラム値をセットする
        HashMap<String, String> recMap = new HashMap<String, String>();
        recMap.put("FILE_ID", rs.getString("FILE_ID"));
        recMap.put("FILE_PATH_PARAM", rs.getString("FILE_PATH_PARAM"));
        recMap.put("FILE_NAME_JA", rs.getString("FILE_NAME_JA"));
        recMap.put("MONTHS_HELD", rs.getString("MONTHS_HELD"));
        result.add(recMap);
      }
    } finally {
        rs.close();
        preStmt.close();
    }
    return result;
  }
}
