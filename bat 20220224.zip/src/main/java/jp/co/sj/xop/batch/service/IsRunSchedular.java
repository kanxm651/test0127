package jp.co.sj.xop.batch.service;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Locale;
import javax.sql.DataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Component;
import jp.co.sj.xop.batch.common.DateTimeUtil;
import jp.co.sj.xop.batch.common.constants.Constants;
import jp.co.sj.xop.batch.common.constants.DateTimeConstants;
import jp.co.sj.xop.batch.entity.DBatchCount;

/**
 * 対象バッチの実行状態を確認する. 一日一回正常終了した場合、TRUEを戻る、.<br />
 * それ以外場合、 FALSEを戻る． また、計画停止有無の確認を行う.
 *
 * @author SSD
 *
 */

@Component
public class IsRunSchedular {

  /**
   * jdbcテンプレート.
   */
  @Autowired
  private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

  /**
   * データソース.
   */
  @Autowired
  public DataSource dataSource;

  /**
   * メッセージソース.
   */
  @Autowired
  MessageSource messagesource;

  /**
   * 環境変数より、バッチ計画停止
   */
  private static final String batchOutage = System.getenv("BATCH_OUTAGE");

  private String logHead = Constants.EMPTY;

  public void setLogHead(String logHead) {
    this.logHead = logHead;
  }

  /**
   * ロガー.
   */
  private static final Logger logger = LoggerFactory.getLogger(IsRunSchedular.class);

  /**
   * Spring Batch実行共通テーブルから、正常に完了した対象バッチあるか確認する.<br/>
   * 正常完了ある場合、 TRUEを戻す。正常完了ない場合、FALSEを戻す。
   *
   * @return 実行結果（0以上：TRUE，上記以外：false）
   */
  public boolean isRunSchedularinDay(String jobName, String jobStatus) {

    if (Constants.ON.equals(batchOutage)) {
      return false;
    }
    // バッチ実行結果フラグ
    try {
      MapSqlParameterSource key = new MapSqlParameterSource();

      // システムの日付を取得する
      String systemDate = DateTimeUtil.getDateFormat(Timestamp.valueOf(LocalDateTime.now()),
          DateTimeConstants.DATETIMEFORMAT_DATE);

      // Job名前
      key.addValue("key1", jobName);
      // システム日付
      key.addValue("key2", systemDate);
      // Job状態
      key.addValue("key3", jobStatus);

      // Sql文を編集する
      StringBuffer strSql = new StringBuffer(Constants.EMPTY);
      strSql.append("SELECT count(*) AS cmpCnt ");
      strSql.append("FROM public.batch_job_execution AS execution, ");
      strSql.append("public.batch_job_instance AS jobinstance ");
      strSql.append("WHERE execution.job_instance_id  = jobinstance.job_instance_id ");
      strSql.append("AND jobinstance.job_name = :key1 ");
      strSql.append("AND to_char(execution.start_time,  'yyyymmdd') = :key2 ");
      strSql.append("AND execution.status = :key3 ");
      List<DBatchCount> compCnt = namedParameterJdbcTemplate.query(strSql.toString(), key,
          new BeanPropertyRowMapper<DBatchCount>(DBatchCount.class));
      // 既にバッチが完成した記録がある場合、trueを戻す。それ以外、falseを戻す。
      if (compCnt.get(0).getCmpCnt() > 0) {
        logger.info(
            messagesource.getMessage("message.LOGMSG0003I", new String[] {logHead}, Locale.JAPAN));
        return true;
      } else {
        return false;
      }
    } catch (Exception e) {
      logger.error(
          messagesource.getMessage("message.LOGMSG0003E", new String[] {logHead}, Locale.JAPAN), e);
      return false;
    }
  }

  /**
   * Spring Batch実行共通テーブルから、正常に完了した対象バッチはあるかを確認する（1時間毎）.<br />
   * 正常完了ある場合、TRUEを戻す。正常完了ない場合、FALSEを戻す。
   *
   * @return 実行結果（0以上：TRUE，上記以外：false）
   * @throws Exception
   */
  public boolean isRunSchedularInHour(String jobName, String jobStatus) throws Exception {

    if (Constants.ON.equals(batchOutage)) {
      return false;
    }
    // バッチ実行結果フラグ
    try {
      MapSqlParameterSource key = new MapSqlParameterSource();

      // システムの日付・時を取得する
      String systemDate = DateTimeUtil.format(Timestamp.valueOf(LocalDateTime.now()),
          DateTimeConstants.DATETIMEFORMAT_DATEHOUR);

      // Job名前
      key.addValue("key1", jobName);
      // システム日付
      key.addValue("key2", systemDate);
      // Job状態
      key.addValue("key3", jobStatus);

      // Sql文を編集する
      StringBuffer strSql = new StringBuffer(Constants.EMPTY);
      strSql.append("SELECT count(*) AS cmpCnt ");
      strSql.append("FROM public.batch_job_execution AS execution, ");
      strSql.append("public.batch_job_instance AS jobinstance ");
      strSql.append("WHERE execution.job_instance_id  = jobinstance.job_instance_id ");
      strSql.append("AND jobinstance.job_name = :key1 ");
      strSql.append("AND to_char(execution.start_time,  'yyyymmddHH24') = :key2 ");
      strSql.append("AND execution.status = :key3 ");

      List<DBatchCount> compCnt = namedParameterJdbcTemplate.query(strSql.toString(), key,
          new BeanPropertyRowMapper<DBatchCount>(DBatchCount.class));
      // 既にバッチが完成した記録がある場合、trueを戻す。それ以外、falseを戻す。
      if (compCnt.get(0).getCmpCnt() > 0) {
        logger.info(
            messagesource.getMessage("message.LOGMSG0003I", new String[] {logHead}, Locale.JAPAN));
        return true;
      } else {
        return false;
      }
    } catch (Exception e) {
      logger.error(
          messagesource.getMessage("message.LOGMSG0003E", new String[] {logHead}, Locale.JAPAN), e);
      return false;
    }
  }
}
