package jp.co.sj.xop.batch.tasklet;

import java.util.List;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.ItemStreamException;
import org.springframework.batch.item.ItemStreamWriter;
import org.springframework.stereotype.Component;

/**
 * 出力処理
 *
 * @author SSD
 *
 */
@Component
public class BaseDataWriter implements ItemStreamWriter<Object> {

  @Override
  public void open(ExecutionContext executionContext) {
    // TODO 自動生成されたメソッド・スタブ

  }

  @Override
  public void update(ExecutionContext executionContext) {
    // TODO 自動生成されたメソッド・スタブ

  }

  @Override
  public void close() throws ItemStreamException {
    // TODO 自動生成されたメソッド・スタブ

  }

  @SuppressWarnings("rawtypes")
  @Override
  public void write(List items) throws Exception {
    // TODO 自動生成されたメソッド・スタブ

  }

}
