package jp.co.sj.xop.batch.tasklet;

import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;
import jp.co.sj.xop.batch.common.DateTimeUtil;
import jp.co.sj.xop.batch.common.LocalDateTimeEx;
import jp.co.sj.xop.batch.common.ParamConvert;
import jp.co.sj.xop.batch.common.constants.Constants;
import jp.co.sj.xop.batch.common.constants.DateTimeConstants;
import jp.co.sj.xop.batch.jdbc.BaseQuery;
import jp.co.sj.xop.batch.service.SqlLoaderService;

/**
 * データ取得IMPL
 *
 * @author SSD
 *
 */
@Component
public class BaseReaderImpl {

  private Map<String, String> readFunctionMap = new HashMap<String, String>();
  // システム時間取得
  static Timestamp nowTimestamp = Timestamp.valueOf(LocalDateTimeEx.now());
  static String sys_date =
      DateTimeUtil.format(nowTimestamp, DateTimeConstants.DATETIMEFORMAT_DATE_TIME);

  protected void setReadFunctionMap(Map<String, String> readFunctionMap) {
    this.readFunctionMap = readFunctionMap;
  }

  @SuppressWarnings("unchecked")
  public HashMap<String, ArrayList<HashMap<String, String>>> getReaderResult(
      Map<String, String> condition, Connection conn, SqlLoaderService sqlLoaderService,
      MessageSource messagesource) throws Exception {
    HashMap<String, ArrayList<HashMap<String, String>>> result =
        new HashMap<String, ArrayList<HashMap<String, String>>>();

    // フォームコードよりフォームのデータ取得を利用なクラスを取得する
    readFunctionMap.put(Constants.FORM_DAO_MAP.get(condition.get("FORM_CODE")), "query");

    if ((int) readFunctionMap.size() == 0) {
      return null;
    } else {
      for (String key : readFunctionMap.keySet()) {
        ArrayList<HashMap<String, String>> subResult = null;
        ArrayList<HashMap<String, String>> attachmentResult = null;
        // データ取得する
        Class<?> baseQueryClass = Class.forName(key);
        BaseQuery baseQuery = (BaseQuery) (baseQueryClass.getDeclaredConstructor().newInstance());
        Method queryMethod = baseQueryClass.getMethod(readFunctionMap.get(key), Map.class,
            Connection.class, SqlLoaderService.class, MessageSource.class);
        // SQL文の時間条件設定
        condition.put("SYSTEM_TIME", sys_date);
        subResult = (ArrayList<HashMap<String, String>>) queryMethod.invoke(baseQuery,
            new Object[] {condition, conn, sqlLoaderService, messagesource});
        // データがフォームテーブルから取得した場合。
        if (Constants.DAO_LIST.contains(key)) {
          // Convert編集をする。
          Class<?> convert = Class.forName("jp.co.sj.xop.batch.common.ParamConvert");
          ParamConvert param = new ParamConvert();
          Method method = convert.getMethod(Constants.METHOD_MAP.get(key), ArrayList.class);
          attachmentResult =
              (ArrayList<HashMap<String, String>>) method.invoke(param, (Object) subResult);
          result.put("jp.co.sj.xop.batch.jdbc.AttachmentQuery", attachmentResult);
        } else {
          // データがフォームテーブル以外から取得した場合。
          result.put(key, subResult);
        }
      }
    }

    return result;
  }
}
