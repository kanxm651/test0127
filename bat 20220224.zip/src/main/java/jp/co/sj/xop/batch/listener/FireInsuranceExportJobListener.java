package jp.co.sj.xop.batch.listener;

import org.springframework.stereotype.Component;
import jp.co.sj.xop.batch.common.constants.Constants;

/**
 * 集配信システムへファイル転送（火災保険加入相談）バッチの Job前後に実施する処理。
 *
 * @author SSD
 *
 */
@Component
public class FireInsuranceExportJobListener extends BaseJobListener {
  public FireInsuranceExportJobListener() {
    super.setLogHead(Constants.FIRE_INSURANCE_EXPORT_JOB_NAME_JAP);
  }
}
