package jp.co.sj.xop.batch.listener;

import org.springframework.stereotype.Component;

/**
 * 不要データ削除バッチ のWrite前後に実施する処理。
 *
 * @author SSD
 *
 */
@Component
public class RegularDelItemWriteListener extends BaseItemWriteListener {
}
