package jp.co.sj.xop.batch.common;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjuster;
import jp.co.sj.xop.batch.common.constants.DateTimeConstants;

/**
 * 任意の日付をシステム日付として取得するためのLocalDateTimeラッパークラス<br>
 * <br>
 * 環境変数ASOFDATESに調整したい日付の設定を行うことで、LocalDateTimeの返すシステム日付を<br>
 * 任意の日付にすることができるようにする。<br>
 * <br>
 * 設定方法：<br>
 * ASOFDATES=デフォルトの加算日数[,変更前の日付(yyyyMMdd)=変更後の日付(yyyyMMdd)]<br>
 * <br>
 * デフォルトの加算日数は環境変数を設定する場合、設定必須とする。<br>
 * 後述の変更前日付の中にシステム日付が見つからなかった場合、<br>
 * 取得したシステム日付にこの日数を加算する。マイナス設定可能。<br>
 * <br>
 * 変更前の日付と変更後の日付は必ずセットで指定すること。複数セット指定可能。<br>
 * システム日付と一致する変更前の日付が設定されている場合、<br>
 * 変更後の日付に置き換えた日付がシステム日付として返す。<br>
 * <br>
 * 設定例：<br>
 * ASOFDATES=180<br>
 * 一律、システム日付に180日加算された日付をシステム日付として返す。<br>
 * <br>
 * ASOFDATES=0,20180901=20181201,20180902=20190101<br>
 * システム日付が2018/9/1なら2018/12/1を、2018/9/2なら2019/1/1を返す。<br>
 * それ以外の場合はシステム日付を無加工で返す。
 *
 * @author
 *
 */
public class LocalDateTimeEx {
  /**
   * 調整済みシステム日付の取得
   *
   * @return 環境変数ASOFDATESの設定により調整されたシステム日付
   */
  public static LocalDateTime now() {
    // 環境変数ASOFDATESの取得
    return now(System.getenv("ASOFDATES"));
  }

  /**
   * 調整済みシステム日付の取得(設定値直接指定)
   *
   * @param asofdates 環境変数ASOFDATESに設定する設定値
   * @return 引数で指定した設定により調整されたシステム日付
   */
  public static LocalDateTime now(String asofdates) {
    // 設定がなければシステム日付をそのまま返す
    if (asofdates == null || asofdates.isEmpty()) {
      return LocalDateTime.now();
    }
    // 設定がある場合、デフォルトのアジャスタを現在日付から調整日数分加算したものにする
    TemporalAdjuster adjuster = LocalDate.now().plusDays(Integer.parseInt(asofdates.split(",")[0]));
    // 現在日付の置き換え設定があるかどうかチェック
    String nowDate =
        LocalDate.now().format(DateTimeFormatter.ofPattern(DateTimeConstants.DATETIMEFORMAT_DATE))
            + "=";
    for (String data : asofdates.split(",")) {
      if (data.contains(nowDate)) {
        // 置き換え設定が見つかったら、アジャスタを置き換え後の日付にする
        adjuster = LocalDate.parse(data.split("=")[1],
            DateTimeFormatter.ofPattern(DateTimeConstants.DATETIMEFORMAT_DATE));
        break;
      }
    }
    return LocalDateTime.now().with(adjuster);
  }
}
