package jp.co.sj.xop.batch.common;


import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;


/**
 * 日付時間操作関連クラス
 *
 * @author SSD
 *
 */
public class DateTimeUtil {


  /**
   * 日付をフォーマットする.
   *
   * @param timestamp フォーマット前
   * @param pattern パターン
   * @return フォーマット後
   */
  public static String format(Timestamp timestamp, String pattern) {
    LocalDateTime localDateTime = timestamp.toLocalDateTime();
    DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern(pattern);
    return localDateTime.format(dateTimeFormatter);
  }


  public static String getDateFormat(Timestamp timestamp, String strformat) {
    LocalDateTime localDateTime = timestamp.toLocalDateTime();
    DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern(strformat);

    return localDateTime.format(dateTimeFormatter);
  }
}
