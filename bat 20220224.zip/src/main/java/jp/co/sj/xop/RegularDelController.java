package jp.co.sj.xop;

import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import jp.co.sj.xop.batch.listener.RegularDelItemProcessListener;
import jp.co.sj.xop.batch.listener.RegularDelItemReadListener;
import jp.co.sj.xop.batch.listener.RegularDelItemWriteListener;
import jp.co.sj.xop.batch.listener.RegularDelJobListener;
import jp.co.sj.xop.batch.listener.RegularDelStepListener;
import jp.co.sj.xop.batch.tasklet.RegularDelDataProcessor;
import jp.co.sj.xop.batch.tasklet.RegularDelDataReader;
import jp.co.sj.xop.batch.tasklet.RegularDelDataWriter;

/**
 * 不要データ削除バッチ Controllerクラス
 *
 * @author SSD
 *
 */
@EnableBatchProcessing
@EnableAutoConfiguration
@ComponentScan
public class RegularDelController extends BaseController {

  @Autowired
  public JobBuilderFactory jobBuilderFactory;

  /**
   * リスナー定義
   */
  @Autowired
  private RegularDelItemProcessListener regularDelItemProcessListener;
  @Autowired
  private RegularDelItemReadListener regularDelItemReadListener;
  @Autowired
  private RegularDelItemWriteListener regularDelItemWriteListener;
  @Autowired
  private RegularDelJobListener regularDelJobListener;
  @Autowired
  private RegularDelStepListener regularDelStepListener;

  /**
   * 取得処理定義
   */
  @Autowired
  private RegularDelDataReader regularDelDataReader;
  /**
   * 編集処理定義
   */
  @Autowired
  private RegularDelDataProcessor regularDelDataProcessor;
  /**
   * 出力処理定義
   */
  @Autowired
  private RegularDelDataWriter regularDelDataWriter;

  /**
   * mainメソッド
   *
   * @param args 引数
   */
  public static void main(String[] args) throws Exception {
    SpringApplication.run(RegularDelController.class, args);
  }

  /**
   * Job実行メソッド
   *
   * @return Job
   * @throws Exception
   */
  @Bean(name = "RegularDelBatchJob")
  public Job NightnoticeExportBatchJob(JobBuilderFactory jobBuilderFactory) throws Exception {
    // 不要データ削除Jobの取得データセット
    super.setBaseDataRead(regularDelDataReader);
    // 不要データ削除Jobの編集データセット
    super.setBaseDataProcessor(regularDelDataProcessor);
    // 不要データ削除Jobの出力データセット
    super.setBaseDataWriter(regularDelDataWriter);
    // 不要データ削除JobのStepリスナーセット
    super.setBaseStepListener(regularDelStepListener);
    // 不要データ削除JobのReadリスナーセット
    super.setBaseItemReadListener(regularDelItemReadListener);
    // 不要データ削除JobのProcessリスナーセット
    super.setBaseItemProcessListener(regularDelItemProcessListener);
    // 不要データ削除JobのWriteリスナーセット
    super.setBaseItemWriteListener(regularDelItemWriteListener);
    // 不要データ削除Jobを実行
    return jobBuilderFactory.get("RegularDelBatchJob").incrementer(new RunIdIncrementer())
        // step処理開始
        .preventRestart().start(stepExecution())
        // 正常の場合、ステータスと終了コードを取得、Job完了
        .on(ExitStatus.COMPLETED.getExitCode()).end()
        // 異常した場合、ステータスと終了コードを取得、Job完了
        .on(ExitStatus.FAILED.getExitCode()).fail().end()
        // 不要データ削除Jobリスナーセット
        .listener(regularDelJobListener)
        // Job実行
        .build();
  }
}
