package jp.co.sj.xop.batch.common.constants;

/**
 * CD117:受付区分２の列挙クラス
 *
 * @author SSD
 *
 */
public enum CD117 implements Encodable<String> {
  /**
   * なし
   */
  RECEPTION_DIV_NOTHING("00", "なし");

  /** デコーダー */
  private static final Decoder<String, CD117> DECODER = Decoder.create(values());

  /** コード値 */
  private final String code;

  /** 名称 */
  private final String name;

  /**
   * コンストラクタ.
   *
   * @param code コード値
   * @param name 名称
   */
  private CD117(String code, String name) {
    this.code = code;
    this.name = name;
  }

  @Override
  public String getCode() {
    return code;
  }

  /**
   * コード値からEnumクラスを取得する.
   *
   * @param code コード値
   * @return 受領形式Enumクラス
   */
  public static CD117 decode(String code) {
    return DECODER.decode(code);
  }

  /**
   * 名称を取得するメソッド.
   *
   * @return 名称
   */
  public String getName() {
    return name;
  }
}

