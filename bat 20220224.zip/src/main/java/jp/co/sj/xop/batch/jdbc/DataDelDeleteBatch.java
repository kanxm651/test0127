package jp.co.sj.xop.batch.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import org.springframework.stereotype.Component;
import jp.co.sj.xop.batch.common.constants.Constants;
import jp.co.sj.xop.batch.service.SqlLoaderService;

/**
 * 不要データ削除バッチ 削除管理テーブルのデータDeleteクラス
 *
 * @author SSD
 */
@Component
public class DataDelDeleteBatch extends BaseUpdate {

  private PreparedStatement preStmt = null;
  private ResultSet rs = null;

  /**
   * Update実行メソッド
   *
   * @return updateCount
   * @throws Exception
   */

  @Override
  protected int subExecute(List<String> list, Connection conn, SqlLoaderService sqlLoaderService)
      throws Exception {
    int updateCount = 0;
    String sql = Constants.EMPTY;
    try {
      if (list != null) {
        conn.setAutoCommit(false);
        ArrayList<HashMap<String, String>> result = new ArrayList<HashMap<String, String>>();
        sql =
            "SELECT j.job_execution_id,j.job_instance_id,s.step_execution_id FROM batch_job_execution j, batch_step_execution s "
                + "WHERE j.last_updated < (to_timestamp('" + list.get(4)
                + "','yyyymmdd hh24:mi:ss') - interval '" + list.get(3) + " month') "
                + "AND j.job_execution_id = s.job_execution_id";
        preStmt = conn.prepareStatement(sql);
        rs = preStmt.executeQuery();
        while (rs.next()) {
          // リターン結果にDBから取得したカラム値をセットする
          HashMap<String, String> recMap = new HashMap<String, String>();
          recMap.put("JOB_EXECUTION_ID", rs.getString("JOB_EXECUTION_ID"));
          recMap.put("JOB_INSTANCE_ID", rs.getString("JOB_INSTANCE_ID"));
          recMap.put("STEP_EXECUTION_ID", rs.getString("STEP_EXECUTION_ID"));
          result.add(recMap);
        }


        for (int i = 0; i < result.size(); i++) {
          String sql1 = "DELETE FROM batch_step_execution_context WHERE step_execution_id = "
              + result.get(i).get("STEP_EXECUTION_ID");
          preStmt = conn.prepareStatement(sql1);
          preStmt.executeUpdate();
        }
        conn.commit();

        for (int i = 0; i < result.size(); i++) {
          String sql2 = "DELETE FROM batch_step_execution WHERE step_execution_id = "
              + result.get(i).get("STEP_EXECUTION_ID");
          preStmt = conn.prepareStatement(sql2);
          preStmt.executeUpdate();
        }
        conn.commit();

        for (int i = 0; i < result.size(); i++) {
          String sql3 = "DELETE FROM batch_job_execution_params WHERE job_execution_id = "
              + result.get(i).get("JOB_EXECUTION_ID");
          preStmt = conn.prepareStatement(sql3);
          preStmt.executeUpdate();
        }
        conn.commit();

        for (int i = 0; i < result.size(); i++) {
          String sql4 = "DELETE FROM batch_job_execution_context WHERE job_execution_id = "
              + result.get(i).get("JOB_EXECUTION_ID");
          preStmt = conn.prepareStatement(sql4);
          preStmt.executeUpdate();
        }
        conn.commit();

        for (int i = 0; i < result.size(); i++) {
          String sql5 = "DELETE FROM batch_job_execution WHERE job_execution_id = "
              + result.get(i).get("JOB_EXECUTION_ID");
          preStmt = conn.prepareStatement(sql5);
          updateCount += preStmt.executeUpdate();
        }
        conn.commit();

        for (int i = 0; i < result.size(); i++) {
          String sql6 = "DELETE FROM batch_job_instance WHERE job_instance_id = "
              + result.get(i).get("JOB_INSTANCE_ID");
          preStmt = conn.prepareStatement(sql6);
          preStmt.executeUpdate();
        }
        conn.commit();

      }
    } finally {
        rs.close();
        preStmt.close();
    }
    return updateCount;
  }

}
