package jp.co.sj.xop.batch.common;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * TXTtoAFTUtilsクラス.
 *
 * @author SSD 曾洋
 *
 */
public class FileToAftUtils {

  /**
   *
   * @param txtFile
   * @param outPutPath
   * @throws Exception
   */
  public static String copyAftFile(String fileAbsolutePath, String outPutPath, String name)
      throws Exception {

    File file = new File(fileAbsolutePath);
    File aftFile = new File(outPutPath);
    String aftName = null;

    try {
      InputStream in = new FileInputStream(file);
      // バックアップファイル名を設定
      aftName = name + ".aft";
      OutputStream out = new FileOutputStream(new File(aftFile, aftName));

      byte[] buffer = new byte[(int) file.length()];
      if (buffer.length != 0) {
        while (in.read(buffer) != -1) {
          out.write(buffer);
        }
        in.close();
        out.close();
      } else {
        in.close();
        out.close();
      }
    } catch (Exception e) {
      return null;
    }

    return aftName;
  }

}
