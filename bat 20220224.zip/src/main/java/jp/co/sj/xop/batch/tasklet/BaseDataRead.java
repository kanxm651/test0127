package jp.co.sj.xop.batch.tasklet;

import javax.sql.DataSource;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.ItemStreamException;
import org.springframework.batch.item.ItemStreamReader;
import org.springframework.batch.item.NonTransientResourceException;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;
import jp.co.sj.xop.batch.service.IsRunSchedular;

/**
 * 取得処理
 *
 * @author SSD
 *
 */
@Component
public class BaseDataRead implements ItemStreamReader<Object> {

  @Autowired
  MessageSource messagesource;

  @Autowired
  public DataSource dataSource;


  @Autowired
  public IsRunSchedular IsRunSchedular;

  @Override
  public void open(ExecutionContext executionContext) throws ItemStreamException {
    // TODO 自動生成されたメソッド・スタブ

  }

  @Override
  public void update(ExecutionContext executionContext) throws ItemStreamException {
    // TODO 自動生成されたメソッド・スタブ

  }

  @Override
  public void close() throws ItemStreamException {
    // TODO 自動生成されたメソッド・スタブ

  }

  @Override
  public Object read()
      throws Exception, UnexpectedInputException, ParseException, NonTransientResourceException {
    return null;
  }



}
