package jp.co.sj.xop.batch.tasklet;

import java.lang.reflect.Method;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;
import jp.co.sj.xop.batch.common.DateTimeUtil;
import jp.co.sj.xop.batch.common.JSONXOPUtils;
import jp.co.sj.xop.batch.common.MailUtils;
import jp.co.sj.xop.batch.common.TempFileUtils;
import jp.co.sj.xop.batch.common.constants.Constants;
import jp.co.sj.xop.batch.common.constants.DateTimeConstants;
import jp.co.sj.xop.batch.service.S3Services;
import net.sf.json.JSONNull;

/**
 * 夜間バッチ通知メール送信バッチ 編集処理
 *
 * @author SSD
 *
 */
@Component
public class NightnoticeExportDataProcessor extends BaseDataProcessor {

  /**
   * ロガー
   */
  private static final Logger logger =
      LoggerFactory.getLogger(NightnoticeExportDataProcessor.class);

  /**
   * フォルダパス文字列.
   */
  @Value("${app.temp_folder_path}")
  private String tempfolder;

  /**
   * S3Services.
   */
  @Autowired
  S3Services s3Services;

  /**
   * メッセージソース
   */
  @Autowired
  private MessageSource messagesource;
  private String csvMailSubject = Constants.EMPTY;
  String tableName = Constants.EMPTY;

  /**
   * 抽出したデータをファイルに加工処理.
   *
   * @author SSD
   *
   */
  @SuppressWarnings({"unchecked", "unlikely-arg-type"})
  @Override
  public Object process(Object item) throws Exception {
    // 抽出したデータ
    String processorParam = Constants.EMPTY;
    // 加工処理フラグ
    boolean processorFlag = false;
    // 加工処理完了フラグ
    boolean processorEndFlag = false;
    // 出力レコード配列
    HashMap<String, Object> subFlagMap = new HashMap<String, Object>();
    // データ編集処理エラーフラグ
    boolean dataProcessErrorFlag = false;
    // クラス名
    String thisclassName = this.getClass().getName();
    processorParam = item.toString();
    // 夜間バッチ通知メール送信バッチ 状態検証
    if (!StringUtils.isEmpty(processorParam)) {
      if ("readerror".equals(processorParam.substring(1, 10))) {
        // 状態より、各フラグ設定
        processorEndFlag = false;
        processorFlag = false;
        dataProcessErrorFlag = true;
        csvMailSubject = (processorParam.split("="))[1].substring(0,
            (processorParam.split("="))[1].length() - 1);
      } else if ("readenderror".equals(processorParam.substring(1, 13))) {
        processorEndFlag = true;
        processorFlag = false;
        dataProcessErrorFlag = true;
        csvMailSubject = (processorParam.split("="))[1].substring(0,
            (processorParam.split("="))[1].length() - 1);
      } else if ("readend".equals(processorParam.substring(1, 8))) {
        processorEndFlag = true;
        processorFlag = true;
      } else if ("read".equals(processorParam.substring(1, 5))) {
        processorFlag = true;
        processorEndFlag = false;
      }
    }
    Map<String, Object> result = new HashMap<String, Object>();
    if (processorFlag) {
      // 添付配列
      Map<String, HashMap<String, ArrayList<String>>> attachmentMap =
          new HashMap<String, HashMap<String, ArrayList<String>>>();
      // メールアドレス配列
      Map<String, String> addressMap = new HashMap<String, String>();
      // オプションリスト
      List<HashMap<String, String>> optionList = new ArrayList<HashMap<String, String>>();
      // メールアドレスリスト
      List<HashMap<String, String>> addressList = new ArrayList<HashMap<String, String>>();
      // 添付リスト
      List<HashMap<String, String>> attachmentList = new ArrayList<HashMap<String, String>>();
      try {
        // 抽出データから、各リスト作成
        result = JSONXOPUtils.object2Map(item);
        optionList = (List<HashMap<String, String>>) result
            .get("jp.co.sj.xop.batch.jdbc.NightNoticeGetFormOption");
        addressList = (List<HashMap<String, String>>) result
            .get("jp.co.sj.xop.batch.jdbc.NightNoticeGetMailAddress");
        attachmentList =
            (List<HashMap<String, String>>) result.get("jp.co.sj.xop.batch.jdbc.AttachmentQuery");
        tableName = Constants.FORM_TBNAME_MAP.get(optionList.get(0).get("FORM_CODE"));


        // メールアドレス配列を作成する
        if (addressList == null || addressList.size() == 0) {
          // メールアドレス配列データ取得0件の場合、ログを出力する。
          dataProcessErrorFlag = true;
          logger.error(messagesource.getMessage("message.LOGMSG0023I",
              new String[] {Constants.TBNAME_MAILADDRESS, tableName}, Locale.JAPAN));
        } else {
          StringBuffer sBuffer = new StringBuffer();
          for (HashMap<String, String> singleMap : addressList) {
            sBuffer = new StringBuffer();
            for (int i = 1; i < 16; i++) {
              String key = "EMAIL_ADD" + String.valueOf(i);
              if (!JSONNull.getInstance().equals(singleMap.get(key))) {
                if (sBuffer.toString().contains(singleMap.get(key))) {
                  continue;
                }
                sBuffer.append(singleMap.get("EMAIL_ADD" + String.valueOf(i)) + ";");
              }
            }
            if (StringUtils.isNotEmpty(sBuffer.toString())) {
              addressMap.put(singleMap.get("FORM_CODE"),
                  (sBuffer.toString()).substring(0, sBuffer.toString().length() - 1));
            } else {
              // 対象フォームメールアドレスが0件の場合、ログを出力する。
              dataProcessErrorFlag = true;
              logger.error(messagesource.getMessage("message.LOGMSG0013E",
                  new String[] {Constants.TBNAME_MAILADDRESS, tableName}, Locale.JAPAN));
            }
          }
        }
        if (!dataProcessErrorFlag) {
          // 添付データ組合せメソッド呼び出す
          Class<?> convertUtilClass = Class.forName("jp.co.sj.xop.batch.common.ConvertUtil");
          Method getMethod = convertUtilClass.getMethod("StringMosaiWithQuotes", List.class,
              HashMap.class, String.class);
          // 添付配列を作成する
          if (attachmentList == null || attachmentList.size() == 0) {
            // 更新不要と設定
            subFlagMap.put("UPDATE_FLAG", "DO_NOT");
          } else {
            for (HashMap<String, String> singleMap : attachmentList) {
              // データ作成メソッドキー
              String StringMosaicKey = thisclassName + "_" + singleMap.get("METHODNAME");
              // ファイルに書き込みデータ作成
              String resultstr = (String) getMethod.invoke(convertUtilClass,
                  new Object[] {Constants.CLASS_CONVERT_MAP.get(StringMosaicKey), singleMap,
                      Constants.CLASS_DIVIDER_MAP.get(StringMosaicKey)});
              if (attachmentMap.get(singleMap.get("FORM_CODE")) == null) {
                ArrayList<String> insertNumberList = new ArrayList<String>();
                ArrayList<String> contentsList = new ArrayList<String>();
                insertNumberList.add(singleMap.get("FORM_CODE") + singleMap.get("INSERT_NUMBER"));
                contentsList.add(resultstr);
                HashMap<String, ArrayList<String>> newMap =
                    new HashMap<String, ArrayList<String>>();
                newMap.put("INSERT_NUMBER_LIST", insertNumberList);
                newMap.put("CSV_CONTENTS_LIST", contentsList);
                attachmentMap.put(singleMap.get("FORM_CODE"), newMap);
              } else {
                attachmentMap.get(singleMap.get("FORM_CODE")).get("INSERT_NUMBER_LIST")
                    .add(singleMap.get("FORM_CODE") + singleMap.get("INSERT_NUMBER"));
                attachmentMap.get(singleMap.get("FORM_CODE")).get("CSV_CONTENTS_LIST")
                    .add(resultstr);
              }
            }
            // データ編集成功のログを出力する。
            logger.info(messagesource.getMessage("message.LOGMSG0013I", new String[] {tableName},
                Locale.JAPAN));
          }
        }
      } catch (Exception e) {
        dataProcessErrorFlag = true;
        // データ編集失敗のログを出力する。
        logger.error(
            messagesource.getMessage("message.LOGMSG0004E", new String[] {tableName}, Locale.JAPAN),
            e);
      }
      /*
       * csv_flag 0 1 2 COMPLETED FAILED no file
       *
       * mail_flag 0 1
       *
       */
      // データファイルパス
      String fileAbsolutePath = Constants.EMPTY;
      // リトライ回数
      int mailCount = Constants.SENDMAIL_RETYR_TIMES;
      // メール送信フラグ
      boolean mailNextFlag = false;
      // csvフラグ
      boolean csvFlag = false;
      // csvフラグ
      boolean csvErrorFlag = false;
      // メールフラグ
      boolean mailFlag = false;
      // Ｓ３サーバーにアップロードのフラグ
      boolean upFileFlg = false;
      // 送信ステータス
      String status = null;
      // バックアップファイル名
      String aftName = null;

      if (!dataProcessErrorFlag) {
        for (HashMap<String, String> optionSingleMap : optionList) {
          subFlagMap = new HashMap<String, Object>();
          subFlagMap.put("FORM_CODE", optionSingleMap.get("FORM_CODE"));
          // 添付ファイルにデータがある場合
          if (attachmentMap.get(optionSingleMap.get("FORM_CODE")) != null) {
            try {
              // 添付csvファイル作成
              fileAbsolutePath = TempFileUtils.createTempFile(
                  attachmentMap.get(optionSingleMap.get("FORM_CODE")).get("CSV_CONTENTS_LIST"),
                  tempfolder, optionSingleMap.get("CSV_MAIL_SUBJECT"), ".csv");
              csvFlag = true;
              logger.info(messagesource.getMessage("message.LOGMSG0014I",
                  new String[] {optionSingleMap.get("CSV_MAIL_SUBJECT")}, Locale.JAPAN));
            } catch (Exception e) {
              // 添付csvファイル作成失敗のログ出力。
              logger.error(messagesource.getMessage("message.LOGMSG0005E",
                  new String[] {optionSingleMap.get("CSV_MAIL_SUBJECT")}, Locale.JAPAN), e);
              subFlagMap.put("CSV_FLAG", "1");
              subFlagMap.put("MAIL_FLAG", "1");
              csvFlag = false;
              csvErrorFlag = true;
              dataProcessErrorFlag = true;
              csvMailSubject = optionSingleMap.get("CSV_MAIL_SUBJECT");
            }
          }

          if (!csvErrorFlag) {
            // リトライ回数：3
            for (int i = 0; i < mailCount; i++) {
              if (!mailNextFlag) {
                try {
                  // テンプレートデータを作成
                  HashMap<String, Object> mailTemplateData = new HashMap<String, Object>();
                  String datetime =
                      DateTimeUtil.getDateFormat(new Timestamp(System.currentTimeMillis()),
                          DateTimeConstants.DATETIMEFORMAT_DATE_TIME);
                  mailTemplateData.put("mail_subject", optionSingleMap.get("CSV_MAIL_SUBJECT"));
                  mailTemplateData.put("send_datetime", datetime);
                  if (attachmentMap.get(optionSingleMap.get("FORM_CODE")) == null) {
                    // 添付ファイルにデータがない場合
                    // メール本文：yyyy-MM-dd hh:mm:ss サーバー内に上記時点までのデータはありませんでした。
                    mailTemplateData.put("mail_body",
                        Constants.NIGHT_NOTICE_EXPORT_MAIL_NASHIMSGEN);
                    status = MailUtils.sendMail(addressMap.get(optionSingleMap.get("FORM_CODE")),
                        optionSingleMap.get("CSV_MAIL_SUBJECT"), mailTemplateData,
                        fileAbsolutePath);
                  } else {
                    // 添付ファイルにデータがある場合
                    // メール本文：yyyy-MM-dd hh:mm:ssサーバー内の上記時点までのデータを全て添付しました。
                    mailTemplateData.put("mail_body", Constants.NIGHT_NOTICE_EXPORT_MAIL_ARIMSGEN);
                    status = MailUtils.sendMail(addressMap.get(optionSingleMap.get("FORM_CODE")),
                        optionSingleMap.get("CSV_MAIL_SUBJECT"), mailTemplateData,
                        fileAbsolutePath);
                  }
                  String[] str = status.split("%");
                  if (String.valueOf(str[0]).indexOf("2") == 0) {
                    aftName = str[1];
                    mailNextFlag = true;
                    mailFlag = true;
                  } else {
                    mailFlag = false;
                  }
                } catch (Exception e) {
                  mailFlag = false;
                }

              }
            }

            // メール送信成功のログ出力。
            if (mailFlag) {
              logger.info(messagesource.getMessage("message.LOGMSG0017I",
                  new String[] {optionSingleMap.get("CSV_MAIL_SUBJECT")}, Locale.JAPAN));
              subFlagMap.put("MAIL_FLAG", "0");

              /*
               * バックアップファイルをＳ３サーバーにアップロードする
               */
              if (csvFlag) {
                upFileFlg = s3Services.uploadBackupFile(
                    Constants.BKFILE_PATH_NIGHTNOTICE + aftName + Constants.FILE_TYPE_AFT,
                    fileAbsolutePath);
                subFlagMap.put("BK_FILE_NAME", aftName);
                if (!upFileFlg) {
                  // バックアップファイルアップロード失敗のログを出力する。
                  logger.error(messagesource.getMessage("message.LOGMSG0007E",
                      new String[] {optionSingleMap.get("CSV_MAIL_SUBJECT") + Constants.BACKUP},
                      Locale.JAPAN));
                  csvMailSubject = optionSingleMap.get("CSV_MAIL_SUBJECT");
                } else {
                  // バックアップアップロード成功のログを出力する。
                  logger.info(messagesource.getMessage("message.LOGMSG0016I",
                      new String[] {optionSingleMap.get("CSV_MAIL_SUBJECT") + Constants.BACKUP},
                      Locale.JAPAN));
                }
              }
            } else {
              // メール送信失敗ログを出力する
              logger.error(messagesource.getMessage("message.LOGMSG0008E",
                  new String[] {optionSingleMap.get("CSV_MAIL_SUBJECT")}, Locale.JAPAN));
              subFlagMap.put("MAIL_FLAG", "1");
              dataProcessErrorFlag = true;
              csvMailSubject = optionSingleMap.get("CSV_MAIL_SUBJECT");
            }
          }
          // メール添付ありまた送信成功の場合、状態をセット。
          if (csvFlag && mailFlag) {
            subFlagMap.put("CSV_FLAG", "0");
            subFlagMap.put("MAIL_FLAG", "0");
            subFlagMap.put("INSERT_NUMBER_LIST",
                attachmentMap.get(optionSingleMap.get("FORM_CODE")).get("INSERT_NUMBER_LIST"));
          }
          // メール添付なしまた送信成功の場合、状態をセット。
          else if (!csvFlag && mailFlag) {
            subFlagMap.put("CSV_FLAG", "2");
            subFlagMap.put("MAIL_FLAG", "0");
            subFlagMap.put("UPDATE_FLAG", "DO_NOT");
          }
        }
      }
      if (processorEndFlag) {
        subFlagMap.put("END_FLAG", "END");
      }
    }

    if (dataProcessErrorFlag) {
      // エラーの場合、状態をセット
      subFlagMap = new HashMap<String, Object>();

      if (StringUtils.isNotEmpty(csvMailSubject)) {
        subFlagMap.put("ERROR_FLAG", csvMailSubject);
      } else {
        subFlagMap.put("ERROR_FLAG", "ERROR");
      }

      if (processorEndFlag) {
        subFlagMap.put("END_FLAG", "END");
      }
    }
    return subFlagMap;
  }
}
