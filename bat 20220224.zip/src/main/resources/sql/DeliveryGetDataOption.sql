--オプションテーブル取得sql
SELECT
form_code,
inform_mail,
csv_mail,
csv_mail_subject,
return_mail_template,
inform_mail_template,
shuhai_div,
shuhai_tbl
FROM m_option
WHERE shuhai_div = ?

