--火災保険加入相談テーブルを更新するsql
UPDATE t_fire_insurance_inquiry SET shuhai_send_flag = ?,shuhai_send_datetime = (to_timestamp(?,'yyyymmdd hh24:mi:ss')) WHERE form_code=? and insert_number=?