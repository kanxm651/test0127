--お問合せデータ取得sql
SELECT
form_code,
insert_number,
insert_datetime,
customer_number,
reception_div,
inquiry_name,
exchange,
bond_number,
contents,
customer_div,
lastname,
firstname,
lastname_kana,
firstname_kana,
birthday,
sex,
zip_code,
address_pref,
address1,
address2,
address3,
tel_home,
tel_contact,
contact_classify,
email_add,
company,
department,
industry
FROM t_inquiry_interface
WHERE csv_mail_send_flg = ?
AND form_code = ?
AND insert_datetime <  to_timestamp(? ,'yyyy-mm-dd hh24:mi:ss')
ORDER BY insert_datetime asc

