-- 英語お問合データ更新SQL
UPDATE t_english_inquiry_interface SET csv_mail_send_datetime= (to_timestamp(?,'yyyymmdd hh24:mi:ss')) ,csv_mail_send_flg=? WHERE form_code=? and insert_number=?