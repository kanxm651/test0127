-- 美術館英語お問合せデータ更新SQL
UPDATE t_english_museum_inquiry SET csv_mail_send_datetime= (to_timestamp(?,'yyyymmdd hh24:mi:ss')) ,csv_mail_send_flg=? WHERE form_code=? and insert_number=?