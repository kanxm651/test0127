-- 削除管理データ取得SQL
SELECT table_id,table_name_en,table_name_ja,conditon_datetime,conditon_flag,months_held FROM m_data_del WHERE del_flag = ?