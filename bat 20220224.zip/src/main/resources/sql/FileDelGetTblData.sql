-- 不要ファイル削除管理データ取得SQL
SELECT file_id,file_path_param,file_name_ja,months_held FROM m_file_del