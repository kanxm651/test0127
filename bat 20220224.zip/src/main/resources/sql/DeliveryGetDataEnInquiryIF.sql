-- 英語お問合せテーブル取得SQL
SELECT
form_code,
insert_number,
insert_datetime,
reception_div,
contents,
firstname,
lastname,
age,
sex,
address_eng,
email_add
FROM t_english_inquiry_interface
WHERE shuhai_send_flag = ?
AND form_code = ?
AND insert_datetime <  to_timestamp(? ,'yyyy-mm-dd hh24:mi:ss')
ORDER BY insert_datetime asc

