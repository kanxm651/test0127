-- 美術館お問合せテーブル取得SQL
SELECT
form_code,
insert_number,
insert_datetime,
lastname,
firstname,
lastname_kana,
firstname_kana,
zip_code,
address_pref,
address1,
address2,
address3,
tel_contact,
contact_classify,
email_add,
occupation,
industry,
company,
department,
birthday,
contents
FROM t_museum_inquiry
WHERE csv_mail_send_flg = ?
AND form_code = ?
AND insert_datetime <  to_timestamp(? ,'yyyy-mm-dd hh24:mi:ss')
ORDER BY insert_datetime asc