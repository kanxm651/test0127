-- リマインド情報を更新するSQL
UPDATE
    t_fire_insurance_inquiry
SET
    remind_send_flag = ?,
    remind_send_datetime = (to_timestamp(?,'yyyymmdd hh24:mi:ss'))
WHERE
	form_code=? and insert_number=?
