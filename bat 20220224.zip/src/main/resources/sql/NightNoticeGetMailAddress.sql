-- メールアドレスデータ取得SQL
SELECT
form_code,
email_add1,
email_add2,
email_add3,
email_add4,
email_add5,
email_add6,
email_add7,
email_add8,
email_add9,
email_add10,
email_add11,
email_add12,
email_add13,
email_add14,
email_add15
FROM m_mail_address WHERE form_code = ?