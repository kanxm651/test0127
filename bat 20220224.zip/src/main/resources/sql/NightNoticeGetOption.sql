-- オプションデータ取得SQL
SELECT form_code,return_mail,inform_mail,csv_mail,csv_mail_subject FROM m_option WHERE csv_mail = ?