package jp.co.sj.xop.service;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;

import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.util.CellRangeAddress;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.bind.annotation.ModelAttribute;

import jp.co.sj.xop.domain.dto.SpecialEarthquakeSimulationDto;
import jp.co.sj.xop.web.common.SessionManager;

@RunWith(SpringRunner.class)
@SpringBootTest
public class SpecialEarthquakeSimulationServiceTest {

  private static final Logger logger = LoggerFactory.getLogger(EarthquakeSimulationServiceTest.class);

  @Autowired
  SessionManager session;

  @Autowired
  SpecialEarthquakeSimulationService service;

  private BufferedWriter bw;

  @ModelAttribute("TEST001")
  public Class<TEST001> TEST001() {
    return TEST001.class;
  }

  @ModelAttribute("TEST002")
  public Class<TEST002> TEST002() {
    return TEST002.class;
  }

  @Test
  public void testCalcResult() throws Exception {

    File file = new File("D:\\working\\excel\\特約火災\\log.csv");
    FileWriter fw = new FileWriter(file);
    bw = new BufferedWriter(fw);
    bw.append("ファイル名,エラー数");
    bw.newLine();

    String path = "D:\\working\\excel\\特約火災\\";
    String file1 = "特約地震保険試算用([location]・[structure])[from]-[to].xls";
    String file2 = "特約地震保険試算用([location]・[structure]).xls";

    // all
    for (int i = 1; i <= 166680; i = i + 10000) {
      int from = i;
      if (from == 1) {from = 10;}
      int to = i + 9999;
      if (to > 166680) {to = 166680;}

      for (TEST001 location : TEST001.values()) {
        createFile1(path , file1, from, to, "イ構造", location.getCode());
        createFile1(path , file1, from, to, "ロ構造", location.getCode());
      }
    }

    // pickup
    for (TEST002 location : TEST002.values()) {
      createFile2(path , file2, "イ構造", location.getCode());
      createFile2(path , file2, "ロ構造", location.getCode());
    }

    bw.close();

  }

  // all
  private void createFile1(String strPath, String strFile, int moneyFrom ,int moneyTo, String structure, String location) throws Exception {

    strFile = strFile.replace("[from]", String.valueOf(moneyFrom)).replace("[to]", String.valueOf(moneyTo));
    strFile = strFile.replace("[location]", String.valueOf(location)).replace("[structure]", String.valueOf(structure));

    logger.info(strFile + " --- start.");

    SpecialEarthquakeSimulationDto dto = new SpecialEarthquakeSimulationDto();

    HSSFWorkbook workbook = new HSSFWorkbook();

    HSSFSheet sheet1 = workbook.createSheet("特約料率テスト (ケース)");
    HSSFSheet sheet2 = workbook.createSheet("特約料率テスト (結果)");
    HSSFSheet sheet3 = workbook.createSheet("特約料率テスト (検証)");

    HSSFCellStyle styleTitle = CreateStyle.createStyleTitle(workbook);

    createTitle(styleTitle, sheet1);
    createTitle(styleTitle, sheet2);
    createTitle(styleTitle, sheet3);

    HSSFCellStyle styleData = CreateStyle.createStyleData(workbook);

    int rowNum = 1;
    for (int i = moneyFrom; i <= moneyTo; i++) {
      // テストデータ作成
      dto.setTxtMoney(String.valueOf(i));
      dto.setRbtStructure(structure);
      dto.setSelLocation(location);
      session.set(SpecialEarthquakeSimulationDto.KEY, dto);
      service.calcResult(SpecialEarthquakeSimulationDto.KEY);

      // ケースシート
      createSheet1(styleData, sheet1, rowNum, dto);
      // 結果シート
      createSheet2(styleData, sheet2, rowNum, dto);
      // 検証シート
      createSheet3(styleData, sheet3, rowNum, dto);

      rowNum = rowNum + 1;
    }

    // 「×」count
    sheet3.getRow(0).createCell(11).setCellFormula("COUNTIF(F:K,\"×\")");
    FormulaEvaluator evaluator = workbook.getCreationHelper().createFormulaEvaluator();
    bw.append(strFile + "," + String.valueOf(evaluator.evaluate(sheet3.getRow(0).getCell(11)).getNumberValue()));
    bw.newLine();

    File path = new File(strPath + location);
    if (!path.exists()) {
      path.mkdir();
    }
    File file = new File(strPath + location + "\\" + strFile);

    workbook.write(file);
    workbook.close();

    logger.info(strFile + " --- end.");

  }

  // pickup
  private void createFile2(String strPath, String strFile, String structure, String location) throws Exception {

    int[] money = new int[52];
    money[0] = 10;
    money[1] = 20;
    money[2] = 30;
    money[3] = 40;
    money[4] = 50;
    money[5] = 60;
    money[6] = 70;
    money[7] = 80;
    money[8] = 90;
    money[9] = 100;
    money[10] = 200;
    money[11] = 300;
    money[12] = 400;
    money[13] = 500;
    money[14] = 600;
    money[15] = 700;
    money[16] = 800;
    money[17] = 900;
    money[18] = 1000;
    money[19] = 2000;
    money[20] = 3000;
    money[21] = 4000;
    money[22] = 5000;
    money[23] = 6000;
    money[24] = 7000;
    money[25] = 8000;
    money[26] = 9000;
    money[27] = 10000;
    money[28] = 20000;
    money[29] = 30000;
    money[30] = 40000;
    money[31] = 50000;
    money[32] = 60000;
    money[33] = 70000;
    money[34] = 80000;
    money[35] = 90000;
    money[36] = 100000;
    money[37] = 110000;
    money[38] = 120000;
    money[39] = 130000;
    money[40] = 140000;
    money[41] = 150000;
    money[42] = 160000;
    money[43] = 166000;
    money[44] = 166610;
    money[45] = 166620;
    money[46] = 166630;
    money[47] = 166640;
    money[48] = 166650;
    money[49] = 166660;
    money[50] = 166670;
    money[51] = 166680;

    strFile = strFile.replace("[location]", String.valueOf(location)).replace("[structure]", String.valueOf(structure));

    logger.info(strFile + " --- start.");

    SpecialEarthquakeSimulationDto dto = new SpecialEarthquakeSimulationDto();

    HSSFWorkbook workbook = new HSSFWorkbook();

    HSSFSheet sheet1 = workbook.createSheet("特約料率テスト (ケース)");
    HSSFSheet sheet2 = workbook.createSheet("特約料率テスト (結果)");
    HSSFSheet sheet3 = workbook.createSheet("特約料率テスト (検証)");

    HSSFCellStyle styleTitle = CreateStyle.createStyleTitle(workbook);

    createTitle(styleTitle, sheet1);
    createTitle(styleTitle, sheet2);
    createTitle(styleTitle, sheet3);

    HSSFCellStyle styleData = CreateStyle.createStyleData(workbook);

    int rowNum = 1;
    for (int i = 0; i < money.length; i++) {
      // テストデータ作成
      dto.setTxtMoney(String.valueOf(money[i]));
      dto.setRbtStructure(structure);
      dto.setSelLocation(location);
      session.set(SpecialEarthquakeSimulationDto.KEY, dto);
      service.calcResult(SpecialEarthquakeSimulationDto.KEY);

      // ケースシート
      createSheet1(styleData, sheet1, rowNum, dto);
      // 結果シート
      createSheet2(styleData, sheet2, rowNum, dto);
      // 検証シート
      createSheet3(styleData, sheet3, rowNum, dto);

      rowNum = rowNum + 1;
    }

    // 「×」count
    sheet3.getRow(0).createCell(11).setCellFormula("COUNTIF(F:K,\"×\")");
    FormulaEvaluator evaluator = workbook.getCreationHelper().createFormulaEvaluator();
    bw.append(strFile + "," + String.valueOf(evaluator.evaluate(sheet3.getRow(0).getCell(11)).getNumberValue()));
    bw.newLine();

    File path = new File(strPath + location);
    if (!path.exists()) {
      path.mkdir();
    }
    File file = new File(strPath + location + "\\" + strFile);

    workbook.write(file);
    workbook.close();

    logger.info(strFile + " --- end.");

  }

  // タイトル
  private void createTitle(HSSFCellStyle style, HSSFSheet sheet) {

    HSSFRow row = sheet.createRow(0);

    row.createCell(0).setCellValue("項番");
    row.createCell(1).setCellValue("所在地");
    row.createCell(2).setCellValue("構造");
    row.createCell(3).setCellValue("適用料率");
    row.createCell(4).setCellValue("火災保険金額\r\n単位：千円");
    row.createCell(5).setCellValue("最低地震保険金額\r\n単位：千円");
    row.createCell(6).setCellValue("最高地震保険金額\r\n単位：千円");
    row.createCell(7).setCellValue("１年間保険料\r\n最低地震保険料\r\n単位：円");
    row.createCell(8).setCellValue("１年間保険料\r\n最高地震保険料\r\n単位：円");
    row.createCell(9).setCellValue("５年間保険料\r\n最低地震保険料\r\n単位：円");
    row.createCell(10).setCellValue("５年間保険料\r\n最高地震保険料\r\n単位：円");

    for (int i = 0; i <= 10; i++) {
      row.getCell(i).setCellStyle(style);
    }
    row.setHeightInPoints(45);
    sheet.setColumnWidth(0, 3000);
    sheet.setColumnWidth(1, 3000);
    sheet.setColumnWidth(2, 3000);
    sheet.setColumnWidth(3, 3000);
    sheet.setColumnWidth(4, 4000);
    sheet.setColumnWidth(5, 5000);
    sheet.setColumnWidth(6, 5000);
    sheet.setColumnWidth(7, 4500);
    sheet.setColumnWidth(8, 4500);
    sheet.setColumnWidth(9, 4500);
    sheet.setColumnWidth(10, 4500);
    sheet.setAutoFilter(new CellRangeAddress(0, 0, 0, 10));

  }

  //ケースシート
  private void createSheet1(HSSFCellStyle style, HSSFSheet sheet, int rowNum, SpecialEarthquakeSimulationDto dto) {

    HSSFRow row = sheet.createRow(rowNum);

    row.createCell(0).setCellValue(rowNum);
    row.createCell(1).setCellValue(dto.getSelLocation());
    row.createCell(2).setCellValue(dto.getRbtStructure());
    row.createCell(3).setCellValue(dto.getRate().doubleValue());
    row.createCell(4).setCellValue(dto.getTxtMoney());
    row.createCell(5).setCellFormula("MIN(ROUNDUP(E[R]*0.3,0),50000)".replace("[R]", String.valueOf(rowNum + 1)));
    row.createCell(6).setCellFormula("MIN(ROUNDDOWN(E[R]*0.5,0),50000)".replace("[R]", String.valueOf(rowNum + 1)));
    row.createCell(7).setCellFormula("IF(ROUND(D[R]*F[R],-1)=0,10,ROUND(D[R]*F[R],-1))".replace("[R]", String.valueOf(rowNum + 1)));
    row.createCell(8).setCellFormula("IF(ROUND(D[R]*G[R],-1)=0,10,ROUND(D[R]*G[R],-1))".replace("[R]", String.valueOf(rowNum + 1)));
    row.createCell(9).setCellFormula("IF(ROUND(F[R]*ROUND(D[R]*4.65,2),-1)=0,10,ROUND(F[R]*ROUND(D[R]*4.65,2),-1))".replace("[R]", String.valueOf(rowNum + 1)));
    row.createCell(10).setCellFormula("IF(ROUND(G[R]*ROUND(D[R]*4.65,2),-1)=0,10,ROUND(G[R]*ROUND(D[R]*4.65,2),-1))".replace("[R]", String.valueOf(rowNum + 1)));

    for (int i = 0; i <= 10; i++) {
      row.getCell(i).setCellStyle(style);
    }

  }

  //結果シート
  private void createSheet2(HSSFCellStyle style, HSSFSheet sheet, int rowNum, SpecialEarthquakeSimulationDto dto) {

    HSSFRow row = sheet.createRow(rowNum);

    row.createCell(0).setCellValue(rowNum);
    row.createCell(1).setCellValue(dto.getSelLocation());
    row.createCell(2).setCellValue(dto.getRbtStructure());
    row.createCell(3).setCellValue(dto.getRate().doubleValue());
    row.createCell(4).setCellValue(dto.getTxtMoney());
    row.createCell(5).setCellValue(dto.getMinMoney());
    row.createCell(6).setCellValue(dto.getMaxMoney());
    row.createCell(7).setCellValue(dto.getMinPremOneYear());
    row.createCell(8).setCellValue(dto.getMaxPremOneYear());
    row.createCell(9).setCellValue(dto.getMinPremFiveYear());
    row.createCell(10).setCellValue(dto.getMaxPremFiveYear());

    for (int i = 0; i <= 10; i++) {
      row.getCell(i).setCellStyle(style);
    }

  }

  //検証シート
  private void createSheet3(HSSFCellStyle style, HSSFSheet sheet, int rowNum, SpecialEarthquakeSimulationDto dto) {

    HSSFRow row = sheet.createRow(rowNum);

    row.createCell(0).setCellValue(rowNum);
    row.createCell(1).setCellValue(dto.getSelLocation());
    row.createCell(2).setCellValue(dto.getRbtStructure());
    row.createCell(3).setCellValue(dto.getRate().doubleValue());
    row.createCell(4).setCellValue(dto.getTxtMoney());
    row.createCell(5).setCellFormula("IF('特約料率テスト (ケース)'!F[R]='特約料率テスト (結果)'!F[R],\"○\",\"×\")".replace("[R]", String.valueOf(rowNum + 1)));
    row.createCell(6).setCellFormula("IF('特約料率テスト (ケース)'!G[R]='特約料率テスト (結果)'!G[R],\"○\",\"×\")".replace("[R]", String.valueOf(rowNum + 1)));
    row.createCell(7).setCellFormula("IF('特約料率テスト (ケース)'!H[R]='特約料率テスト (結果)'!H[R],\"○\",\"×\")".replace("[R]", String.valueOf(rowNum + 1)));
    row.createCell(8).setCellFormula("IF('特約料率テスト (ケース)'!I[R]='特約料率テスト (結果)'!I[R],\"○\",\"×\")".replace("[R]", String.valueOf(rowNum + 1)));
    row.createCell(9).setCellFormula("IF('特約料率テスト (ケース)'!J[R]='特約料率テスト (結果)'!J[R],\"○\",\"×\")".replace("[R]", String.valueOf(rowNum + 1)));
    row.createCell(10).setCellFormula("IF('特約料率テスト (ケース)'!K[R]='特約料率テスト (結果)'!K[R],\"○\",\"×\")".replace("[R]", String.valueOf(rowNum + 1)));

    for (int i = 0; i <= 10; i++) {
      row.getCell(i).setCellStyle(style);
    }

  }

}
