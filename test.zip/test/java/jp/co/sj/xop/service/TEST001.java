package jp.co.sj.xop.service;

import jp.co.sj.xop.web.constants.Decoder;
import jp.co.sj.xop.web.constants.Encodable;

/**
 * TEST001:都道府県の列挙クラス
 *
 * @author SSD
 *
 */
public enum TEST001 implements Encodable<String> {
  /**
   * 岩手県
   */
  IWATE("岩手県", ""),
  /**
   * 北海道
   */
  HOKKAIDO("北海道", ""),
  /**
   * 福島県
   */
  FUKUSHIMA("福島県", ""),
  /**
   * 宮城県
   */
  MIYAGI("宮城県", ""),
  /**
   * 愛媛県
   */
  EHIME("愛媛県", ""),
  /**
   * 大阪府
   */
  OSAKA("大阪府", ""),
  /**
   * 愛知県
   */
  AICHI("愛知県", ""),
  /**
   * 茨城県
   */
  IBARAKI("茨城県", ""),
  /**
   * 徳島県
   */
  TOKUSHIMA("徳島県", ""),
  /**
   * 埼玉県
   */
  SAITAMA("埼玉県", ""),
  /**
   * 千葉県
   */
  CHIBA("千葉県", "");

  /** デコーダー */
  private static final Decoder<String, TEST001> DECODER = Decoder.create(values());

  /** コード値 */
  private final String code;

  /** 名称 */
  private final String name;

  /**
   * コンストラクタ.
   *
   * @param code コード値
   * @param name 名称
   */
  private TEST001(String code, String name) {
    this.code = code;
    this.name = name;
  }

  @Override
  public String getCode() {
    return code;
  }

  /**
   * コード値からEnumクラスを取得する.
   *
   * @param code コード値
   * @return 受領形式Enumクラス
   */
  public static TEST001 decode(String code) {
    return DECODER.decode(code);
  }

  /**
   * 名称を取得するメソッド.
   *
   * @return 名称
   */
  public String getName() {
    return name;
  }
}

