package jp.co.sj.xop.service;

import jp.co.sj.xop.web.constants.Decoder;
import jp.co.sj.xop.web.constants.Encodable;

/**
 * TEST002:都道府県の列挙クラス
 *
 * @author SSD
 *
 */
public enum TEST002 implements Encodable<String> {
  /**
   * 青森県
   */
  AOMORI("青森県", ""),
  /**
   * 秋田県
   */
  AKITA("秋田県", ""),
  /**
   * 山形県
   */
  YAMAGATA("山形県", ""),
  /**
   * 栃木県
   */
  TOCHIGI("栃木県", ""),
  /**
   * 群馬県
   */
  GUNMA("群馬県", ""),
  /**
   * 東京都
   */
  TOKYO("東京都", ""),
  /**
   * 神奈川県
   */
  KANAGAWA("神奈川県", ""),
  /**
   * 新潟県
   */
  NIIGATA("新潟県", ""),
  /**
   * 富山県
   */
  TOYAMA("富山県", ""),
  /**
   * 石川県
   */
  ISHIKAWA("石川県", ""),
  /**
   * 福井県
   */
  FUKUI("福井県", ""),
  /**
   * 山梨県
   */
  YAMANASHI("山梨県", ""),
  /**
   * 長野県
   */
  NAGANO("長野県", ""),
  /**
   * 岐阜県
   */
  GIFU("岐阜県", ""),
  /**
   * 静岡県
   */
  SHIZUOKA("静岡県", ""),
  /**
   * 三重県
   */
  MIE("三重県", ""),
  /**
   * 滋賀県
   */
  SHIGA("滋賀県", ""),
  /**
   * 京都府
   */
  KYOTO("京都府", ""),
  /**
   * 兵庫県
   */
  HYOGO("兵庫県", ""),
  /**
   * 奈良県
   */
  NARA("奈良県", ""),
  /**
   * 和歌山県
   */
  WAKAYAMA("和歌山県", ""),
  /**
   * 鳥取県
   */
  TOTTORI("鳥取県", ""),
  /**
   * 島根県
   */
  SHIMANE("島根県", ""),
  /**
   * 岡山県
   */
  OKAYAMA("岡山県", ""),
  /**
   * 広島県
   */
  HIROSHIMA("広島県", ""),
  /**
   * 山口県
   */
  YAMAGUCHI("山口県", ""),
  /**
   * 香川県
   */
  KAGAWA("香川県", ""),
  /**
   * 高知県
   */
  KOCHI("高知県", ""),
  /**
   * 福岡県
   */
  FUKUOKA("福岡県", ""),
  /**
   * 佐賀県
   */
  SAGA("佐賀県", ""),
  /**
   * 長崎県
   */
  NAGASAKI("長崎県", ""),
  /**
   * 熊本県
   */
  KUMAMOTO("熊本県", ""),
  /**
   * 大分県
   */
  OITA("大分県", ""),
  /**
   * 宮崎県
   */
  MIYAZAKI("宮崎県", ""),
  /**
   * 鹿児島県
   */
  KAGOSHIMA("鹿児島県", ""),
  /**
   * 沖縄県
   */
  OKINAWA("沖縄県", "");

  /** デコーダー */
  private static final Decoder<String, TEST002> DECODER = Decoder.create(values());

  /** コード値 */
  private final String code;

  /** 名称 */
  private final String name;

  /**
   * コンストラクタ.
   *
   * @param code コード値
   * @param name 名称
   */
  private TEST002(String code, String name) {
    this.code = code;
    this.name = name;
  }

  @Override
  public String getCode() {
    return code;
  }

  /**
   * コード値からEnumクラスを取得する.
   *
   * @param code コード値
   * @return 受領形式Enumクラス
   */
  public static TEST002 decode(String code) {
    return DECODER.decode(code);
  }

  /**
   * 名称を取得するメソッド.
   *
   * @return 名称
   */
  public String getName() {
    return name;
  }
}

